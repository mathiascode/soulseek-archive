# Copyright (c) 2001-2002 Alexander Kanavin. All rights reserved.

import struct
import types
import zlib

""" This module contains message classes, that networking and UI thread
exchange. Basically there are three types of messages: internal messages,
server messages and p2p messages (between clients)."""

class InternalMessage:
    pass

class Conn(InternalMessage):
    def __init__(self,conn = None,addr = None, init = None):
	self.conn = conn
	self.addr = addr
	self.init = init

class OutConn(Conn):
    """ UI thread sends this to make networking thread establish a connection,
    when a connection is established, networking thread returns and object 
    of this
    type."""
    pass

class IncConn(Conn):
    """ Sent by networking thread to indicate an incoming connection."""
    pass

class ConnClose(Conn):
    """ Sent by networking thread to indicate a connection has been closed."""
    pass

class ServerConn(OutConn):
    """ A connection to the server has been established"""
    pass

class ConnectError(InternalMessage):
    """ Sent when a socket exception occurs. It's up to UI thread to 
    handle this."""
    def __init__(self, connobj = None, err = None):
	self.connobj = connobj
	self.err = err

class IncPort(InternalMessage):
    """ Send by networking thread to tell UI thread the port number client 
    listens on."""
    def __init__(self, port = None):
	self.port = port

class PeerTransfer(InternalMessage):
    """ Used to indicate progress of long transfers. """
    def __init__(self, conn = None, total = None, bytes = None):
	self.conn = conn
	self.bytes = bytes
	self.total = total

class DownloadFile(InternalMessage):
    """ Sent by networking thread to indicate file transfer progress.
    Sent by UI to pass the file object to write and offset to resume download 
    from. """
    def __init__(self, conn = None, offset = None, file = None, filesize = None):
	self.conn = conn
	self.offset = offset
	self.file = file
	self.filesize = filesize

class FileError(InternalMessage):
    """ Sent by networking thread ot indicate that a file error occured during
    filetransfer. """
    def __init__(self, conn = None, file = None):
	self.conn = conn
	self.file = file

class SlskMessage:
    """ This is a parent class for all protocol messages. """

    def getObject(self,message,type, start=0, getintasshort=0):
	""" Returns object of specified type, extracted from message (which is
	a binary array). start is an offset."""
        intsize = struct.calcsize("<I")
        try:
            if type is types.IntType:
                if getintasshort:
                    return intsize+start,struct.unpack("<H",message[start:start+struct.calcsize("<H")])[0]
                else:
                    return intsize+start,struct.unpack("<I",message[start:start+intsize])[0]
            elif type is types.LongType:
                return struct.calcsize("<L")+start,struct.unpack("<L",message[start:start+struct.calcsize("<L")])[0]
            elif type is types.StringType:
                len = int(struct.unpack("<I",message[start:start+intsize])[0])
                string = message[start+intsize:start+len+intsize]
                return len+intsize+start, string
            else:
                return start,None
        except struct.error,error:
            print error
	    return start,None

    def packObject(self,object):
	""" Returns object (integer, long or string packed into a 
	binary array."""
        if type(object) is types.IntType:
            return struct.pack("<i",object)
	elif type(object) is types.LongType:
	    return struct.pack("<I",object)
        elif type(object) is types.StringType:
            return struct.pack("<i",len(object))+object
        
    def makeNetworkMessage(self):
	""" Returns binary array, that can be sent over the network"""
        print "Empty message made, class", self.__class__
        return None
    
    def parseNetworkMessage(self, message):
	""" Extracts information from the message and sets up fields 
	in an object"""
        print "Can't parse incoming messages, class", self.__class__

    def getDict(self, message):
	""" Returns a dictionary of values contained in the message """
	dict = {}
	len, numlabels = self.getObject(message,types.IntType)
	for i in range(numlabels):
	    len, label = self.getObject(message,types.StringType,len)
	    len, value = self.getObject(message,types.StringType,len)
	    dict[label] = value 
	return dict

    def makeMsgFromDict(self, dict):
	""" Makes a protocol message from a dictionary of values """
	msg = self.packObject(len(dict))
	for i in dict.keys():
	    msg = msg + self.packObject(i) + self.packObject(dict[i])
	return msg
	

class ServerMessage(SlskMessage):
    def ntoa(self,ip):
	""" converts ip address in integer form into 'a.b.c.d' string """
	import string
	addr=[]
	for i in range(4):
	     addr, ip = [str(int(ip % 256))] + addr, ip / 256
	return string.join(addr,".")

class PeerMessage(SlskMessage):
    pass

class Login(ServerMessage):
    """ We sent this to the server right after the connection has been 
    established. Server responds with the greeting message. """
    def __init__(self, username=None, passwd=None):
        self.username = username
        self.passwd = passwd

    def makeNetworkMessage(self):
	return self.makeMsgFromDict ({"user":self.packObject(self.username),"pass":self.packObject(self.passwd)})

    def parseNetworkMessage(self,message):
	dict = self.getDict(message)
        self.success = ord(dict["success"])
	self.banner = self.getObject(dict["message"],types.StringType)[1]
	if not self.success:
	    self.reason = self.getObject(dict["reason"],types.StringType)[1]


class SetWaitPort(ServerMessage):
    """ Send this to server to indicate port number that we listen on."""
    def __init__(self, port=None):
        self.port = port

    def makeNetworkMessage(self):
        return self.makeMsgFromDict ({"port":self.packObject(self.port)})

class GetPeerAddress(ServerMessage):
    """ Used to find out a peer's (ip,port) address."""
    def __init__(self, user = None):
        self.user = user

    def makeNetworkMessage(self):
        return self.makeMsgFromDict ({"user":self.packObject(self.user)})

    def parseNetworkMessage(self,message):
	dict = self.getDict(message)
        self.user = self.getObject(dict["user"],types.StringType)[1]
        ipnum = self.getObject(dict["addr"],types.IntType)[1]
	self.ip = self.ntoa(ipnum) 
        self.port = self.getObject(dict["addr"], types.IntType,4,1)[1]

class AddUser(ServerMessage):
    """ Used to be kept updated about a user's status."""
    def __init__(self, user = None):
        self.user = user

    def makeNetworkMessage(self):
        return self.makeMsgFromDict ({"user":self.packObject(self.user)})

    def parseNetworkMessage(self,message):
        dict = self.getDict(message)
        self.user = self.getObject(dict["user"],types.StringType)[1]
        self.userexists = ord(dict["userexists"])

class RemoveUser(ServerMessage):
    """ Used when we no longer want to be kept updated about a user's status."""
    def __init__(self, user = None):
        self.user = user

    def makeNetworkMessage(self):
        return self.makeMsgFromDict ({"user":self.packObject(self.user)})

class GetUserStatus(ServerMessage):
    """ Server tells us if a user has gone away or has returned"""
    def __init__(self, user = None):
        self.user = user

    def makeNetworkMessage(self):
        return self.makeMsgFromDict ({"user":self.packObject(self.user)})

    def parseNetworkMessage(self,message):
        dict = self.getDict(message)
        self.user = self.getObject(dict["user"],types.StringType)[1]
        self.status = self.getObject(dict["status"],types.IntType)[1]
      
class SayChatroom(ServerMessage):
    """ Either we want to say something in the chatroom, or someone did."""
    def __init__(self,room = None, msg = None):
        self.room = room
        self.msg = msg

    def makeNetworkMessage(self):
        return self.makeMsgFromDict ({"room":self.packObject(self.room),"text":self.packObject(self.msg)})

    def parseNetworkMessage(self,message):
        dict = self.getDict(message)
        self.room = self.getObject(dict["room"],types.StringType)[1]
        self.user = self.getObject(dict["user"],types.StringType)[1]
        self.msg = self.getObject(dict["text"],types.StringType)[1]

class UserData:
    """ When we join a room the server send us a bunch of these, 
    for each user."""
    def __init__(self,list):
	self.status = list[0]
	self.avgspeed = list[1]
	self.downloadnum = list[2]
	self.something = list[3]
	self.files = list[4]
	self.dirs = list[5]
	self.slotsfull = list[6]

class JoinRoom(ServerMessage):
    """ Server sends us this message when we join a room. Contains users list
    with data on everyone."""
    def __init__(self,room = None):
        self.room = room

    def makeNetworkMessage(self):
        return self.makeMsgFromDict ({"room":self.packObject(self.room)})

    def parseNetworkMessage(self,message):
        dict = self.getDict(message)
        self.room = self.getObject(dict["room"],types.StringType)[1]

	self.users = self.getUsers(dict)

    def getUsers(self,dict):

        len,numusers = self.getObject(dict["userlist"],types.IntType)
        users = []
        for i in range(numusers):
            len,username = self.getObject(dict["userlist"],types.StringType,len)
            users.append([username,None,None,None,None,None,None,None])

        len, statuslen = self.getObject(dict["statuslist"],types.IntType)
        for i in range(statuslen):
            len,users[i][1]=self.getObject(dict["statuslist"],types.IntType,len)

        len, statslen = self.getObject(dict["statslist"],types.IntType)
        for i in range(statslen):
            len,users[i][2] = self.getObject(dict["statslist"],types.IntType,len)
            len,users[i][3] = self.getObject(dict["statslist"],types.IntType,len)
            len,users[i][4] = self.getObject(dict["statslist"],types.IntType,len)
            len,users[i][5] = self.getObject(dict["statslist"],types.IntType,len)
	    len,users[i][6] = self.getObject(dict["statslist"],types.IntType,len)

	len, slotslen = self.getObject(dict["qdlslist"],types.IntType)
 	for i in range(slotslen):
	    len, users[i][7] = self.getObject(dict["qdlslist"],types.IntType,len)
	usersdict={}
	for i in users:
	    usersdict[i[0]] = UserData(i[1:])
	return usersdict

class LeaveRoom(ServerMessage):
    """ We send this when we want to leave a room."""
    def __init__(self,room = None):
        self.room = room

    def makeNetworkMessage(self):
        return self.makeMsgFromDict ({"room":self.packObject(self.room)})

    def parseNetworkMessage(self,message):
        dict = self.getDict(message)
        self.room = self.getObject(dict["room"],types.StringType)[1]

class UserJoinedRoom(ServerMessage):
    """ Server tells us someone has just joined the room."""
    def parseNetworkMessage(self,message):
        dict = self.getDict(message)
        self.room = self.getObject(dict["room"],types.StringType)[1]
        self.username = self.getObject(dict["user"],types.StringType)[1]

	status = self.getObject(dict["status"],types.IntType)[1]

	len,avgspeed = self.getObject(dict["stats"],types.IntType)
	len,uploads = self.getObject(dict["stats"],types.IntType,len)
        len,something = self.getObject(dict["stats"],types.IntType,len)
        len,files = self.getObject(dict["stats"],types.IntType,len)
        len,folders = self.getObject(dict["stats"],types.IntType,len)

        slotsavail = self.getObject(dict["qdls"],types.IntType)[1]

	self.userdata = UserData([status,avgspeed,uploads,something,files,folders,slotsavail])

class UserLeftRoom(ServerMessage):
    """ Well, the opposite."""
    def parseNetworkMessage(self,message):
        dict = self.getDict(message)
        self.room = self.getObject(dict["room"],types.StringType)[1]
        self.username = self.getObject(dict["user"],types.StringType)[1]

class ConnectToPeer(ServerMessage):
    """ Either we ask server to tell someone else we want to establish a 
    connection with him or server tells us someone wants to connect with us.
    Used when the side that wants a connection can't establish it, and tries
    to go the other way around.
    """
    def __init__(self, token = None, user = None, type = None):
	self.token = token
	self.user = user
	self.type = type
    
    def makeNetworkMessage(self):
	return self.makeMsgFromDict ({"req":self.packObject(self.token),"user":self.packObject(self.user),"type":self.packObject(self.type)})

    def parseNetworkMessage(self,message):
        dict = self.getDict(message)
        self.user = self.getObject(dict["user"],types.StringType)[1]
        len,ipnum = self.getObject(dict["addr"],types.IntType)
	self.ip = self.ntoa(ipnum)
        len,self.port = self.getObject(dict["addr"], types.IntType, len, 1)
	self.token = self.getObject(dict["req"], types.IntType)[1]
	self.type = self.getObject(dict["type"],types.StringType)[1]
    
class MessageUser(ServerMessage):
    """ Chat phrase sent to someone or received by us in private"""
    def __init__(self, user = None, msg = None):
        self.user = user
        self.msg = msg

    def makeNetworkMessage(self):
        return self.makeMsgFromDict ({"user":self.packObject(self.user),"text":self.packObject(self.msg)})

    def parseNetworkMessage(self,message):
        dict = self.getDict(message)
        self.msgid = self.getObject(dict["messageid"],types.IntType)[1]
        self.timestamp = self.getObject(dict["time"],types.IntType)[1]
        self.user = self.getObject(dict["user"],types.StringType)[1]
        self.msg = self.getObject(dict["text"],types.StringType)[1]

class MessageAcked(ServerMessage):
    """ Confirmation of private chat message.
    If we don't send it, the server will keep sending the chat phrase to us.
    """
    def __init__(self, msgid = None):
        self.msgid = msgid

    def makeNetworkMessage(self):
        return self.makeMsgFromDict ({"messageid":self.packObject(self.msgid)})

class FileSearch(ServerMessage):
    """ We send this to the server when we search for something."""
    """ Server send this to tell us someone is searching for something."""
    def __init__(self, requestid = None, text = None):
        self.requestid = requestid
        self.text = text

    def makeNetworkMessage(self):
        return self.makeMsgFromDict ({"req":self.packObject(self.requestid),"term":self.packObject(self.text)})

    def parseNetworkMessage(self,message):
        dict = self.getDict(message)
        self.user = self.getObject(dict["user"],types.StringType)[1]
        self.requestid = self.getObject(dict["req"],types.IntType)[1]
        self.search = self.getObject(dict["term"],types.StringType)[1]

class GetUserStats(ServerMessage):
    """ Server sends this to indicate change in user's statistics"""
    def parseNetworkMessage(self, message):
        dict = self.getDict(message)
	self.user = self.getObject(dict["user"],types.StringType)[1]

        len,self.avgspeed = self.getObject(dict["stats"],types.IntType)
        len,self.downloadnum = self.getObject(dict["stats"],types.IntType,len)
        len,self.something = self.getObject(dict["stats"],types.IntType,len)
        len,self.files = self.getObject(dict["stats"],types.IntType,len)
        len,self.dirs = self.getObject(dict["stats"],types.IntType,len)

class QueuedDownloads(ServerMessage):
    """ Server sends this to indicate if someone has download slots available 
    or not. """
    def parseNetworkMessage(self, message):
        dict = self.getDict(message)
        self.user = self.getObject(dict["user"],types.StringType)[1]
        self.slotsfull = self.getObject(dict["downloads"],types.IntType)[1]

class Relogged(ServerMessage):
    """ Server sends this if someone else logged in under our nickname
    and then disconnects us """
    def parseNetworkMessage(self, message):
        dict = self.getDict(message)


class PlaceInLineResponse(ServerMessage):
    """ Server sends this to indicate change in place in queue while we're
    waiting for files from other peer """
    def __init__(self, user = None, req = None, place = None):
        self.req = req
	self.user = user
        self.place = place

    def makeNetworkMessage(self):
        return self.makeMsgFromDict ({"user":self.packObject(self.user),"req":self.packObject(self.req),"place":self.packObject(self.place)})

    def parseNetworkMessage(self, message):
        dict = self.getDict(message)
        self.user = self.getObject(dict["user"],types.StringType)[1]
        self.req = self.getObject(dict["req"],types.IntType)[1]
        self.place = self.getObject(dict["place"],types.IntType)[1]

class RoomAdded(ServerMessage):
    """ Server tells us a new room has been added"""
    def parseNetworkMessage(self, message):
        dict = self.getDict(message)
        self.room = self.getObject(dict["room"],types.StringType)[1]

class RoomRemoved(ServerMessage):
    """ Server tells us a room has been removed"""
    def parseNetworkMessage(self, message):
        dict = self.getDict(message)
        self.room = self.getObject(dict["room"],types.StringType)[1]

class RoomList(ServerMessage):
    """ Server tells us a list of rooms"""
    def __init__(self):
        pass

    def makeNetworkMessage(self):
        return self.makeMsgFromDict ({})

    def parseNetworkMessage(self, message):
        dict = self.getDict(message)

        len,numrooms = self.getObject(dict["rooms"],types.IntType)
        self.rooms = []
        for i in range(numrooms):
            len,room = self.getObject(dict["rooms"],types.StringType,len)
            self.rooms.append([room,None])

        len,numusercounts = self.getObject(dict["usercounts"],types.IntType)
        for i in range(numusercounts):
            len,usercount = self.getObject(dict["usercounts"],types.IntType,len)
            self.rooms[i][1] = usercount

class ExactFileSearch(ServerMessage):
    """ Someone is searching for a file with an exact name """
    def parseNetworkMessage(self, message):
	dict = self.getDict(message)
	self.req = self.getObject(dict["req"],types.IntType)[1]
	self.file = self.getObject(dict["file"],types.StringType)[1]
	self.folder = self.getObject(dict["folder"],types.StringType)[1]
	self.size = self.getObject(dict["size"],types.IntType)[1]
	self.checksum = self.getObject(dict["checksum"],types.IntType)[1]
	self.user = self.getObject(dict["user"],types.StringType)[1]

class AdminMessage(ServerMessage):
    """ A global message form admin has arrived """
    def parseNetworkMessage(self, message):
        dict = self.getDict(message)
        self.msg = self.getObject(dict["msg"],types.StringType)[1]

class GlobalUserList(JoinRoom):
    """ We send this to get a global list of all users online """
    def __init__(self):
	pass

    def makeNetworkMessage(self):
        return self.makeMsgFromDict ({})

    def parseNetworkMessage(self, message):
        dict = self.getDict(message)
	self.users = self.getUsers(dict)

class TunneledMessage(ServerMessage):
    def __init__(self, user = None, req = None, code = None, msg = None):
	self.user = user
	self.req = req
	self.code = code
	self.msg = msg

    def makeNetworkMessage(self,message):
        return self.makeMsgFromDict ({"user":self.packObject(self.user),"req":self.packObject(self.req),"code":self.packObject(self.code),"msg":self.packObject(self.msg)})

    def parseNetworkMessage(self,message):
	dict = self.getDict(message)
	self.user = self.getObject(dict["user"],types.StringType)[1]
	self.code = self.getObject(dict["code"],types.IntType)[1]
	self.req = self.getObject(dict["req"],types.IntType)[1]
        ip = self.ntoa(self.getObject(dict["addr"],types.IntType)[1])
        port = self.getObject(dict["addr"], types.IntType,4,1)[1]
	self.addr = (ip,port)
	self.msg = dict["msg"][4:]


class PrivilegedUsers(ServerMessage):
    """ A list of thise who made a donation """
    def __init__(self):
	pass

    def parseNetworkMessage(self, message):
	dict = self.getDict(message)
	self.users = []
	len, numusers = self.getObject(dict["users"],types.IntType)
	for i in range(numusers):
	    len, user = self.getObject(dict["users"],types.StringType, len)
	    self.users.append(user)

class CantConnectToPeer(ServerMessage):
    """ We send this to say we can't connect to peer after it has asked us
    to connect. We receive this if we asked peer to connect and it can't do
    this. So this message means a connection can't be established either way.
    """
    def __init__(self, token = None, user = None):
	self.token = token
	self.user = user

    def makeNetworkMessage(self):
	return self.makeMsgFromDict ({"user":self.packObject(self.user),"req":self.packObject(self.token)})

    def parseNetworkMessage(self, message):
        dict = self.getDict(message)
        self.token = self.getObject(dict["req"],types.IntType)[1]

class CantCreateRoom(ServerMessage):
    """ Server tells us a new room cannot be created"""
    def parseNetworkMessage(self, message):
        dict = self.getDict(message)
        self.room = self.getObject(dict["room"],types.StringType)[1]


class PierceFireWall(PeerMessage):
    """ This is the very first message send by peer that established a 
    connection, if it has been asked by other peer to do so. Token is taken
    from ConnectToPeer server message."""
    def __init__(self, conn, token = None):
	self.conn = conn
	self.token = token

    def makeNetworkMessage(self):
	return self.packObject(self.token)
	
    def parseNetworkMessage(self,message):
	len, self.token = self.getObject(message, types.IntType)

class PeerInit(PeerMessage):
    """ This message is sent by peer that initiated a connection, not
    necessarily a peer that actually established it. Token apparently
    can be anything. Type is 'P' if it's anything but filetransfer, 'F' 
    otherwise"""
    def __init__(self, conn = None, user = None, type = None, token = None):
	self.conn = conn
	self.user = user
	self.type = type
	self.token = token

    def makeNetworkMessage(self):
        return self.packObject(self.user)+self.packObject(self.type)+self.packObject(self.token)

    def parseNetworkMessage(self, message):
	len, self.user = self.getObject(message, types.StringType)
	len, self.type = self.getObject(message, types.StringType,len)
	len ,self.token = self.getObject(message, types.IntType, len)

class UserInfoRequest(PeerMessage):
    """ Ask other peer to send user information, picture and all."""
    def __init__(self,conn):
	self.conn = conn

    def makeNetworkMessage(self):
	return self.makeMsgFromDict ({})

    def parseNetworkMessage(self,message):
	pass

class UserInfoReply(PeerMessage):
    """ Peer responds with this, when asked for user information."""
    def __init__(self,conn):
	self.conn = conn

    def parseNetworkMessage(self,message):
        dict = self.getDict(message)
        self.descr = self.getObject(dict["desc"],types.StringType)[1]
        self.has_pic = dict["pic"][0]
        if ord(self.has_pic):
            self.pic = self.getObject(dict["pic"][1:],types.StringType)[1]

#	self.userupl = self.getObject(dict["perusermaxul"], types.IntType)[1]
	self.totalupl = self.getObject(dict["totalmaxul"], types.IntType)[1]
        self.queuesize = self.getObject(dict["qdulcount"], types.IntType)[1]
        self.slotsavail = ord(dict["ulavail"])

class SharedFileList(PeerMessage):
    """ Peer responds with this when asked for a filelist."""
    def __init__(self,conn, list = None):
	self.conn = conn
   	self.list = list
	 
    def parseNetworkMessage(self, message):
        dict = self.getDict(message)
	message=zlib.decompress(dict["list"])
	list={}
	len, ndir = self.getObject(message,types.IntType)
	for i in range(ndir):
	    len, dir = self.getObject(message,types.StringType, len)
	    len, nfiles = self.getObject(message,types.IntType, len)
	    list[dir] = []
	    for j in range(nfiles):
		len, code = len+1, message[len]
		len, name = self.getObject(message,types.StringType, len)
		len, size = self.getObject(message,types.IntType, len)
                len, something = self.getObject(message,types.IntType, len)
		len, ext = self.getObject(message,types.StringType, len)
		len, numattr = self.getObject(message, types.IntType, len)
		attrs = []
		for k in range(numattr):
		    len, attrnum = self.getObject(message,types.IntType, len)
		    len, attr = self.getObject(message,types.IntType, len)
		    attrs.append(attr)
		list[dir].append([code,name,size,ext,attrs])
	self.list = list

class GetSharedFileList(PeerMessage):
    """ Ask the peer for a filelist. """ 
    def __init__(self,conn):

	self.conn = conn

    def parseNetworkMessage(self,message):
	pass

    def makeNetworkMessage(self):
        return self.makeMsgFromDict ({})

class FileSearchResult(PeerMessage):
    """ Peer sends this when it has a file search match."""
    def __init__(self,conn, token = None, list = None):
	self.conn = conn
	self.token = token
	self.list = list
    
    def parseNetworkMessage(self, message):
        dict = self.getDict(message)

	self.token = self.getObject(dict["req"],types.IntType)[1]
	self.freeulslots = ord(dict["freeulslots"])
	self.ulspeed = self.getObject(dict["ulspeed"],types.IntType)[1]
	message = zlib.decompress(dict["list"])
        len, nfiles = self.getObject(message,types.IntType)
        list = []
        for i in range(nfiles):
            len, code = len+1, message[len]
            len, name = self.getObject(message,types.StringType, len)
            len, size = self.getObject(message,types.IntType, len)
	    len, something = self.getObject(message,types.IntType, len)
            len, ext = self.getObject(message,types.StringType, len)
            len, numattr = self.getObject(message, types.IntType, len)
            attrs = []
            for j in range(numattr):
                len, attrnum = self.getObject(message,types.IntType, len)
                len, attr = self.getObject(message,types.IntType, len)
                attrs.append(attr)
            list.append([code,name,size,ext,attrs])
        self.list = list

class FolderContentsRequest(PeerMessage):
    """ Ask the peer to send us the contents of a single folder. """
    def __init__(self, conn, dir=None):
	self.conn = conn
	self.dir = dir

    def makeNetworkMessage(self):
	return self.makeMsgFromDict ({"req":self.packObject(1),"folder":self.packObject(self.dir)})

class FolderContentsResponse(PeerMessage):
    """ Peer tells us the contents of a particular folder (with all subfolders)
    """ 
    def __init__(self, conn):
	self.conn = conn

    def parseNetworkMessage(self, message):
        dict = self.getDict(message)
	message = zlib.decompress(dict["list"])
	
        list={}
        len, nfolders = self.getObject(message,types.IntType)
	for h in range(nfolders):
	        len, folder = self.getObject(message,types.StringType, len)
                len, nfiles = self.getObject(message,types.IntType, len)
		list[folder] = []
                for j in range(nfiles):
                    len, code = len+1, message[len]
                    len, name = self.getObject(message,types.StringType, len)
                    len, size = self.getObject(message,types.IntType, len)
                    len, something = self.getObject(message,types.IntType, len)
                    len, ext = self.getObject(message,types.StringType, len)
                    len, numattr = self.getObject(message, types.IntType, len)
                    attrs = []
                    for k in range(numattr):
                        len, attrnum = self.getObject(message,types.IntType, len)
                        len, attr = self.getObject(message,types.IntType, len)
                        attrs.append(attr)
                    list[folder].append([code,name,size,ext,attrs])
        self.list = list

class TransferRequest(PeerMessage):
    """ Request a file from peer, or tell a peer that we want to send a file to
    them. """
    def __init__(self,conn, direction = None, req = None, file = None, filesize = None):
        self.conn = conn
        self.direction = direction
        self.req = req
        self.file = file
        self.filesize = filesize

    def makeNetworkMessage(self):
	dict = {"direction":self.packObject(self.direction),"req":self.packObject(self.req),"file":self.packObject(self.file)}
	if self.filesize is not None:
		dict["filesize"] = self.packObject(self.filesize)
        return self.makeMsgFromDict (dict)

    def parseNetworkMessage(self,message):

        dict = self.getDict(message)
        self.direction = self.getObject(dict["direction"],types.IntType)[1]
	self.req = self.getObject(dict["req"],types.IntType)[1]
	self.file = self.getObject(dict["file"],types.StringType)[1]
	if self.direction == 1:
	    self.filesize = self.getObject(dict["filesize"],types.IntType)[1]

class TransferResponse(PeerMessage):
    """ Response to the TreansferRequest - either we (or other peer) agrees, or 
    tells the reason for rejecting filetransfer. """
    def __init__(self,conn, allowed = None, reason = None, req = None, filesize=None):
        self.conn = conn
        self.allowed = allowed
        self.req = req
        self.reason = reason
        self.filesize = filesize

    def makeNetworkMessage(self):
	dict = {"allowed":chr(self.allowed),"req":self.packObject(self.req)}
	if self.reason is not None:
	    dict["reason"] = self.packObject(self.reason)
	if self.filesize is not None:
	    dict["filesize"] = self.packObject(self.filesize)
	return self.makeMsgFromDict (dict)

    def parseNetworkMessage(self,message):
        dict = self.getDict(message)
        self.allowed = ord(dict["allowed"])
	self.req = self.getObject(dict["req"],types.IntType)[1]
	if self.allowed and dict.has_key("filesize"):
	    self.filesize = self.getObject(dict["filesize"],types.IntType)[1]
	if not self.allowed:
	    self.reason = self.getObject(dict["reason"],types.StringType)[1]

class TransferSomething(PeerMessage):
    def __init__(self,conn, file = None):
        self.conn = conn
        self.file = file

    def makeNetworkMessage(self):
	dict = {"file":self.packObject(self.file)}
        return self.makeMsgFromDict (dict)

    def parseNetworkMessage(self,msg):
        dict = self.getDict(msg)
	self.file = self.getObject(dict["file"],types.StringType)[1]

class TransferSomething2(PeerMessage):
    def __init__(self,conn, file = None):
        self.conn = conn
        self.file = file

    def makeNetworkMessage(self):
	dict = {"file":self.packObject(self.file)}
        return self.makeMsgFromDict (dict)

    def parseNetworkMessage(self,msg):
        dict = self.getDict(msg)
	self.file = self.getObject(dict["file"],types.StringType)[1]

class PlaceInLine(PeerMessage):
    def __init__(self,conn):
	self.conn = conn

    def parseNetworkMessage(self,message):
	dict = self.getDict(message)
	self.file = self.getObject(dict["file"],types.StringType)[1]
	self.place = self.getObject(dict["place"],types.IntType)[1]

class FileRequest(PeerMessage):
    """ Request a file from peer, or tell a peer that we want to send a file to
    them. """
    def __init__(self,conn, req = None):
	self.conn = conn
	self.req = req

    def makeNetworkMessage(self):
	msg = self.packObject(self.req)
	return msg

