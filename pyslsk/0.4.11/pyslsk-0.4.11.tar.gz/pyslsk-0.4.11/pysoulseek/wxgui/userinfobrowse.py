# Copyright (c) 2001-2002 Alexander Kanavin. All rights reserved.

"""
This module contains GUI classes for displaying user's info and filelist.
"""

import time
from pysoulseek import slskproto
from pysoulseek import slskmessages
import Queue
import threading
import images
import about
import userinfobrowse
import search
import notebook
from sortablelist import sortableListCtrl
from wxPython.wx import *

class UserNotebook(notebook.IconNotebook):
    """ This is a notebook with user's information. Used to show either
    user's info itself or their filelists (this is determined by 
    subwindow class)"""
    def __init__(self, parent, id, queue, subwindow, frame, style=wxCLIP_CHILDREN|wxNB_RIGHT):
        notebook.IconNotebook.__init__(self,parent,id,style = style)
        self.users={}
        self.queue = queue
        self.subwindow = subwindow
        self.frame = frame

    def InitWindow(self,user,conn):
        """ Creates subwindow if necessary"""
        if not self.users.has_key(user):
            self.users[user]= self.subwindow(self, -1, user, conn, self.frame)
            self.AddPage(self.users[user],user)
        else:
            self.users[user].conn = conn

    def ShowInfo(self, user, msg):
        """ Shows info in a subwindow, creating it if necessary."""
        if not self.users.has_key(user):
            self.InitWindow(user, msg.conn)
        self.users[user].ShowInfo(msg) # deletes conn attr
	self.frame.OnPageUpdated(self)
	self.OnPageUpdated(self.users[user])

    def UpdateGauge(self, msg):
        """Updates gauge in a subwindow if a transfer is in progress"""
        for i in self.users.values():
            if i.conn == msg.conn.conn:
                i.UpdateGauge(msg)

class picScrolledWindow(wxScrolledWindow):
    def __init__(self, parent, pic):
        wxScrolledWindow.__init__(self, parent, -1, wxPoint(0, 0),size = wxSize(pic.GetWidth(), pic.GetHeight()))
	self.pic = wxStaticBitmap(self, -1, pic,size=wxSize(pic.GetWidth(), pic.GetHeight()))
        sizer = wxBoxSizer(wxVERTICAL)
        sizer.Add(self.pic,1,wxALIGN_CENTER)
        self.SetSizer(sizer)
        self.SetAutoLayout(true)
	self.SetScrollRate(20,20)

class UserInfoWindow(wxPanel):
    """ This is a window that shows user's information, picture, description
    and all. Was rather hard to get the layout of widgets just right."""
    def __init__(self, parent, id, user, conn, frame):
        wxPanel.__init__(self, parent, id)
        self.gauge = wxGauge(self,-1,100,size=wxSize(250, 25),style=wxGA_HORIZONTAL|wxGA_SMOOTH)
        self.close = wxButton(self, -1, "Close")
	self.savepic = wxButton(self, -1, "Save pic")
	self.savepic.Enable(0)
        self.descr = wxTextCtrl(self,-1,size=wxSize(250,100),style = wxTE_MULTILINE|wxTE_READONLY|wxTE_RICH)
        self.infobox = wxStaticBoxSizer(wxStaticBox(self, -1, "Information:"),wxVERTICAL)
        self.info = wxStaticText(self,-1,"\n\n\n")
        self.infobox.Add(self.info,1,wxEXPAND)
        self.picbox = wxStaticBoxSizer(wxStaticBox(self, -1, "Picture:"),wxVERTICAL)
        self.bitmap = None
	self.image = None

        sizerlowh = wxBoxSizer(wxHORIZONTAL)
        sizerlowh.Add(self.gauge,0,wxEXPAND)
        sizerlowh.Add(60,20,1,wxEXPAND)
	sizerlowh.Add(self.savepic,0,wxEXPAND)
	sizerlowh.Add(10,20,0,wxEXPAND)
        sizerlowh.Add(self.close,0,wxEXPAND)

        sizerv = wxBoxSizer(wxVERTICAL)
        sizerv.Add(wxStaticText(self,-1, "Self-description:"))
        sizerv.Add(self.descr,1,wxEXPAND)
        sizerv.Add(self.infobox,0,wxEXPAND)

        sizeruph = wxBoxSizer(wxHORIZONTAL)
        sizeruph.Add(sizerv,0,wxEXPAND)
        sizeruph.Add(self.picbox,1,wxEXPAND)

        mainsizerv = wxBoxSizer(wxVERTICAL)
        mainsizerv.Add(sizeruph,1,wxEXPAND)
        mainsizerv.Add(sizerlowh,0,wxEXPAND)

        self.SetSizer(mainsizerv)
        self.SetAutoLayout(true)
        EVT_BUTTON(self,self.close.GetId(), self.OnClose)
	EVT_BUTTON(self,self.savepic.GetId(), self.OnSave)

        self.user = user
        self.conn = conn
        self.parent = parent
	self.config = frame.np.config.sections
	self.frame = frame

    def ShowInfo(self,msg):
        """ Actually displays the info"""
        self.conn = None
        self.descr.Clear()
        self.descr.AppendText(msg.descr)
        self.info.SetLabel("Total uploads allowed: %i\nQueue size: %i\nSlots available: %i" %(msg.totalupl,msg.queuesize,msg.slotsavail))
        self.picbox.Remove(0)
        if self.bitmap is not None:
            self.bitmap.Destroy()
        if ord(msg.has_pic):
            import os, tempfile
            name = tempfile.mktemp()
            f = open(name,"w")
            f.write(msg.pic)
            f.close()
            img = wxImage(name).ConvertToBitmap()
            os.remove(name)
	    self.bitmap = picScrolledWindow(self, img)
	    self.image = msg.pic
	    self.savepic.Enable(1)
        else:
            self.bitmap = wxStaticText(self,-1,"No picture available")
	    self.image = None
	    self.savepic.Enable(0)

	self.picbox.Add(self.bitmap,1,wxALIGN_CENTER|wxEXPAND)
        self.picbox.Layout()

    def UpdateGauge(self,msg):
        self.gauge.SetRange(msg.total)
	if msg.bytes > 0 and msg.bytes <= msg.total:
            self.gauge.SetValue(msg.bytes)

    def OnSave(self, event):
	handlers = [wxPNGHandler, wxJPEGHandler, wxBMPHandler,wxICOHandler, wxCURHandler,wxANIHandler,wxGIFHandler,wxPNMHandler,wxPCXHandler,wxTIFFHandler]
        import os, tempfile
        name = os.path.join(self.config["transfers"]["downloaddir"],self.user)
        f = open(name,"w")
        f.write(self.image)
        f.close()
	ext = ""
	for i in handlers:
	    h = i()
	    if h.CanRead(name):
		ext = h.GetExtension()
		break
	newname = name + "." + ext
	os.rename(name,newname)
	self.frame.logMessage("Picture saved to " + newname)


    def OnClose(self, event):
        """ Closes the window"""
        del self.parent.users[self.user]
	parent = self.parent
        self.parent.DeletePage(self.parent.GetSelection())
        if parent.GetPageCount() > 0:
            parent.SetSelection(0)

class FileListCtrl(sortableListCtrl):
    """ This is a list of a user's files in a particular directory"""
    def __init__(self, parent, id, style = wxLC_REPORT|wxLC_VIRTUAL|wxSUNKEN_BORDER|wxLC_VRULES):
        sortableListCtrl.__init__(self,parent,id,style = style)
        self.InsertColumn(0,"Filename", width=200)
        self.InsertColumn(1,"Size",width=100)
        self.InsertColumn(2,"Attributes",width=150)
        self.SetItemCount(0)
        self.list = []
        self.dir = None

        self.parent = parent

    def SetFileList(self, list):
        """ Actually sets the list."""
        if list is None:
            self.SetItemCount(0)
 	    self.list = []
	    self.dir = None
        else:
            self.dir = list[0]
            self.list = list[1]
            self.SetItemCount(len(self.list))

    def OnGetItemText(self, item, col):
        """ Returns item in (item,col) cell."""
	return self.GetColumnValue(self.list[item],col)

    def GetColumnValue(self,item,col):
        import string
        if col == 0:
            return item[1]
        if col == 1:
            return item[2]
        if col == 2:
            if item[3] == 'mp3':
                attrs = item[4]
                if len(attrs) >= 3:
                    if attrs[2] == 1:
                        brs = 'VBR'
                    else:
                        brs = 'Bitrate'
                    br = attrs[0]
                    length = '%i:%02i' %(attrs[1] / 60, attrs[1] % 60)
                    return '%s: %i, Length: %s' %(brs,br,length)
                return ""
            elif item[3] == '':
                return ""
            else:
                return str(item[4])

    def OnGetItemImage(self, item):
	return -1

    def SortList(self, col, order):
        if order == 0:
            self.list.sort(lambda x,y: cmp(self.GetColumnValue(x,col),self.GetColumnValue(y,col)))
        else:
            self.list.sort(lambda y,x: cmp(self.GetColumnValue(x,col),self.GetColumnValue(y,col)))


class DirTreeCtrl(wxTreeCtrl):
    """ A tree of user's directories"""
    def __init__(self, parent, id, style = wxTR_HIDE_ROOT|wxTR_HAS_BUTTONS|wxSUNKEN_BORDER):
        wxTreeCtrl.__init__(self,parent, id, style = style)

    def OnCompareItems(self, item1, item2):
        t1 = self.GetItemText(item1)
        t2 = self.GetItemText(item2)
        if t1 < t2: return -1
        if t1 == t2: return 0
        return 1

class UserBrowseWindow(wxPanel):
    """ A window that lets you browse user's files. Contains a directory 
    tree on the left and a file list on the right"""
    def __init__(self, parent, id, user, conn, frame):
        wxPanel.__init__(self, parent, id)
        self.gauge = wxGauge(self,-1,100,size=wxSize(250, 25),style=wxGA_HORIZONTAL|wxGA_SMOOTH)
        self.search =  wxTextCtrl(self,-1, size = wxSize(300,25),style = wxTE_PROCESS_ENTER)
        self.close = wxButton(self, -1, "Close")
        splitter = wxSplitterWindow(self,-1,style=wxNO_3D|wxSP_3DSASH)
        self.tree = DirTreeCtrl(splitter, -1)
        self.listctrl = FileListCtrl(splitter,-1)

        sizerlowh = wxBoxSizer(wxHORIZONTAL)
        sizerlowh.Add(self.gauge,0,wxEXPAND)
        sizerlowh.Add(60,20,1,wxEXPAND)
        sizerlowh.Add(self.close,0,wxEXPAND)

        sizerhighh = wxBoxSizer(wxHORIZONTAL)
        sizerhighh.Add(wxStaticText(self,-1,"Search file and folder names (exact match):"),0,wxALIGN_CENTER)
        sizerhighh.Add(self.search,1,wxEXPAND)

        mainsizerv = wxBoxSizer(wxVERTICAL)
	mainsizerv.Add(sizerhighh,0,wxEXPAND)
        mainsizerv.Add(splitter,1,wxEXPAND)
        mainsizerv.Add(60,20,0,wxEXPAND)
        mainsizerv.Add(sizerlowh,0,wxEXPAND)

        splitter.SplitVertically(self.tree,self.listctrl,250)

        self.SetSizer(mainsizerv)
        self.SetAutoLayout(true)
        EVT_BUTTON(self,self.close.GetId(), self.OnClose)
        EVT_TREE_SEL_CHANGED (self, self.tree.GetId(), self.OnTreeSelChanged)
        EVT_TEXT_ENTER(self,self.search.GetId(), self.OnSearch)

	self.treedict = {}

	self.searchtext = None
	self.searchitems = []
	self.currentsearchitem = None

        self.user = user
        self.conn = conn
        self.parent = parent
        self.queue = frame.np.queue
        self.processrequest = frame.np.ProcessRequestToPeer
        self.privatechat = frame.np.privatechat
        self.info = frame.np.userinfo
        self.transfers = frame.np.transfers
	self.frame = frame

        self.treemenu = wxMenu()
        self.listmenu = wxMenu()
        downloaddirID=wxNewId()
        self.treemenu.Append(downloaddirID, 'Download Directory')
        EVT_MENU(self.tree,downloaddirID, self.OnDownloadDir)
        downloadfileID=wxNewId()
        self.listmenu.Append(downloadfileID, 'Download File(s)')
        EVT_MENU(self.listctrl,downloadfileID, self.OnDownloadFile)
        sendmessageID=wxNewId()
        self.treemenu.Append(sendmessageID, 'Send Message')
        self.listmenu.Append(sendmessageID, 'Send Message')
        EVT_MENU(self,sendmessageID, self.OnSendMessage)
        getinfoID=wxNewId()
        self.treemenu.Append(getinfoID, 'Get User Info')
        self.listmenu.Append(getinfoID, 'Get User Info')
        EVT_MENU(self,getinfoID, self.OnGetInfo)
	addtolistID=wxNewId()
	self.treemenu.Append(addtolistID, 'Add to User List')
	self.listmenu.Append(addtolistID, 'Add to User List')
	EVT_MENU(self,addtolistID, self.OnAddToList)

        EVT_RIGHT_UP(self.listctrl,self.OnRightUpList)
        EVT_RIGHT_UP(self.tree, self.OnRightUpTree)


    def OnRightUpList(self,event):
        """ Pops up a menu on a right-click in files list."""
        pt = event.GetPosition()
        item, flags = self.listctrl.HitTest(pt)
        if item >= 0:
            self.listctrl.SetItemState(item,wxLIST_STATE_FOCUSED,wxLIST_STATE_FOCUSED)
            self.listctrl.PopupMenu(self.listmenu, pt)

    def OnRightUpTree(self,event):
        """ Pops up a menu on a right click in dirs tree. """
        pt = event.GetPosition()
        item, flags = self.tree.HitTest(pt)
	if flags != wxTREE_HITTEST_NOWHERE:
            self.tree.SelectItem(item)
            self.tree.PopupMenu(self.treemenu, pt)

    """ Handlers for the menu items"""
    def OnSendMessage(self, event):
        self.privatechat.SendMessage(self.user)

    def OnGetInfo(self, event):
        self.processrequest(self.user, slskmessages.UserInfoRequest(None), self.info)

    def OnAddToList(self, event):
	self.frame.AddToList(self.user)

    def ShowInfo(self,msg):
        """ We got the filelist, now set up the directory tree and sort it."""
        self.conn = None
        self.list = msg.list
        self.tree.DeleteAllItems()
        root = self.tree.AddRoot("The Root Item")
        treedict = { "root": (root,{}) }
        for i in self.list.keys():
            dirs = i.split('\\')
            node = treedict["root"]
            for j in dirs:
                if not node[1].has_key(j):
                     node[1][j] = (self.tree.AppendItem(node[0],j),{})
                node = node[1][j]
            self.tree.SetPyData(node[0], (i, self.list[i]))
        self.SortTree(treedict["root"])
	self.treedict = treedict
	self.listctrl.SetFileList([None,[]])
        self.searchtext = None
        self.searchitems = []
        self.currentsearchitem = None


    def SortTree(self,node):
        self.tree.SortChildren(node[0])
        for i in node[1].keys():
            self.SortTree(node[1][i])

    def OnTreeSelChanged(self, event):
        """ On selection of a tree item, display the filelist"""
        self.listctrl.SetFileList(self.tree.GetPyData(event.GetItem()))

    def OnDownloadDir(self,event):
        """ Get every file in the directory """
        import string
        dir = string.split(self.listctrl.dir,'\\')[-1]
        for i in self.listctrl.list:
            self.transfers.getFile(self.user, self.listctrl.dir+'\\'+i[1], dir)

    def OnDownloadFile(self,event):
        """ Get selected files """
	item = -1
	while 1:
            item = self.listctrl.GetNextItem(item,wxLIST_NEXT_ALL,wxLIST_STATE_SELECTED|wxLIST_STATE_FOCUSED)
            if item == -1:
                break
            self.transfers.getFile(self.user,self.listctrl.dir+'\\'+self.listctrl.list[item][1])

    def UpdateGauge(self,msg):
        """ If the filelist is long, this is handy"""
        self.gauge.SetRange(msg.total)
        self.gauge.SetValue(msg.bytes)

    def OnClose(self, event):
        """ Closes the window."""
        del self.parent.users[self.user]
	parent = self.parent
        self.parent.DeletePage(self.parent.GetSelection())
        if parent.GetPageCount() > 0:
            parent.SetSelection(0)

    def OnSearch(self,event):
        """ Process search request"""
        text = self.search.GetLineText(0)
	if text == self.searchtext:
	     self.currentsearchitem = self.currentsearchitem + 1
	     if len(self.searchitems) == self.currentsearchitem:
		self.currentsearchitem = 0 
	else:
	    self.searchitems = self.FindNodes(self.treedict["root"][1],text)
	    if len(self.searchitems) > 0:
		self.searchtext = text
		self.currentsearchitem = 0
	if len(self.searchitems) > 0:
	    self.tree.SelectItem(self.searchitems[self.currentsearchitem][0])
	    for i in range(len(self.listctrl.list)):
	        self.listctrl.SetItemState(i,0,wxLIST_STATE_SELECTED)
	    filenumbers = self.searchitems[self.currentsearchitem][1]
	    if len(filenumbers) > 0:
		for i in filenumbers:
		    self.listctrl.SetItemState(i,wxLIST_STATE_SELECTED,wxLIST_STATE_SELECTED)
	    
    def FindNodes(self,node,text):
	import string
	list = []
	dirs = node.keys()
	dirs.sort()
	for i in dirs:
	    if string.find(string.lower(self.tree.GetItemText(node[i][0])),string.lower(text)) >= 0:
		list.append((node[i][0],[]))
	    if self.tree.GetPyData(node[i][0]) is not None:
		files = self.tree.GetPyData(node[i][0])[1]
		matchedfiles = []
		for j in files:
		    if string.find(string.lower(j[1]),string.lower(text)) >= 0:
			matchedfiles.append(files.index(j))
		if len(matchedfiles)>0:
		    list.append((node[i][0],matchedfiles))
	    list.extend(self.FindNodes(node[i][1],text))
	return list
		
