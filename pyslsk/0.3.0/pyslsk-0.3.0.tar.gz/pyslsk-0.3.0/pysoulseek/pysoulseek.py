# Copyright (c) 2001-2002 Alexander Kanavin. All rights reserved.

"""
This is the actual client code. Actual GUI classes are in the separate modules
"""

import time
import slskproto
import slskmessages
import transfers
import Queue
import threading
import images
import about
import userinfobrowse
import search
import chat
from wxPython.wx import *
from config import *

class NetworkEvent(wxPyEvent):
    """
    Special event that occurs when networking thread sends us some messages.
    msgs is a list of them.
    """
    def __init__(self,id,msgs):
	wxPyEvent.__init__(self)
	self.SetEventType(id)
	self.msgs = msgs

class PeerConnection:
    """
    Holds information about a peer connection. Not every field may be set
    to something. addr is (ip,port) address, conn is a socket object, msgs is
    a list of outgoing pending messages, token is a reverse-handshake 
    number (protocol feature), init is a PeerInit protocol message. (read
    slskmessages docstrings for explanation of these)
    """
    def __init__(self, addr = None, username = None, conn = None, msgs = None, token = None, init = None):
	self.addr = addr
	self.username = username
	self.conn = conn
	self.msgs = msgs
	self.token = token
	self.init = init


class NetworkEventProcessor:
    """ This class contains handlers for various messages from the networking
    thread"""
    def __init__(self,frame):
	self.frame=frame

        self.events = {slskmessages.ConnectError:self.ConnectError,
		       slskmessages.IncPort:self.IncPort,
		       slskmessages.ServerConn:self.ServerConn,
		       slskmessages.ConnClose:self.ConnClose,
		       slskmessages.Login:self.Login,
		       slskmessages.MessageUser:self.MessageUser,
		       slskmessages.FileSearch:self.FileSearch,
			slskmessages.ExactFileSearch:self.ExactFileSearch,
		       slskmessages.UserJoinedRoom:self.UserJoinedRoom,
		       slskmessages.SayChatroom:self.SayChatRoom,
		       slskmessages.JoinRoom:self.JoinRoom,
		       slskmessages.UserLeftRoom:self.UserLeftRoom,
		       slskmessages.QueuedDownloads:self.QueuedDownloads,
		       slskmessages.GetPeerAddress:self.GetPeerAddress,
		       slskmessages.OutConn:self.OutConn,
		       slskmessages.UserInfoReply:self.UserInfoReply,
		       slskmessages.PierceFireWall:self.PierceFireWall,
		       slskmessages.CantConnectToPeer:self.CantConnectToPeer,
		       slskmessages.PeerTransfer:self.PeerTransfer,
		       slskmessages.SharedFileList:self.SharedFileList,
		       slskmessages.FileSearchResult:self.FileSearchResult,
		       slskmessages.ConnectToPeer:self.ConnectToPeer,
		       slskmessages.GetUserStatus:self.GetUserStatus,
		       slskmessages.GetUserStats:self.GetUserStats,
		       slskmessages.PeerInit:self.PeerInit,
		       slskmessages.DownloadFile:self.FileDownload,
			slskmessages.FileRequest:self.FileRequest,
			slskmessages.TransferRequest:self.TransferRequest,
			slskmessages.TransferResponse:self.TransferResponse,
			slskmessages.PlaceInLineResponse:self.PlaceInLineResponse,
		        slskmessages.FileError:self.FileError,
			slskmessages.FolderContentsResponse:self.FolderContentsResponse,
			slskmessages.RoomList:self.RoomList,
			slskmessages.LeaveRoom:self.LeaveRoom,
			slskmessages.GlobalUserList:self.GlobalUserList,
			slskmessages.AddUser:self.AddUser,
			slskmessages.TunneledMessage:self.TunneledMessage}

    def ConnectError(self,msg):
	if msg.connobj.__class__ is slskmessages.ServerConn:
	    self.frame.SetStatusText("Can't connect to server %s:%s: %s" % (msg.connobj.addr[0],msg.connobj.addr[1],msg.err))
	    self.frame.serverconn = None
	    self.frame.mainmenu.Enable(self.frame.connectID,1)
	    self.frame.mainmenu.Enable(self.frame.disconnectID,0)
	elif msg.connobj.__class__ is slskmessages.OutConn:
            for i in self.frame.peerconns:
                if i.addr == msg.connobj.addr and i.conn is None: 
		    if i.token is None:
		        i.token = wxNewId()
			if len(i.msgs) > 0 and i.msgs[0].__class__ is slskmessages.FileRequest:
			    type = 'F'
			else:
			    type = 'P'
			i.init = slskmessages.PeerInit(None,self.frame.config.sections["server"]["login"],type,300)
		        self.frame.queue.put(slskmessages.ConnectToPeer(i.token,i.username,i.init.type))
		        self.frame.users[i.username].behindfw = "yes"
			if len(i.msgs)>=1 and i.msgs[0].__class__ is slskmessages.TransferRequest:
			    self.frame.transfers.gotConnectError(i.msgs[0].req)
		    elif len(i.msgs)==0:
			wxLogMessage("Can't connect to %s, sending notification via the server" %(i.username))
			self.frame.queue.put(slskmessages.CantConnectToPeer(i.token,i.username))
			self.frame.peerconns.remove(i)
			
	else:
	    wxLogMessage("%s %s" %(msg.__class__, vars(msg)))

    def IncPort(self, msg):
        self.frame.waitport = msg.port
	self.frame.SetStatusText("Listening on port %i" %(msg.port))

    def ServerConn(self, msg):
	self.frame.SetStatusText("Connected to server %s:%s, logging in..." %(msg.addr[0],msg.addr[1]))
	self.frame.serverconn = msg.conn
        self.frame.queue.put(slskmessages.Login(self.frame.config.sections["server"]["login"],self.frame.config.sections["server"]["passw"]))
        if self.frame.waitport is not None:	
	    self.frame.queue.put(slskmessages.SetWaitPort(self.frame.waitport))

    def PeerInit(self, msg):
	list = [i for i in self.frame.peerconns if i.conn == msg.conn.conn]
	if list == []:
	    self.frame.peerconns.append(PeerConnection(addr = msg.conn.addr, username = msg.user, conn = msg.conn.conn, init = msg, msgs = []))
	else:
	    for i in list:
		i.init = msg
		i.username = msg.user

    def ConnClose(self, msg):
	if msg.conn == self.frame.serverconn:
	    self.frame.SetStatusText("Disconnected from server %s:%s" %(msg.addr[0],msg.addr[1]))
	    self.frame.serverconn = None
	    self.frame.mainmenu.Enable(self.frame.connectID,1)
	    self.frame.mainmenu.Enable(self.frame.disconnectID,0)
	    self.frame.nb.DeleteAllPages()
	    if self.frame.transfers is not None:
		self.frame.transfers.AbortTransfers()
	        self.frame.config.sections["transfers"]["downloads"] = self.frame.transfers.GetDownloads()
        else:
	    for i in self.frame.peerconns:
	        if i.conn == msg.conn:
		    wxLogMessage("Connection closed by peer: %s" %(vars(i)))
		    self.frame.peerconns.remove(i)
		    self.frame.transfers.ConnClose(msg)
	
    def Login(self,msg):
	conf = self.frame.config.sections
	self.frame.SetStatusText("Logged in, getting the list of rooms...")
	self.frame.privatechat = chat.PrivateChatNotebook(self.frame.nb, -1,self.frame.queue)
	self.frame.chatrooms = chat.ChatRooms(self.frame.nb, -1,self.frame.queue,self.frame.privatechat,self.frame.peerconns, self.frame)
	self.frame.globallist = chat.GlobalUsersList(self.frame.nb, -1,self.frame.queue,self.frame.privatechat,self.frame.peerconns, self.frame)
	self.frame.userinfo = userinfobrowse.UserNotebook(self.frame.nb, -1, self.frame.queue, userinfobrowse.UserInfoWindow, self.frame)
	self.frame.userbrowse = userinfobrowse.UserNotebook(self.frame.nb, -1, self.frame.queue, userinfobrowse.UserBrowseWindow, self.frame)
	self.frame.transfers = transfers.Transfers(self.frame.nb, conf["transfers"]["shared"],conf["transfers"]["downloaddir"],conf["transfers"]["uploadbandwidth"],conf["transfers"]["downloads"],self.frame.peerconns,self.frame.queue, self, self.frame.users, self.frame)
	self.frame.search = search.SearchWindow(self.frame.nb, -1, self.frame.queue, self.frame.ProcessRequestToPeer, self.frame.privatechat, self.frame.userinfo, self.frame.userbrowse, self.frame.transfers)
	self.frame.nb.AddPage(self.frame.chatrooms,"Chat Rooms")
	self.frame.nb.AddPage(self.frame.privatechat,"Private Chat")
	self.frame.nb.AddPage(self.frame.globallist,"Global Users List")
	self.frame.nb.AddPage(self.frame.transfers.downloadspanel,"Downloads")
	self.frame.nb.AddPage(self.frame.search, "Search Files")
	self.frame.nb.AddPage(self.frame.userinfo,"User Info")
	self.frame.nb.AddPage(self.frame.userbrowse,"User Browse")
	self.frame.chatrooms.roomsctrl.SetGreeting(msg.banner)

    def MessageUser(self, msg):
	if self.frame.privatechat is not None:
	    self.frame.privatechat.ShowMessage(msg)
	    self.frame.queue.put(slskmessages.MessageAcked(msg.msgid))
       	else:
            wxLogMessage("%s %s" %(msg.__class__, vars(msg)))

    def UserJoinedRoom(self,msg):
	if self.frame.chatrooms is not None:
	    self.frame.chatrooms.roomsctrl.UserJoinedRoom(msg)
	else:
            wxLogMessage("%s %s" %(msg.__class__, vars(msg)))


    def JoinRoom(self,msg):
	if self.frame.chatrooms is not None:
            self.frame.chatrooms.roomsctrl.JoinRoom(msg)
        else:
            wxLogMessage("%s %s" %(msg.__class__, vars(msg)))

    def LeaveRoom(self,msg):
        if self.frame.chatrooms is not None:
            self.frame.chatrooms.roomsctrl.LeaveRoom(msg)
        else:
            wxLogMessage("%s %s" %(msg.__class__, vars(msg)))


    def SayChatRoom(self,msg):
        if self.frame.chatrooms is not None:
            self.frame.chatrooms.roomsctrl.SayChatRoom(msg)
        else:
            wxLogMessage("%s %s" %(msg.__class__, vars(msg)))

    def AddUser(self,msg):
        if self.frame.transfers is not None:
            self.frame.transfers.getAddUser(msg)
        else:
            wxLogMessage("%s %s" %(msg.__class__, vars(msg)))

    def GetUserStatus(self,msg):
	self.frame.queue.put(slskmessages.AddUser(msg.user))
	if msg.user not in self.frame.users.keys():
	    self.frame.users[msg.user] = UserAddr(status = msg.status)
	else:
	    self.frame.users[msg.user].status = msg.status
	if self.frame.transfers is not None:
	    self.frame.transfers.GetUserStatus(msg)
	if self.frame.chatrooms is not None:
            self.frame.chatrooms.roomsctrl.GetUserStatus(msg)
        else:
            wxLogMessage("%s %s" %(msg.__class__, vars(msg)))


    def GetUserStats(self,msg):
        if self.frame.chatrooms is not None:
            self.frame.chatrooms.roomsctrl.GetUserStats(msg)
        else:
            wxLogMessage("%s %s" %(msg.__class__, vars(msg)))

    def UserLeftRoom(self,msg):
        if self.frame.chatrooms is not None:
            self.frame.chatrooms.roomsctrl.UserLeftRoom(msg)
        else:
            wxLogMessage("%s %s" %(msg.__class__, vars(msg)))


    def QueuedDownloads(self,msg): 
	if self.frame.chatrooms is not None:
	    self.frame.chatrooms.roomsctrl.QueuedDownloads(msg) 
	else: 
	    wxLogMessage("%s %s" %(msg.__class__, vars(msg)))

    def GetPeerAddress(self,msg):
	for i in self.frame.peerconns:
	    if i.username == msg.user and i.addr is None:
		i.addr = (msg.ip, msg.port)
		self.frame.queue.put(slskmessages.OutConn(None, i.addr))
                if len(i.msgs)>=1 and i.msgs[0].__class__ is slskmessages.TransferRequest:
                    self.frame.transfers.gotAddress(i.msgs[0].req)
		break
	wxLogMessage("%s %s" %(msg.__class__, vars(msg)))
	if msg.user not in self.frame.users.keys():
	    self.frame.users[msg.user] = UserAddr((msg.ip,msg.port))
	else:
	    self.frame.users[msg.user].addr = (msg.ip,msg.port)

    def OutConn(self, msg):
	for i in self.frame.peerconns:
	    if i.addr == msg.addr and i.conn is None:
		if i.token is None:
		    if len(i.msgs)>=1 and i.msgs[0].__class__ is slskmessages.FileRequest:
			type='F'
		    else:
			type='P'
		    i.init = slskmessages.PeerInit(msg.conn,self.frame.config.sections["server"]["login"],type,300)
		    self.frame.queue.put(i.init)
		else:
		    self.frame.queue.put(slskmessages.PierceFireWall(msg.conn, i.token))
		i.conn = msg.conn
		for j in i.msgs:
		    if j.__class__ is slskmessages.UserInfoRequest:
			self.frame.userinfo.InitWindow(i.username,msg.conn)
		    if j.__class__ is slskmessages.GetSharedFileList:
			self.frame.userbrowse.InitWindow(i.username,msg.conn)
		    if j.__class__ is slskmessages.TransferRequest:
			self.frame.transfers.gotConnect(j.req,msg.conn)
		    j.conn = msg.conn
		    self.frame.queue.put(j)
		    i.msgs.remove(j)
		break
		
	wxLogMessage("%s %s" %(msg.__class__, vars(msg)))

    def ConnectToPeer(self, msg):
	init = slskmessages.PeerInit(None,msg.user,msg.type,300)
        self.frame.queue.put(slskmessages.OutConn(None,(msg.ip,msg.port),init))
        self.frame.peerconns.append(PeerConnection(addr = (msg.ip,msg.port), username = msg.user, msgs = [], token = msg.token, init = init))

        wxLogMessage("%s %s" %(msg.__class__, vars(msg)))


    def UserInfoReply(self,msg):
	for i in self.frame.peerconns:
	    if i.conn is msg.conn.conn:
		self.frame.userinfo.ShowInfo(i.username, msg)

    def SharedFileList(self, msg):
	for i in self.frame.peerconns:
	    if i.conn is msg.conn.conn:
		self.frame.userbrowse.ShowInfo(i.username, msg)

    def FileSearchResult(self, msg):
	for i in self.frame.peerconns:
	    if i.conn is msg.conn.conn:
		self.frame.search.ShowResult(msg, i.username)

    def PierceFireWall(self, msg):
	for i in self.frame.peerconns:
	    if i.token == msg.token and i.conn is None:
                if len(i.msgs)>=1 and i.msgs[0].__class__ is slskmessages.FileRequest:
                    type='F'
                else:
                    type='P'
		i.init = slskmessages.PeerInit(msg.conn.conn,self.frame.config.sections["server"]["login"],type,300)
                self.frame.queue.put(i.init)
                i.conn = msg.conn.conn
                for j in i.msgs:
                    if j.__class__ is slskmessages.UserInfoRequest:
                        self.frame.userinfo.InitWindow(i.username,msg.conn.conn)
                    if j.__class__ is slskmessages.GetSharedFileList:
                        self.frame.userbrowse.InitWindow(i.username,msg.conn.conn)
		    if j.__class__ is slskmessages.FileRequest:
			self.frame.transfers.gotConnect(j.req,msg.conn.conn)
                    j.conn = msg.conn.conn
                    self.frame.queue.put(j)
                    i.msgs.remove(j)
		break

        wxLogMessage("%s %s" %(msg.__class__, vars(msg)))

    def CantConnectToPeer(self, msg):
	for i in self.frame.peerconns:
	    if i.token == msg.token:
		self.frame.peerconns.remove(i)
	        wxLogMessage("Can't connect to %s (either way), giving up" % (i.username))
                if len(i.msgs)>=1 and i.msgs[0].__class__ is slskmessages.TransferRequest:
                    self.frame.transfers.gotCantConnect(i.msgs[0].req)

    def FileDownload(self,msg):
        if self.frame.transfers is not None:
            self.frame.transfers.FileDownload(msg)
        else:
            wxLogMessage("%s %s" %(msg.__class__, vars(msg)))

    def FileRequest(self,msg):
        if self.frame.transfers is not None:
            self.frame.transfers.FileRequest(msg)
        else:
            wxLogMessage("%s %s" %(msg.__class__, vars(msg)))

    def FileError(self,msg):
        if self.frame.transfers is not None:
            self.frame.transfers.FileError(msg)
        else:
            wxLogMessage("%s %s" %(msg.__class__, vars(msg)))

    def TransferRequest(self,msg):
        if self.frame.transfers is not None:
            self.frame.transfers.TransferRequest(msg)
        else:
            wxLogMessage("%s %s" %(msg.__class__, vars(msg)))

    def TransferResponse(self,msg):
        if self.frame.transfers is not None:
            self.frame.transfers.TransferResponse(msg)
        else:
            wxLogMessage("%s %s" %(msg.__class__, vars(msg)))


    def PlaceInLineResponse(self,msg):
        if self.frame.transfers is not None:
            self.frame.transfers.PlaceInQueue(msg)
        else:
            wxLogMessage("%s %s" %(msg.__class__, vars(msg)))

    def FolderContentsResponse(self,msg):
        if self.frame.transfers is not None:
            self.frame.transfers.FolderContentsResponse(msg)
        else:
            wxLogMessage("%s %s" %(msg.__class__, vars(msg)))

    def RoomList(self,msg):
	if self.frame.chatrooms is not None:
	     self.frame.chatrooms.roomsctrl.SetRoomList(msg)
	     self.frame.SetStatusText("")
	else:
            wxLogMessage("%s %s" %(msg.__class__, vars(msg)))

    def GlobalUserList(self,msg):
        if self.frame.globallist is not None:
             self.frame.globallist.setGlobalUsersList(msg)
        else:
            wxLogMessage("%s %s" %(msg.__class__, vars(msg)))

    def PeerTransfer(self,msg):
	self.frame.userinfo.UpdateGauge(msg)
	self.frame.userbrowse.UpdateGauge(msg)

    def TunneledMessage(self, msg):
	peermsg = self.frame.protothread.peerclasses[msg.code](None)

	peermsg.parseNetworkMessage(msg.msg)
	peermsg.tunneleduser = msg.user
	peermsg.tunneledreq = msg.req
	peermsg.tunneledaddr = msg.addr
	self.frame.callback([peermsg])

    def ExactFileSearch(self,msg):
	pass
	
    def FileSearch(self, msg):
	pass #alright, alright, they take too much space in log window and i kinda don't know where to stick them, and server-side p2p is not yet done anyway

class UserAddr:
    def __init__(self, addr = None, behindfw = None, status = None):
	self.addr = addr
	self.behindfw = behindfw
	self.status = status


class MainFrame(wxFrame):
    """ This is the very main window, with menu, status bar and notebook 
    that contains all other subwindows. Everything else is set up 
    from here""" 
    def __init__(self, parent, id, title): 
        wxFrame.__init__(self,parent,id,title, size = (800,600), style = wxDEFAULT_FRAME_STYLE|wxMAXIMIZE|wxNO_FULL_REPAINT_ON_RESIZE)

	# set icon here, see demo to know how
	self.SetIcon(wxIconFromXPMData(images.getBirdData()))

	# set task bar icon here, see demo to know how

        EVT_CLOSE(self, self.OnCloseWindow)
        self.Centre(wxBOTH)
        self.CreateStatusBar(1, wxST_SIZEGRIP)

	self.config = Config()
	self.config.readConfig()
	self.configwindow = ConfigWindow(self, -1, "Settings")

        self.mainmenu = wxMenuBar()

        menu = wxMenu()
	if not self.config.needConfig():
	    self.serverstring =  '%s:%s'%(self.config.sections["server"]["server"][0],self.config.sections["server"]["server"][1])
	else:
	    self.serverstring = ''
	self.connectID = wxNewId()
	menu.Append(self.connectID, '&Connect\tAlt-C', 'Connect to ' + self.serverstring)
	menu.Enable(self.connectID, not self.config.needConfig())
        EVT_MENU(self, self.connectID, self.OnConnect)
	self.disconnectID = wxNewId()
	menu.Append(self.disconnectID, '&Disconnect\tAlt-D', 'Disconnect from ' + self.serverstring)
	menu.Enable(self.disconnectID, false)
        EVT_MENU(self, self.disconnectID, self.OnDisconnect)
	self.settingsID = wxNewId()
	menu.Append(self.settingsID, '&Settings...', 'Set up server name, login, password')
	EVT_MENU(self, self.settingsID, self.OnSettings)
	menu.AppendSeparator()
        exitID = wxNewId()
        menu.Append(exitID, 'E&xit\tAlt-X', 'Get the heck outta here!')
        EVT_MENU(self, exitID, self.OnFileExit)

	
	helpmenu = wxMenu()
        aboutID = wxNewId()
        helpmenu.Append(aboutID, '&About', 'About PySoulSeek')
        EVT_MENU(self, aboutID, self.OnAbout)

        self.mainmenu.Append(menu, '&File')
	self.mainmenu.Append(helpmenu, '&Help')
        self.SetMenuBar(self.mainmenu)
        aTable = wxAcceleratorTable([(wxACCEL_ALT,  ord('X'), exitID),(wxACCEL_ALT,  ord('C'), self.connectID),(wxACCEL_ALT,  ord('D'), self.disconnectID)])

        splitter = wxSplitterWindow(self, -1, style=wxNO_3D|wxSP_3D)
        self.nb = wxNotebook(splitter, -1, style=wxCLIP_CHILDREN)

	self.log = chat.OutputWindow(splitter,-1,style = wxTE_MULTILINE|wxTE_READONLY|wxTE_RICH)
        EVT_RIGHT_UP(self.log, self.OnRightClickInLog)

        wxLog_SetActiveTarget(wxLogTextCtrl(self.log))

	splitter.SplitHorizontally(self.nb,self.log)	
	splitter.SetSashPosition(400, true)

	self.EVT_NETWORK_ID = wxNewId()     
	self.EVT_NETWORK(self, self.EVT_NETWORK_ID, self.OnNetworkEvent)

	self.np = NetworkEventProcessor(self)
	self.queue = Queue.Queue(0)
    	self.protothread = slskproto.SlskProtoThread(self.callback,self.queue)
	self.serverconn = None
	self.waitport = None
	self.peerconns = []
	self.users = {}
	self.chatrooms = None
	self.privatechat = None
	self.globallist = None
	self.userinfo = None
	self.userbrowse = None
	self.search = None
	self.transfers = None

    def OnRightClickInLog(self,event):
	""" Log window is not self-cleaning yet, unlike chat windows. Will change that when the client stabilizes."""
	menu = wxMenu()
	clearID=wxNewId()
	menu.Append(clearID, 'Clear')
	EVT_MENU(self,clearID, self.OnClearLog)
	self.log.PopupMenu(menu, wxPoint(event.GetX(),event.GetY()))
	event.Skip()

    def OnClearLog(self,event):
	self.log.Clear()

    def OnCloseWindow(self, event):
 	""" Close the window, but finish all filetransfers and stop the 
	networking thread first."""
	if self.transfers is not None:
            self.transfers.AbortTransfers()
            self.config.setConfig({"transfers":{"downloads":self.transfers.GetDownloads()}})
	    self.config.writeConfig()
        self.queue.put(slskmessages.ConnClose(self.serverconn)) 
	self.protothread.abort()
	while self.protothread.isAlive():
  	    wxYield()
	    time.sleep(0.1)
        self.Destroy()
	wxYield()

    """ Menu items handlers."""
    def OnFileExit(self, event):
        self.Close()

    def OnConnect(self, event):
	self.mainmenu.Enable(self.connectID,0)
	self.mainmenu.Enable(self.disconnectID,1)
	if self.serverconn is None:
	    server = self.config.sections["server"]["server"]
	    self.queue.put(slskmessages.ServerConn(None, server))
	    self.SetStatusText("Connecting to %s:%s" %(server[0],server[1]))

    def OnDisconnect(self, event):
	self.queue.put(slskmessages.ConnClose(self.serverconn))

    def OnSettings(self, event):
	self.configwindow.SetSettings(self.config)
	val = self.configwindow.ShowModal()
	if val == wxID_OK:
	    self.config.setConfig(self.configwindow.GetSettings())
	    if not self.config.needConfig():
		self.config.writeConfig()
	        if not self.mainmenu.IsEnabled(self.disconnectID):
		    self.mainmenu.Enable(self.connectID,1)
		server = self.config.sections["server"]["server"]
	        self.serverstring = '%s:%s'%(server[0],server[1])
	        self.mainmenu.SetHelpString(self.connectID,'Connect to '+self.serverstring)
	        self.mainmenu.SetHelpString(self.disconnectID,'Disconnect from '+self.serverstring)

    def OnAbout(self, event):
	about.About(self, -1, "About PySoulSeek").ShowModal()

    def ProcessRequestToPeer(self, user, message, window = None):
        """ 
	Sends message to a peer and possibly sets up a window to display 
	the result.
	"""
	conn = None
        for i in self.peerconns:
	    if i.username == user and i.init is not None and i.init.type == 'P' and message.__class__ is not slskmessages.FileRequest:
	        conn = i
		break
        if conn is not None:
	    message.conn = conn.conn
	    self.queue.put(message)
	    if window is not None:	    
	        window.InitWindow(conn.username,conn.conn)
	else:
	    if self.users.has_key(user):
	        addr = self.users[user].addr
	        behindfw = self.users[user].behindfw
	    else:
		addr = None
		behindfw = None
	    token = None
	    if addr is None:
	        self.queue.put(slskmessages.GetPeerAddress(user))
	    elif behindfw is None:
	        self.queue.put(slskmessages.OutConn(None,addr))
	    else:
	        token = wxNewId()
		if message.__class__ is slskmessages.FileRequest:
		    type = 'F'
		else:
		    type = 'P'
                self.queue.put(slskmessages.ConnectToPeer(token,user,type))

	    self.peerconns.append(PeerConnection(addr = addr, username = user, msgs = [message], token = token))

 
    def callback(self,msgs):
	""" Callback function called by networking thread."""
	wxPostEvent(self, NetworkEvent(self.EVT_NETWORK_ID,msgs))

    def OnNetworkEvent(self, event):
	""" Processes messages from networking thread."""
	for i in event.msgs:
	    if self.np.events.has_key(i.__class__):
		self.np.events[i.__class__](i)
	    else:
		wxLogMessage("%s %s" % (i.__class__, vars(i)))

    def EVT_NETWORK(self, win, id, func):
	""" Network event macro """
	win.Connect(-1, -1, id, func) 

class MainApp(wxApp): 
    """ Application class. """
    def OnInit(self):
	wxInitAllImageHandlers()
        self.frame = MainFrame(None,-1,'PySoulSeek') 
        self.frame.Show(true) 
        self.SetTopWindow(self.frame) 
        return true 


