# Copyright (c) 2001-2002 Alexander Kanavin. All rights reserved.

import struct
import types
import zlib

""" This module contains message classes, that networking and UI thread
exchange. Basically there are three types of messages: internal messages,
server messages and p2p messages (between clients)."""

class InternalMessage:
    pass

class Conn(InternalMessage):
    def __init__(self,conn = None,addr = None):
	self.conn = conn
	self.addr = addr

class OutConn(Conn):
    """ UI thread sends this to make networking thread establish a connection,
    when a connection is established, networking thread returns and object 
    of this
    type."""
    pass

class IncConn(Conn):
    """ Sent by networking thread to indicate an incoming connection."""
    pass

class ConnClose(Conn):
    """ Sent by networking thread to indicate a connection has been closed."""
    pass

class ServerConn(OutConn):
    """ A connection to the server has been established"""
    pass

class ConnectError(InternalMessage):
    """ Sent when a socket exception occurs. It's up to UI thread to 
    handle this."""
    def __init__(self, connobj = None, err = None):
	self.connobj = connobj
	self.err = err

class IncPort(InternalMessage):
    """ Send by networking thread to tell UI thread the port number client 
    listens on."""
    def __init__(self, port = None):
	self.port = port

class PeerTransfer(InternalMessage):
    """ Used to indicate progress of long transfers. """
    def __init__(self, conn = None, total = None, bytes = None):
	self.conn = conn
	self.bytes = bytes
	self.total = total

class DownloadFile(InternalMessage):
    """ Sent by networking thread to indicate file transfer progress.
    Sent by UI to pass the file object to write and offset to resume download 
    from. """
    def __init__(self, conn = None, offset = None, file = None):
	self.conn = conn
	self.offset = offset
	self.file = file

class FileError(InternalMessage):
    """ Sent by networking thread ot indicate that a file error occured during
    filetransfer. """
    def __init__(self, conn = None, file = None):
	self.conn = conn
	self.file = file

class SlskMessage:
    """ This is a parent class for all protocol messages. """

    def getObject(self,message,type, start=0, getintasshort=0):
	""" Returns object of specified type, extracted from message (which is
	a binary array). start is an offset."""
        intsize = struct.calcsize("<I")
        try:
            if type is types.IntType:
                if getintasshort:
                    return intsize+start,struct.unpack("<H",message[start:start+struct.calcsize("<H")])[0]
                else:
                    return intsize+start,struct.unpack("<I",message[start:start+intsize])[0]
            elif type is types.LongType:
                return struct.calcsize("<L")+start,struct.unpack("<L",message[start:start+struct.calcsize("<L")])[0]
            elif type is types.StringType:
                len = int(struct.unpack("<I",message[start:start+intsize])[0])
                string = message[start+intsize:start+len+intsize]
                return len+intsize+start, string
            else:
                return start,None
        except struct.error,error:
            print error
	    return start,None

    def packObject(self,object):
	""" Returns object (integer, long or string packed into a 
	binary array."""
        if type(object) is types.IntType:
            return struct.pack("<i",object)
	elif type(object) is types.LongType:
	    return struct.pack("<I",object)
        elif type(object) is types.StringType:
            return struct.pack("<i",len(object))+object
        
    def makeNetworkMessage(self):
	""" Returns binary array, that can be sent over the network"""
        print "Empty message made, class", self.__class__
        return None
    
    def parseNetworkMessage(self, message):
	""" Extracts information from the message and sets up fields 
	in an object"""
        print "Can't parse incoming messages, class", self.__class__

class ServerMessage(SlskMessage):
    def ntoa(self,ip):
	""" converts ip address in integer form into 'a.b.c.d' string """
	import string
	addr=[]
	for i in range(4):
	     addr, ip = [str(int(ip % 256))] + addr, ip / 256
	return string.join(addr,".")

class PeerMessage(SlskMessage):
    pass

class Login(ServerMessage):
    """ We sent this to the server right after the connection has been 
    established. Server responds with the greeting message. """
    def __init__(self, username=None, passwd=None):
        self.username = username
        self.passwd = passwd

    def makeNetworkMessage(self):
        return self.packObject(self.username)+ self.packObject(self.passwd)

    def parseNetworkMessage(self,message):
        len,self.banner = self.getObject(message,types.StringType)


class SetWaitPort(ServerMessage):
    """ Send this to server to indicate port number that we listen on."""
    def __init__(self, port=None):
        self.port = port

    def makeNetworkMessage(self):
        return self.packObject(self.port)

class GetPeerAddress(ServerMessage):
    """ Used to find out a peer's (ip,port) address."""
    def __init__(self, user = None):
        self.user = user

    def makeNetworkMessage(self):
        return self.packObject(self.user)

    def parseNetworkMessage(self,message):
        len,self.user = self.getObject(message,types.StringType)
        len,ipnum = self.getObject(message,types.IntType,len)
	self.ip = self.ntoa(ipnum) 
        len,self.port = self.getObject(message, types.IntType,len, 1)

class GetUserStatus(ServerMessage):
    """ Server tells us if a user has gone away or has returned"""
    def parseNetworkMessage(self,message):
        len,self.user = self.getObject(message,types.StringType)
        len,self.status = self.getObject(message, types.IntType,len)
      
class SayChatroom(ServerMessage):
    """ Either we want to say something in the chatroom, or someone did."""
    def __init__(self,roomid = None, msg = None):
        self.roomid = roomid
        self.msg = msg

    def makeNetworkMessage(self):
        return self.packObject(self.roomid)+self.packObject(self.msg)

    def parseNetworkMessage(self,message):
        len,self.roomid = self.getObject(message,types.IntType)
        len,self.user = self.getObject(message,types.StringType,len)
        len,self.msg = self.getObject(message,types.StringType,len)

class UserData:
    """ When we join a room the server send us a bunch of these, 
    for each user."""
    def __init__(self,list):
	self.status = list[0]
	self.avgspeed = list[1]
	self.downloadnum = list[2]
	self.something = list[3]
	self.files = list[4]
	self.dirs = list[5]
	self.slotsfull = list[6]
	self.addr = None
	self.behindfw = None

class JoinRoom(ServerMessage):
    """ Server sends us this message when we join a room. Contains users list
    with data on everyone."""
    def parseNetworkMessage(self,message):
        len,self.roomid = self.getObject(message,types.IntType)
        len,numusers = self.getObject(message,types.IntType,len)
        users = []
        while numusers>0:
            len,username = self.getObject(message,types.StringType,len)
            users.append([username,None,None,None,None,None,None,None])
            numusers = numusers - 1
        len, self.statuslen = self.getObject(message,types.IntType,len)
        for i in users:
            len, i[1] = self.getObject(message,types.IntType,len)
	len, something = self.getObject(message, types.StringType, len)
        len, self.statslen = self.getObject(message,types.IntType,len)
        for i in users:
            len, i[2] = self.getObject(message,types.IntType,len)
            len, i[3] = self.getObject(message,types.IntType,len)
            len, i[4] = self.getObject(message,types.IntType,len)
            len, i[5] = self.getObject(message,types.IntType,len)
	    len, i[6] = self.getObject(message,types.IntType,len)
        len, something = self.getObject(message, types.StringType, len)
	len, self.slotslen = self.getObject(message,types.IntType,len)
 	for i in users:
	    len, i[7] = self.getObject(message,types.IntType,len)
	self.users={}
	for i in users:
	    self.users[i[0]] = UserData(i[1:])


class UserJoinedRoom(ServerMessage):
    """ Server tells us someone has just joined the room."""
    def parseNetworkMessage(self,message):
        len,self.roomid = self.getObject(message,types.IntType)
        len,self.username = self.getObject(message,types.StringType,len)
	i = [None,None,None,None,None,None,None]
	for j in range(7):
	    len, i[j] =(self.getObject(message,types.IntType,len))
	self.userdata = UserData(i)

class UserLeftRoom(ServerMessage):
    """ Well, the opposite."""
    def parseNetworkMessage(self,message):
        len,self.roomid = self.getObject(message,types.IntType)
        len,self.username = self.getObject(message,types.StringType,len)

class ConnectToPeer(ServerMessage):
    """ Either we ask server to tell someone else we want to establish a 
    connection with him or server tells us someone wants to connect with us.
    Used when the side that wants a connection can't establish it, and tries
    to go the other way around.
    """
    def __init__(self, token = None, user = None):
	self.token = token
	self.user = user
    
    def makeNetworkMessage(self):
	return self.packObject(self.token)+self.packObject(self.user)

    def parseNetworkMessage(self,message):
        len,self.user = self.getObject(message,types.StringType)
        len,ipnum = self.getObject(message,types.IntType,len)
	self.ip = self.ntoa(ipnum)
        len,self.port = self.getObject(message, types.IntType, len, 1)
	len,self.token = self.getObject(message, types.IntType, len)
    
class MessageUser(ServerMessage):
    """ Chat phrase sent to someone or received by us in private"""
    def __init__(self, user = None, msg = None):
        self.user = user
        self.msg = msg

    def makeNetworkMessage(self):
        return self.packObject(self.user)+self.packObject(self.msg)

    def parseNetworkMessage(self,message):
        len,self.msgid = self.getObject(message,types.IntType)
        len,self.timestamp = self.getObject(message,types.IntType, len)
        len,self.user = self.getObject(message,types.StringType, len)
        len,self.msg = self.getObject(message,types.StringType, len)

class MessageAcked(ServerMessage):
    """ Confirmation of private chat message.
    If we don't send it, the server will keep sending the chat phrase to us.
    """
    def __init__(self, msgid = None):
        self.msgid = msgid

    def makeNetworkMessage(self):
        return self.packObject(self.msgid)

class FileSearchRoom(ServerMessage):
    """ We send this to the server when we search for something."""
    def __init__(self, requestid = None, roomid = None, text = None):
	self.requestid = requestid
	self.roomid = roomid
	self.text = text

    def makeNetworkMessage(self):
	return self.packObject(self.requestid)+self.packObject(self.roomid)+self.packObject(self.text)

class FileSearch(ServerMessage):
    """ Server send this to tell us someone is searching for something."""
    def parseNetworkMessage(self,message):
        len, self.user = self.getObject(message,types.StringType)
        len, self.searchnum = self.getObject(message,types.IntType, len)
        len, self.search = self.getObject(message,types.StringType, len)

class SendConnectToken(ServerMessage):
    """ Frankly I don't know what this is for. I don't use it."""
    def __init__(self, user, token):
        self.user = user
        self.token = token

    def makeNetworkMessage(self):
        return self.packObject(self.user)+self.packObject(self.token)

    def parseNetworkMessage(self, message):
        len, self.user = self.getObject(message,types.StringType)
        len, self.token = self.getObject(message,types.IntType, len)

class QueuedDownloads(ServerMessage):
    """ Server sends this to indicate if someone has download slots available 
    or not. """
    def parseNetworkMessage(self, message):
        len, self.user = self.getObject(message,types.StringType)
        len, self.slotsfull = self.getObject(message,types.IntType, len)

class GetUserStats(ServerMessage):
    """ Server sends this to indicate change in user's statistics"""
    def parseNetworkMessage(self, message):
	len, self.user = self.getObject(message,types.StringType)
        len, self.avgspeed = self.getObject(message,types.IntType, len)
        len, self.downloadnum = self.getObject(message,types.IntType, len)
        len, self.something = self.getObject(message,types.IntType, len)
        len, self.files = self.getObject(message,types.IntType, len)
	len, self.dirs = self.getObject(message,types.IntType, len)

class PlaceInQueue(ServerMessage):
    """ Server sends this to indicate change in place in queue while we're
    waiting for files from other peer """
    def parseNetworkMessage(self, message):
        len, self.user = self.getObject(message,types.StringType)
        len, self.req = self.getObject(message,types.IntType, len)
        len, self.place = self.getObject(message,types.IntType, len)


class CantConnectToPeer(ServerMessage):
    """ We send this to say we can't connect to peer after it has asked us
    to connect. We receive this if we asked peer to connect and it can't do
    this. So this message means a connection can't be established either way.
    """
    def __init__(self, token = None, user = None):
	self.token = token
	self.user = user

    def makeNetworkMessage(self):
	return self.packObject(self.token)+self.packObject(self.user)

    def parseNetworkMessage(self, message):
	len, self.token = self.getObject(message, types.IntType)

class PierceFireWall(PeerMessage):
    """ This is the very first message send by peer that established a 
    connection, if it has been asked by other peer to do so. Token is taken
    from ConnectToPeer server message."""
    def __init__(self, conn, token = None):
	self.conn = conn
	self.token = token

    def makeNetworkMessage(self):
	return self.packObject(self.token)
	
    def parseNetworkMessage(self,message):
	len, self.token = self.getObject(message, types.IntType)

class PeerInit(PeerMessage):
    """ This message is sent by peer that initiated a connection, not
    necessarily a peer that actually established it. Token apparently
    can be anything. Type is 'P' if it's anything but filetransfer, 'F' 
    otherwise"""
    def __init__(self, conn, user = None, type = None, token = None):
	self.conn = conn
	self.user = user
	self.type = type
	self.token = token

    def makeNetworkMessage(self):
        return self.packObject(self.user)+self.packObject(self.type)+self.packObject(self.token)

    def parseNetworkMessage(self, message):
	len, self.user = self.getObject(message, types.StringType)
	len, self.type = self.getObject(message, types.StringType,len)
	len ,self.token = self.getObject(message, types.IntType, len)

class UserInfoRequest(PeerMessage):
    """ Ask other peer to send user information, picture and all."""
    def __init__(self,conn):
	self.conn = conn

    def makeNetworkMessage(self):
	return ""

    def parseNetworkMessage(self,message):
	pass

class UserInfoReply(PeerMessage):
    """ Peer responds with this, when asked for user information."""
    def __init__(self,conn):
	self.conn = conn

    def parseNetworkMessage(self,message):
	len, self.descr = self.getObject(message, types.StringType)
	len, self.has_pic = len+1, message[len]
	if ord(self.has_pic):
	    len, self.pic = self.getObject(message, types.StringType,len)
	len, self.userupl = self.getObject(message, types.IntType, len)
	len, self.totalupl = self.getObject(message, types.IntType, len)
        len, self.queuesize = self.getObject(message, types.IntType, len)
        len, self.slotsavail = len+1, message[len]

class SharedFileList(PeerMessage):
    """ Peer responds with this when asked for a filelist."""
    def __init__(self,conn, list = None):
	self.conn = conn
   	self.list = list
	 
    def parseNetworkMessage(self, message):
	message=zlib.decompress(message)
	list={}
	len, ndir = self.getObject(message,types.IntType)
	for i in range(ndir):
	    len, dir = self.getObject(message,types.StringType, len)
	    len, nfiles = self.getObject(message,types.IntType, len)
	    list[dir] = []
	    for j in range(nfiles):
		len, code = len+1, message[len]
		len, name = self.getObject(message,types.StringType, len)
		len, size = self.getObject(message,types.IntType, len)
		len, ext = self.getObject(message,types.StringType, len)
		len, numattr = self.getObject(message, types.IntType, len)
		attrs = []
		for k in range(numattr):
		    len, attrnum = self.getObject(message,types.IntType, len)
		    len, attr = self.getObject(message,types.IntType, len)
		    attrs.append(attr)
		list[dir].append([code,name,size,ext,attrs])
	self.list = list

class GetSharedFileList(PeerMessage):
    """ Ask the peer for a filelist. """ 
    def __init__(self,conn):

	self.conn = conn

    def parseNetworkMessage(self,message):
	pass

    def makeNetworkMessage(self):
	return ""

class FileSearchResult(PeerMessage):
    """ Peer sends this when it has a file search match."""
    def __init__(self,conn, token = None, list = None):
	self.conn = conn
	self.token = token
	self.list = list
    
    def parseNetworkMessage(self, message):
	message = zlib.decompress(message)
	len, self.token = self.getObject(message,types.IntType)
        len, nfiles = self.getObject(message,types.IntType, len)
        list = []
        for i in range(nfiles):
            len, code = len+1, message[len]
            len, name = self.getObject(message,types.StringType, len)
            len, size = self.getObject(message,types.IntType, len)
            len, ext = self.getObject(message,types.StringType, len)
            len, numattr = self.getObject(message, types.IntType, len)
            attrs = []
            for j in range(numattr):
                len, attrnum = self.getObject(message,types.IntType, len)
                len, attr = self.getObject(message,types.IntType, len)
                attrs.append(attr)
            list.append([code,name,size,ext,attrs])
        self.list = list

class FolderContentsRequest(PeerMessage):
    """ Ask the peer to send us the contents of a single folder. """
    def __init__(self, conn, dir=None):
	self.conn = conn
	self.dir = dir

    def makeNetworkMessage(self):
	return self.packObject(1)+self.packObject(self.dir)

class FolderContentsResponse(PeerMessage):
    """ Peer tells us the contents of a particular folder (with all subfolders)
    """ 
    def __init__(self, conn):
	self.conn = conn

    def parseNetworkMessage(self, message):
	message = zlib.decompress(message)

        list={}
        len, nfolders = self.getObject(message,types.IntType)
	for h in range(nfolders):
	    len, folder = self.getObject(message,types.StringType, len)
	    list[folder]={}
	    len, ndir = self.getObject(message,types.IntType, len)

            for i in range(ndir):
                len, dir = self.getObject(message,types.StringType, len)
                len, nfiles = self.getObject(message,types.IntType, len)
                list[folder][dir] = []
                for j in range(nfiles):
                    len, code = len+1, message[len]
                    len, name = self.getObject(message,types.StringType, len)
                    len, size = self.getObject(message,types.IntType, len)
                    len, ext = self.getObject(message,types.StringType, len)
                    len, numattr = self.getObject(message, types.IntType, len)
                    attrs = []
                    for k in range(numattr):
                        len, attrnum = self.getObject(message,types.IntType, len)
                        len, attr = self.getObject(message,types.IntType, len)
                        attrs.append(attr)
                    list[folder][dir].append([code,name,size,ext,attrs])
        self.list = list



class FileRequest(PeerMessage):
    """ Request a file from peer, or tell a peer that we want to send a file to
    them. """
    def __init__(self,conn, direction = None, req = None, remotereq = None, filename = None, filesize = None):
	self.conn = conn
	self.direction = direction
	self.req = req
	self.remotereq = remotereq
	self.filename = filename
	self.filesize = filesize

    def makeNetworkMessage(self):
	msg = self.packObject(self.direction)+self.packObject(self.req)+self.packObject(self.remotereq)+self.packObject("")+self.packObject(self.filename)
	if self.direction == 1:
	    msg = msg + self.packObject(self.filesize)
	return msg

class FileResponse(PeerMessage):
    """ Response to the FileRequest - either we (or other peer) agrees, or 
    tells the reason for rejecting filetransfer. """
    def __init__(self,conn, allowed, reason = None, req = None, offset=None):
	self.conn = conn
	self.allowed = allowed
	self.reason = reason
	self.req = req
	self.offset = offset

    def makeNetworkMessage(self):
	if self.allowed ==0:
	     return chr(self.allowed)+self.packObject(self.reason)
	else:
	     return chr(self.allowed)+self.packObject(self.req)+self.packObject(self.offset)
    
