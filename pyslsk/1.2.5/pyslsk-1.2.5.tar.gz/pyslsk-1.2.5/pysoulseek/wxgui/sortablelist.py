# Copyright (c) 2001-2003 Alexander Kanavin. All rights reserved.

"""
This module contains the class for sortable list.
"""

import images
from wxPython.wx import *
import types
import locale

class sortableListCtrl(wxListCtrl):
    def __init__(self, parent, id, style):
        wxListCtrl.__init__(self,parent,id,style = style)
	self.sortcol = -1
	self.sortorder = 1

        self.imglist = wxImageList(18,18)
        self.up = self.imglist.Add(images.getUpBitmap())
        self.down = self.imglist.Add(images.getDownBitmap())
        self.AssignImageList(self.imglist,wxIMAGE_LIST_SMALL)

	EVT_LIST_COL_CLICK(self, self.GetId(), self.OnColClick)

    def OnColClick(self,evt):
	if evt.GetColumn() == -1:
	    return
	if self.sortcol != -1:
	    self.ClearColumnImage(self.sortcol)
	if evt.GetColumn() == self.sortcol:
	    self.sortorder = not self.sortorder
	else:
	    self.sortorder = 1
	self.sortcol = evt.GetColumn()
	if self.sortorder:
	    img = self.up
	else:
	    img = self.down
	self.SetColumnImage(self.sortcol,img)
	self.SortList(self.sortcol,self.sortorder)

    def SortList(self, col, order):
	return

    def cmp(self, item1, item2):
	if (type(item1) is types.UnicodeType or type(item1) is types.StringType) and type(item1) == type(item2):
	    return locale.strcoll(item1,item2)
	else:
	    return cmp(item1, item2)

