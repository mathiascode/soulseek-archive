# Copyright (c) 2001-2002 Alexander Kanavin. All rights reserved.

"""
This module contains GUI classes for displaying search results.
"""

import time
import slskproto
import slskmessages
import transfers
import Queue
import threading
import images
import about
import userinfobrowse
import search
from wxPython.wx import *
from config import *

class SearchWindow(wxPanel):
    """ A search window with notebook that contains search results.
    searches contains pointers to windows that display them."""
    def __init__(self, parent, id, queue, chat, info, browse, transfers):
        wxPanel.__init__(self, parent, id)
        self.queue = queue
        self.chat = chat
        self.info = info
        self.browse = browse
        self.transfers = transfers
        self.search =  wxTextCtrl(self,-1, style = wxTE_PROCESS_ENTER)
        self.searchbutton = wxButton(self, -1, "Search")
        self.resultsnb = wxNotebook(self, -1, style = wxCLIP_CHILDREN)
        sizerh = wxBoxSizer(wxHORIZONTAL)
        sizerh.Add(self.search,1,wxEXPAND)
        sizerh.Add(self.searchbutton,0,wxEXPAND)
        sizerv = wxBoxSizer(wxVERTICAL)
        sizerv.Add(sizerh,0,wxEXPAND)
        sizerv.Add(self.resultsnb,1,wxEXPAND)

        self.SetSizer(sizerv)
        self.SetAutoLayout(true)

        EVT_BUTTON(self, self.searchbutton.GetId(), self.OnSearch)
        EVT_TEXT_ENTER(self,self.search.GetId(), self.OnSearch)

        self.searches = {}

    def OnSearch(self, event):
        """ Process search request"""
        text = self.search.GetLineText(0)
        roomid = self.chat.roomid
        requestid = wxNewId()
        self.searches[requestid] = (None,text)
        self.queue.put(slskmessages.FileSearchRoom(requestid,roomid,text))
        self.search.Clear()

    def ShowResult(self, msg, username):
        """ Show search result. Create a notebook tab if necessary."""
        if self.searches.has_key(msg.token):
            if self.searches[msg.token][0] is None:
                text = self.searches[msg.token][1]
                tab, list = self.MakeSearchTab()
                self.searches[msg.token] = (list, text)
                self.resultsnb.AddPage(tab,text)
            self.searches[msg.token][0].AddResult(msg, username)

    def MakeSearchTab(self):
        """ Create a result window, which is a notebook tab. """
        panel = wxPanel(self.resultsnb, -1)
        close = wxButton(panel, -1, "Close")
        list = SearchList(panel, -1, self.chat.users, self.chat.ProcessRequestToPeer, self.chat.privatechat, self.info, self.browse, self.transfers)
        sizerh = wxBoxSizer(wxHORIZONTAL)
        sizerh.Add(60,10,1,wxEXPAND)
        sizerh.Add(close)
        sizerv = wxBoxSizer(wxVERTICAL)
        sizerv.Add(sizerh,0,wxEXPAND)
        sizerv.Add(list,1,wxEXPAND)
        panel.SetSizer(sizerv)
        panel.SetAutoLayout(true)
        EVT_BUTTON(self, close.GetId(), self.OnClose)
        return panel,list

    def OnClose(self, event):
        """ Close the search results window."""
        selectednum = self.resultsnb.GetSelection()
        selected = self.resultsnb.GetPage(selectednum)
        for i in self.searches.keys():
            if self.searches[i][0] is not None and self.searches[i][0].GetParent() == selected:
                self.searches[i] = (None,self.searches[i][1])
        self.resultsnb.DeletePage(selectednum)
        self.resultsnb.SetSelection(0)

    def ChangeAttrs(self, user):
        """ User's status has changed, update the search results."""
        for i in self.searches.keys():
            if self.searches[i][0] is not None:
                self.searches[i][0].ChangeAttrs(user)

class SearchList(wxListCtrl):
    """ List of search results."""
    def __init__(self, parent, id, users, processrequest, privatechat, info, browse, transfers,style = wxLC_REPORT|wxLC_VIRTUAL|wxLC_VRULES|wxSUNKEN_BORDER):
        wxListCtrl.__init__(self,parent,id,style = style)
        self.InsertColumn(0,"Filename", width=250)
        self.InsertColumn(1,"User", width = 100)
        self.InsertColumn(2,"Size",width=100)
        self.InsertColumn(3,"Attributes",width=150)
        self.InsertColumn(4,"Directory",width=200)
        self.SetItemCount(0)

        self.normal = wxListItemAttr()
        self.normal.SetTextColour("black")
        self.grey = wxListItemAttr()
        self.grey.SetTextColour("grey")
        self.red = wxListItemAttr()
        self.red.SetTextColour("red")

        self.parent = parent
        self.users = users
        self.processrequest = processrequest
        self.privatechat = privatechat
        self.info = info
        self.browse = browse
        self.transfers = transfers

        self.results = []

        self.menu = wxMenu()
        downloadID=wxNewId()
        self.menu.Append(downloadID, 'Download File')
        EVT_MENU(self,downloadID, self.OnDownload)
        downloadfolderID=wxNewId()
        self.menu.Append(downloadfolderID, 'Download Containing Folder')
        EVT_MENU(self,downloadfolderID, self.OnDownloadFolder)
        sendmessageID=wxNewId()
        self.menu.Append(sendmessageID, 'Send Message')
        EVT_MENU(self,sendmessageID, self.OnSendMessage)
        getinfoID=wxNewId()
        self.menu.Append(getinfoID, 'Get User Info')
        EVT_MENU(self,getinfoID, self.OnGetInfo)
        browseID=wxNewId()
        self.menu.Append(browseID, 'Browse Files')
        EVT_MENU(self,browseID, self.OnBrowse)

        EVT_LIST_ITEM_RIGHT_CLICK(self, -1,self.OnRightClick)
        EVT_RIGHT_UP(self,self.OnRightUp)

    def OnRightClick(self,event):
        """ Saves name of a user in a lisr on a right-click."""
        self.id = event.GetIndex()
        self.SetItemState(self.id,wxLIST_STATE_FOCUSED,wxLIST_STATE_FOCUSED)

    def OnRightUp(self,event):
        """ Pops up a menu on a right-click in users list."""
        self.PopupMenu(self.menu, wxPoint(event.GetX(),event.GetY()))

    """ Handlers for the menu items"""
    def OnSendMessage(self, event):
        self.privatechat.SendMessage(self.results[self.id][1])

    def OnGetInfo(self, event):
        self.processrequest(self.results[self.id][1], slskmessages.UserInfoRequest(None), self.info)

    def OnBrowse(self, event):
        self.processrequest(self.results[self.id][1], slskmessages.GetSharedFileList(None), self.browse)

    def OnDownload(self, event):
        self.transfers.getFile(self.results[self.id][1],self.results[self.id][4]+self.results[self.id][0])

    def OnDownloadFolder(self,event):
        self.processrequest(self.results[self.id][1], slskmessages.FolderContentsRequest(None,self.results[self.id][4]))
 
    def AddResult(self, msg, username):
        """ Add a result to the list."""
        import string
        for i in msg.list:
            s = string.split(i[1],'\\')
            name = s[-1]
            dir = i[1][:-len(name)]
            user = username
            size = '%i' %(i[2])

            if i[3] == 'mp3' and len(i[4]) == 3:
                attrs = i[4]
                if attrs[2] == 1:
                    brs = 'VBR'
                else:
                    brs = 'Bitrate'
                br = attrs[0]
                length = '%i:%02i' %(attrs[1] / 60, attrs[1] % 60)
                attributes = '%s: %i, Length: %s' %(brs,br,length)
            elif i[3] == '':
                attributes =  ""
            else:
                attributes = str(i[4])
            self.results.append([name,user,size,attributes,dir])
        self.SetItemCount(len(self.results))

    def OnGetItemText(self, item, col):
        return self.results[item][col]

    def OnGetItemAttr(self, item):
        user = self.results[item][1]
        if not self.users.has_key(user):
            return self.red
        elif self.users[user].slotsfull == 1:
            return self.grey
        else:
            return self.normal

    def ChangeAttrs(self, user):
        """ User's status has changed,  update the list. """
        for i in self.results:
            if i[1] == user:
                self.SetItemCount(len(self.results)) #should check if user is in search results


