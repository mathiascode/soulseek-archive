# Copyright (c) 2001-2003 Alexander Kanavin. All rights reserved.

"""
This module contains configuration classes for pyslsk.
"""

import ConfigParser
import string
import os.path
import os,stat
from pysoulseek import mp3
from pysoulseek import utils

from wxPython.wx import *

def encode(str):
    import locale,types
    try:
        localenc = locale.nl_langinfo(locale.CODESET)
        if type(str) is types.UnicodeType:
            return str.encode(localenc,'replace')
	else:
	    return str	
    except:
        return str



class ServerList(wxListCtrl):
    """ This is a list control that contains list of official servers """
    def __init__(self,parent,id, size, style = wxLC_REPORT|wxLC_VIRTUAL|wxSUNKEN_BORDER):
	wxListCtrl.__init__(self,parent,id, style = style, size = size)
	self.InsertColumn(0,"Description", width=250)
	self.InsertColumn(1,"Hostname",width=150)
	self.SetItemCount(0)

    def setList(self,list):
	self.SetItemCount(len(list))
	self.list = list

    def OnGetItemText(self, item,col):
	return self.list[item][col]

    def OnGetItemImage(self,item):
	return -1

class ServerChoose(wxDialog):
    """ This class defines a servers list window that is used to let user
	select one of the official servers from the list """
    def __init__(self,parent,id, title):
	wxDialog.__init__(self,parent,id,title)

	self.serverlistctrl = ServerList(self, -1, size=wxSize(420,200))
        self.ok = wxButton(self, wxID_OK, "OK")
        self.ok.SetDefault()
        self.cancel = wxButton(self, wxID_CANCEL, "Cancel")

        buttonssizer = wxBoxSizer(wxHORIZONTAL)
        buttonssizer.Add(self.ok)
        buttonssizer.Add(60,20)
        buttonssizer.Add(self.cancel)

        mainsizer = wxBoxSizer(wxVERTICAL)
        mainsizer.Add(self.serverlistctrl,flag=wxALL, border = 10)
        mainsizer.Add(buttonssizer,flag=wxALL|wxALIGN_CENTER, border = 10)
        self.SetSizer(mainsizer)
        self.SetAutoLayout(True)
        mainsizer.Fit(self)
	self.CenterOnParent()

	serverlist=utils.getServerList("http://www.slsk.org/slskinfo2")
	self.serverlistctrl.setList(serverlist)

    def getServer(self):
	item = self.serverlistctrl.GetNextItem(-1,wxLIST_NEXT_ALL,wxLIST_STATE_SELECTED)
	if item == -1:
	    return None
	else:
	    return self.serverlistctrl.list[item][1]

class UserList(wxPanel):
    def __init__(self, parent, id, size, label):
	wxPanel.__init__(self, parent, id, size=size)
	self.label = wxStaticText(self, -1, label)
	self.listbox = wxListBox(self, -1, style=wxLB_EXTENDED)
	self.removeButton = wxButton(self, -1, "Remove")
	self.addButton = wxButton(self, -1, "Add...")
	self.clearButton = wxButton(self, -1, "Clear")

	EVT_BUTTON(self, self.clearButton.GetId(), self.OnClear)
	EVT_BUTTON(self, self.removeButton.GetId(), self.OnRemove)
	EVT_BUTTON(self, self.addButton.GetId(), self.OnAdd)

	sizer = wxBoxSizer(wxVERTICAL)
	sizer.Add(self.label)
	sizer.Add(self.listbox, 1, flag=wxEXPAND)
	sizer.Add(self.removeButton, flag=wxEXPAND)
	sizer.Add(self.clearButton, flag=wxEXPAND)
	sizer.Add(self.addButton, flag=wxEXPAND|wxTOP, border=10)
	self.SetSizer(sizer)
	self.SetAutoLayout(True)
	sizer.Fit(self)
	
    def OnClear(self,event):
        self._list = []
        self.listbox.Set(self._list)

    def OnRemove(self,event):
        sel = self.listbox.GetSelections()
        list = self._list[:]
        for item in sel:
            self._list.remove(list[item])
        self.listbox.Set(self._list)

    def OnAdd(self,event):
	dlg = wxTextEntryDialog(self, "Username:", caption = "Add user to list")
	if (dlg.ShowModal() == wxID_OK):
	    user = encode(dlg.GetValue())
	    if user and not user in self._list:
		self._list.append(user)
		self.setList(self._list)
	dlg.Destroy()

    def getList(self):
        return self._list

    def setList(self, list):
        self._list = list[:]
        self._list.sort()
        self.listbox.Set(self._list)

class ColourPicker:
    def __init__(self, parent, id, title):
    	self.button = wxButton(parent, -1, title)
    	self.textctrl = wxTextCtrl(parent, -1, size=wxSize(125,25), style=wxTE_READONLY|wxTE_RICH|wxTE_MULTILINE)
    	self.button2 = wxButton(parent, -1, "Default")
	self.parent = parent
	self._value = ""
	EVT_BUTTON(parent, self.button.GetId(), self.OnClick)
	EVT_BUTTON(parent, self.button2.GetId(), self.OnClear)

    def OnClick(self, event):
    	colour = wxColourData()
    	colour.SetColour(self._value)
   	dlg = wxColourDialog(self.parent, colour)
    	if dlg.ShowModal() == wxID_OK:
    	    colour = dlg.GetColourData().GetColour()
    	    if colour:
    	        colourname = wxTheColourDatabase.FindName(colour)
    	        if colourname:
    	            self.SetValue(colourname)
    	        else:
    	            self.SetValue("#%2x%2x%2x" % (colour.Red(),colour.Green(),colour.Blue()))
    	    else:
    	        self.SetValue("")
    	dlg.Destroy()

    def OnClear(self,event):
        self.SetValue("")

    def GetValue(self):
    	return self._value

    def SetValue(self, value):
    	self._value = value
    	self.textctrl.Clear()
    	style = self.textctrl.GetDefaultStyle()
    	self.textctrl.SetDefaultStyle(wxTextAttr(value))
	self.textctrl.AppendText(value.capitalize())
	self.textctrl.SetDefaultStyle(style)

class ServerPanel(wxPanel):
    def __init__(self,parent, encodings):
	wxPanel.__init__(self, parent, -1)

        self.serverctrl = wxTextCtrl(self,-1,size=wxSize(250, 25))
        self.loginctrl = wxTextCtrl(self,-1,size=wxSize(100, 25))
        self.passwctrl = wxTextCtrl(self,-1,size=wxSize(100, 25))
#        self.serverchoose = wxButton(self, -1, "Choose...")
#        EVT_BUTTON(self,self.serverchoose.GetId(),self.OnServerChoose)
        self.enc = wxComboBox(self, -1, style = wxCB_DROPDOWN|wxCB_READONLY|wxCB_SORT,choices = encodings)
        self.enc.SetSelection(0)
        self.autoreply = wxTextCtrl(self, -1)
        self.directconn = wxCheckBox(self, -1, "I can receive direct connections")
        self.firstport = wxTextCtrl(self, -1, size=wxSize(50,25))
        self.lastport = wxTextCtrl(self, -1, size=wxSize(50,25))

        hostsizer = wxBoxSizer(wxHORIZONTAL)
        hostsizer.Add(self.serverctrl)
#        hostsizer.Add(self.serverchoose,flag=wxALIGN_CENTER)

        portsizer = wxBoxSizer(wxHORIZONTAL)
        portsizer.Add(self.firstport, flag=wxRIGHT, border=5)
        portsizer.Add(wxStaticText(self, -1, "-"),flag=wxALIGN_CENTER|wxRIGHT, border=5)
        portsizer.Add(self.lastport)

	autoreplysizer = wxBoxSizer(wxHORIZONTAL)
	autoreplysizer.Add(wxStaticText(self, -1, "Auto-reply when away:"), flag=wxALIGN_CENTER|wxRIGHT, border = 5)
	autoreplysizer.Add(self.autoreply, 1, flag=wxEXPAND)

        serversizer = wxStaticBoxSizer(wxStaticBox(self,-1,"Server settings:"),wxVERTICAL)
        serversizer.Add(wxStaticText(self, -1, "Server (if mail.slsk.org:2240 doesn't work, \ncheck http://www.sensi.org/~ak/pyslsk/ \nfor a newer client version):"),flag=wxTOP|wxLEFT, border = 10)
        serversizer.Add(hostsizer,flag=wxLEFT|wxRIGHT, border = 10)
        serversizer.Add(wxStaticText(self, -1, "Login:"),flag=wxTOP|wxLEFT, border = 10)
        serversizer.Add(self.loginctrl,flag=wxLEFT, border = 10)
        serversizer.Add(wxStaticText(self, -1, "Password:"),flag=wxTOP|wxLEFT, border = 10)
        serversizer.Add(self.passwctrl,flag=wxLEFT, border = 10)
        serversizer.Add(wxStaticText(self, -1, "Network character encoding (if not sure, choose utf-8):"),flag=wxTOP|wxLEFT, border = 10)
        serversizer.Add(self.enc,flag=wxLEFT, border = 10)
        serversizer.Add(wxStaticText(self, -1, "Listen on the first available port from this range:"),flag=wxTOP|wxLEFT, border = 10)
        serversizer.Add(portsizer,flag=wxLEFT, border = 10)
        awaysizer = wxBoxSizer(wxHORIZONTAL)
        awaysizer.Add(wxStaticText(self, -1, "Toggle status to 'away' after "),flag=wxALIGN_CENTER)
        self.autoaway = wxTextCtrl(self,-1,size=wxSize(30, 25))
        awaysizer.Add(self.autoaway)
        awaysizer.Add(wxStaticText(self, -1, " minutes of inactivity"),flag=wxALIGN_CENTER)
        serversizer.Add(awaysizer,flag=wxTOP|wxLEFT, border = 10)
	serversizer.Add(autoreplysizer,flag=wxTOP|wxLEFT|wxRIGHT|wxEXPAND, border = 10)
	serversizer.Add(self.directconn,flag=wxTOP|wxLEFT, border = 10)

	self.SetSizer(serversizer)
	self.SetAutoLayout(True)

    def OnServerChoose(self,event):
        serverchoose = ServerChoose(self,-1,"Choose server")
        val = serverchoose.ShowModal()
        if val == wxID_OK:
            server = serverchoose.getServer()
            if server is not None:
                self.serverctrl.SetValue(server)

class SharesPanel(wxPanel):
    def __init__(self,parent, configwindow):
        wxPanel.__init__(self, parent, -1)
	self.configwindow = configwindow

	self.incompletedirctrl = wxTextCtrl(self,-1,size=wxSize(250, 25))
	self.downloaddirctrl = wxTextCtrl(self,-1,size=wxSize(250, 25))
	self.uploaddirsctrl = wxListBox(self, -1, size=wxSize(250,100))
	self.incompletedirchoose = wxButton(self, -1, "Choose...")
	self.downloaddirchoose = wxButton(self, -1, "Choose...")
	self.sharedownloadctrl = wxCheckBox(self, -1, "Share download directory")
	self.uploaddiradd = wxButton(self, -1, "Add...")
	self.uploaddirrem = wxButton(self, -1, "Remove")
        self.uploaddirrescan = wxButton(self, -1, "Rescan")
	self.rescanonstartup = wxCheckBox(self, -1, "Rescan shares on startup")
	
	EVT_BUTTON(self,self.downloaddirchoose.GetId(),self.OnDownloadChoose)
	EVT_BUTTON(self,self.uploaddiradd.GetId(),self.OnUploadAdd)
	EVT_BUTTON(self,self.uploaddirrem.GetId(),self.OnUploadRem)
        EVT_BUTTON(self,self.uploaddirrescan.GetId(),self.OnUploadRescan)
	EVT_CHECKBOX(self,self.sharedownloadctrl.GetId(),self.OnShareDownload)

	incompletesizer = wxBoxSizer(wxHORIZONTAL)
        incompletesizer.Add(self.incompletedirctrl)
        incompletesizer.Add(self.incompletedirchoose,flag=wxALIGN_CENTER)
	
	downloadsizer = wxBoxSizer(wxHORIZONTAL)
        downloadsizer.Add(self.downloaddirctrl)
        downloadsizer.Add(self.downloaddirchoose,flag=wxALIGN_CENTER)
	
	uploadbuttonssizer = wxBoxSizer(wxVERTICAL)
        uploadbuttonssizer.Add(self.uploaddiradd)
        uploadbuttonssizer.Add(self.uploaddirrem)
        uploadbuttonssizer.Add(self.uploaddirrescan)

	uploadsizer = wxBoxSizer(wxHORIZONTAL)
	uploadsizer.Add(self.uploaddirsctrl)
	uploadsizer.Add(uploadbuttonssizer)

	sharessizer = wxStaticBoxSizer(wxStaticBox(self,-1,"Shares settings:"),wxVERTICAL)
	sharessizer.Add(wxStaticText(self, -1, "Incomplete file directory:"),flag=wxTOP|wxLEFT, border = 10)
	sharessizer.Add(incompletesizer,flag=wxLEFT|wxRIGHT, border = 10)
	sharessizer.Add(wxStaticText(self, -1, "Download directory:"),flag=wxTOP|wxLEFT, border = 10)
	sharessizer.Add(downloadsizer,flag=wxLEFT|wxRIGHT, border = 10)
	sharessizer.Add(self.sharedownloadctrl,flag=wxLEFT|wxTOP, border = 10)
	sharessizer.Add(wxStaticText(self, -1, "Shared directories:"),flag=wxTOP|wxLEFT, border = 10)
	sharessizer.Add(uploadsizer, flag=wxLEFT|wxRIGHT, border = 10)
	sharessizer.Add(self.rescanonstartup, flag=wxLEFT|wxRIGHT|wxBOTTOM, border = 10)

	self.needrescan = 0

	self.SetSizer(sharessizer)
	self.SetAutoLayout(True)

    def OnIncompleteChoose(self,event):
	downloadchoose = wxDirDialog(self)
	val = downloadchoose.ShowModal()
	if val == wxID_OK:
	    dir = downloadchoose.GetPath()
	    if dir is not None:
		self.incompletedirctrl.SetValue(dir)
	    if self.sharedownloadctrl.GetValue():
		self.needrescan = 1

    def OnDownloadChoose(self,event):
	downloadchoose = wxDirDialog(self)
	val = downloadchoose.ShowModal()
	if val == wxID_OK:
	    dir = downloadchoose.GetPath()
	    if dir is not None:
		self.downloaddirctrl.SetValue(dir)
	    if self.sharedownloadctrl.GetValue():
		self.needrescan = 1

    def OnShareDownload(self,event):
	self.needrescan = 1

    def OnUploadAdd(self,event):
        uploadadd = wxDirDialog(self)
        val = uploadadd.ShowModal()
        if val == wxID_OK:
            dir = uploadadd.GetPath()
            if dir is not None:
                self.uploaddirsctrl.Append(dir)
	self.needrescan = 1

    def OnUploadRem(self,event):
	num = self.uploaddirsctrl.GetSelection()
	if num>=0:
	    self.uploaddirsctrl.Delete(num)
	    self.needrescan = 1

    def OnUploadRescan(self,event):
	self.configwindow.Enable(0)
	self.rescandirs()
	self.needrescan = 0
	self.configwindow.Enable(1)

    def rescandirs(self):
	shared = []
        for i in range(self.uploaddirsctrl.Number()):
            shared.append(encode(self.uploaddirsctrl.GetString(i)))
	if self.sharedownloadctrl.GetValue():
	    shared.append(encode(self.downloaddirctrl.GetValue()))
	self.sharedfiles,self.sharedfilesstreams,self.wordindex, self.fileindex,self.sharedmtimes = utils.rescandirs(shared, self.sharedmtimes, self.sharedfiles, self.sharedfilesstreams, wxYield)


class TransfersPanel(wxPanel):
    def __init__(self,parent):
        wxPanel.__init__(self, parent, -1)

	self.uploadbandwidth = wxTextCtrl(self,-1,size=wxSize(30, 25))
        self.useuploadlimit = wxCheckBox(self, -1, "Limit upload speed to ")
        self.uploadlimit = wxTextCtrl(self, -1, size=wxSize(30,25))
        self.limittransfer = wxRadioButton(self, -1, "per transfer", style=wxRB_GROUP)
        self.limittotal = wxRadioButton(self, -1, "total for all transfers")
	self.upload_use_slots = wxCheckBox(self,-1,"Number of uploads exceeds ")
	self.upslots = wxTextCtrl(self,-1,size=wxSize(30,25))
	self.queuelimit = wxTextCtrl(self, -1, size=wxSize(30,25))
	self.totalqueue = wxCheckBox(self, -1, "Total upload queue can not exceed ")
	self.totalqueuelimit = wxTextCtrl(self,-1,size=wxSize(30,25))
	self.preferfriends = wxCheckBox(self, -1, "Let users in my list download first")
	self.friendsnolimits = wxCheckBox(self, -1, "Queue limits do not apply to friends")
	
        EVT_CHECKBOX(self,self.useuploadlimit.GetId(),self.OnUseUploadLimit)
	EVT_CHECKBOX(self,self.upload_use_slots.GetId(),self.OnUploadChoose)

	bandwidthsizer = wxBoxSizer(wxHORIZONTAL)
	bandwidthsizer.Add(wxStaticText(self, -1, "Upload speed exceeds"), flag=wxALIGN_CENTER)
	bandwidthsizer.Add(self.uploadbandwidth, flag=wxLEFT, border=10)
	bandwidthsizer.Add(wxStaticText(self, -1, " KBytes/sec"),flag=wxALIGN_CENTER)

	upslotssizer = wxBoxSizer(wxHORIZONTAL)
	upslotssizer.Add(self.upload_use_slots)
	upslotssizer.Add(self.upslots, flag=wxRIGHT, border=5)
	upslotssizer.Add(wxStaticText(self, -1, "(NOT RECOMMENDED)"), flag=wxALIGN_CENTER)

        limitsizer = wxFlexGridSizer(cols=5, rows=2)
	limitsizer.Add(self.useuploadlimit, border = 10)
        limitsizer.Add(self.uploadlimit, border = 10)
        limitsizer.Add(wxStaticText(self, -1, " KBytes/sec "), flag = wxALIGN_CENTER_VERTICAL)
        limitsizer.Add(self.limittransfer)
	limitsizer.Add(0,0)
        limitsizer.Add(0,0)
	limitsizer.Add(0,0)
        limitsizer.Add(0,0)
        limitsizer.Add(self.limittotal)

	queuesizer = wxBoxSizer(wxHORIZONTAL)
	queuesizer.Add(wxStaticText(self, -1, "A user may queue a maximum of "),flag=wxALIGN_CENTER)
	queuesizer.Add(self.queuelimit)
	queuesizer.Add(wxStaticText(self, -1, " megabytes"),flag=wxALIGN_CENTER)

	totalqueuesizer = wxBoxSizer(wxHORIZONTAL)
	totalqueuesizer.Add(self.totalqueue)
	totalqueuesizer.Add(self.totalqueuelimit)
	totalqueuesizer.Add(wxStaticText(self, -1, " megabytes"),flag=wxALIGN_CENTER)
	
	transferssizer = wxStaticBoxSizer(wxStaticBox(self,-1,"Transfers settings:"),wxVERTICAL)
	transferssizer.Add(wxStaticText(self, -1, "Locally queue uploads if:"),flag=wxTOP|wxLEFT, border = 10)
	transferssizer.Add(bandwidthsizer,flag=wxLEFT, border = 10)
	transferssizer.Add(upslotssizer,flag=wxBOTTOM|wxLEFT, border = 10)
	transferssizer.Add(limitsizer, flag=wxLEFT|wxBOTTOM, border = 10)
	transferssizer.Add(queuesizer, flag=wxLEFT, border = 10)
	transferssizer.Add(totalqueuesizer, flag=wxLEFT|wxBOTTOM, border = 10)
	transferssizer.Add(self.preferfriends, flag=wxLEFT, border = 10)
	transferssizer.Add(self.friendsnolimits, flag=wxLEFT|wxBOTTOM, border = 10)

	self.SetSizer(transferssizer)
	self.SetAutoLayout(True)

    def OnUseUploadLimit(self,event):
        enabled = self.useuploadlimit.GetValue()
        self.uploadlimit.Enable(enabled)
        self.limittransfer.Enable(enabled)
        self.limittotal.Enable(enabled)

    def OnUploadChoose(self,event):
	self.upslots.Enable(self.upload_use_slots.GetValue())


class UserinfoPanel(wxPanel):
    def __init__(self,parent):
        wxPanel.__init__(self, parent, -1)

	self.descr = wxTextCtrl(self,-1,size=wxSize(250,100),style = wxTE_MULTILINE|wxTE_RICH)
	self.pic = wxTextCtrl(self,-1,size=wxSize(250, 25))
	self.picchoose = wxButton(self, -1, "Choose...")
	EVT_BUTTON(self,self.picchoose.GetId(),self.OnPicChoose)

	picsizer = wxBoxSizer(wxHORIZONTAL)
	picsizer.Add(self.pic)
	picsizer.Add(self.picchoose,flag=wxALIGN_CENTER)

	userinfosizer = wxStaticBoxSizer(wxStaticBox(self,-1,"Personal settings:"),wxVERTICAL)
	userinfosizer.Add(wxStaticText(self, -1, "Self-description:"),flag=wxTOP|wxLEFT, border = 10)
	userinfosizer.Add(self.descr,1,flag=wxLEFT|wxRIGHT, border = 10)
	userinfosizer.Add(wxStaticText(self, -1, "Picture:"),flag=wxTOP|wxLEFT, border = 10)
	userinfosizer.Add(picsizer,flag=wxLEFT|wxBOTTOM, border = 10)

	self.SetSizer(userinfosizer)
	self.SetAutoLayout(True)

    def OnPicChoose(self,event):
	picchoose = wxFileDialog(self)
	val = picchoose.ShowModal()
	if val == wxID_OK:
            pic = picchoose.GetPath()
            if pic is not None:
                self.pic.SetValue(pic)


class UiPanel(wxPanel):
    def __init__(self,parent):
        wxPanel.__init__(self, parent, -1)
        
	self.colourchatremote = ColourPicker(self, -1, "Remote text:")
	self.colourchatlocal = ColourPicker(self, -1, "Local text:")
	self.colourchatme = ColourPicker(self, -1, "/me text:")
	self.colourhighlight = ColourPicker(self, -1, "Highlight colour:")
	self.coloursearchnoqueue = ColourPicker(self, -1, "Without queue:")
	self.coloursearchqueue = ColourPicker(self, -1, "With queue:")
	self.decimalsep = wxComboBox(self, -1, style=wxCB_DROPDOWN|wxCB_READONLY, choices = ["<none>", ",", ".", "<space>"])
	self.afterdownload = wxTextCtrl(self, -1)
	self.afterfolder = wxTextCtrl(self, -1)

	uisizer=wxStaticBoxSizer(wxStaticBox(self,-1,"Colours:"),wxVERTICAL)
	uisizer.Add(wxStaticText(self,-1,"Chat colours:"), flag=wxLEFT|wxTOP, border = 10)
	chatcoloursgrid = wxFlexGridSizer(cols=3, vgap=2, hgap=5)
	for i in self.colourchatremote, self.colourchatlocal, self.colourchatme, self.colourhighlight:
	    chatcoloursgrid.Add(i.button, flag=wxEXPAND)
	    chatcoloursgrid.Add(i.textctrl)
	    chatcoloursgrid.Add(i.button2)
	uisizer.Add(chatcoloursgrid, flag=wxEXPAND|wxLEFT, border=15)
	uisizer.Add(wxStaticText(self,-1,"Search result colours:"),flag=wxLEFT|wxTOP, border=10)
	searchcoloursgrid = wxFlexGridSizer(cols=3,vgap=2,hgap=5)
	for i in self.coloursearchnoqueue, self.coloursearchqueue:
	    searchcoloursgrid.Add(i.button, flag=wxEXPAND)
	    searchcoloursgrid.Add(i.textctrl)
	    searchcoloursgrid.Add(i.button2)
	uisizer.Add(searchcoloursgrid, flag=wxEXPAND|wxLEFT, border=15)
	decimalsepsizer = wxBoxSizer(wxHORIZONTAL)
	decimalsepsizer.Add(wxStaticText(self, -1, "Decimal separator:"), flag=wxALIGN_CENTER|wxRIGHT, border = 5)
	decimalsepsizer.Add(self.decimalsep)
	uisizer.Add(decimalsepsizer, flag=wxTOP|wxLEFT|wxBOTTOM, border=10)
	
	commandsizer = wxBoxSizer(wxVERTICAL)
	commandsizer.Add(wxStaticText(self, -1, "Run command after download finishes ($ for filename):"))
	commandsizer.Add(self.afterdownload, flag=wxEXPAND)
	uisizer.Add(commandsizer, flag=wxALL|wxEXPAND, border=10)
	
	commanddsizer = wxBoxSizer(wxVERTICAL)
	commanddsizer.Add(wxStaticText(self, -1, "Run command after folder finishes ($ for folder path):"))
	commanddsizer.Add(self.afterfolder, flag=wxEXPAND)
	uisizer.Add(commanddsizer, flag=wxALL|wxEXPAND, border=10)

	self.SetSizer(uisizer)
	self.SetAutoLayout(True)


class MiscPanel(wxPanel):
    def __init__(self,parent):
        wxPanel.__init__(self, parent, -1)

	self.logsdirctrl = wxTextCtrl(self,-1,size=wxSize(250, 25))
	self.logsdirchoose = wxButton(self, -1, "Choose...")
	EVT_BUTTON(self,self.logsdirchoose.GetId(),self.OnLogsChoose)
	logssizer = wxBoxSizer(wxHORIZONTAL)
        logssizer.Add(self.logsdirctrl)
        logssizer.Add(self.logsdirchoose,flag=wxALIGN_CENTER)
	
        miscsizer=wxStaticBoxSizer(wxStaticBox(self,-1,"Misc settings:"),wxVERTICAL)
	self.loggingprivatectrl = wxCheckBox(self, -1, "Log private chat by default")
        miscsizer.Add(self.loggingprivatectrl, flag = wxLEFT|wxTOP, border = 10)
        self.loggingchatctrl = wxCheckBox(self, -1, "Log chatrooms by default")
        miscsizer.Add(self.loggingchatctrl, flag = wxLEFT, border = 10)
	miscsizer.Add(wxStaticText(self, -1, "Logs directory:"),flag=wxLEFT, border = 10)
	miscsizer.Add(logssizer,flag=wxLEFT, border = 10)
	
	resultssizer = wxBoxSizer(wxHORIZONTAL)
        resultssizer.Add(wxStaticText(self, -1, "Return the max of "),flag=wxALIGN_CENTER)
	self.maxresults = wxTextCtrl(self,-1,size=wxSize(30, 25))
        resultssizer.Add(self.maxresults)
        resultssizer.Add(wxStaticText(self, -1, " results per search request"),flag=wxALIGN_CENTER)
	miscsizer.Add(resultssizer,flag=wxTOP|wxLEFT, border = 10)

        self.re_filter = wxCheckBox(self, -1, "Use regexps for filter in/out")
        miscsizer.Add(self.re_filter, flag = wxLEFT|wxTOP, border = 10)

	self.banlist = UserList(self, -1, wxSize(150,0), "Banned users:")
	self.ignorelist = UserList(self, -1, wxSize(150,0), "Ignored users:")
	badpeoplesizer = wxBoxSizer(wxHORIZONTAL)
	badpeoplesizer.Add(self.banlist, 1, flag=wxALIGN_CENTER|wxTOP|wxEXPAND, border=15)
	badpeoplesizer.Add(self.ignorelist, 1, flag=wxALIGN_CENTER|wxTOP|wxEXPAND, border=15)
	miscsizer.Add(badpeoplesizer, 1, flag=wxALIGN_CENTER|wxTOP|wxEXPAND, border=5 )

	custombansizer = wxBoxSizer(wxHORIZONTAL)
	self.usecustomban = wxCheckBox(self, -1, "Use custom ban message:")
	custombansizer.Add(self.usecustomban)
	self.customban = wxTextCtrl(self, -1)
	custombansizer.Add(self.customban, 1, flag=wxEXPAND|wxLEFT, border=5)
	miscsizer.Add(custombansizer, flag=wxLEFT|wxTOP|wxEXPAND|wxRIGHT, border=10)

	self.SetSizer(miscsizer)
        self.SetAutoLayout(True)

    def OnLogsChoose(self,event):
        logschoose = wxDirDialog(self)
        val = logschoose.ShowModal()
        if val == wxID_OK:
            dir = logschoose.GetPath()
            if dir is not None:
                self.logsdirctrl.SetValue(dir)


class ConfigWindow(wxDialog):
    """
    This class defines a settings window that the main application should 
    display on request. 

    Methods:
    SetSettings(config) - fills widgets in the window 
    with provided values
    GetSettings - returns a tuple of settings from window widgets (possibly 
    modified by user
    """
    def __init__(self, parent, id, title):
	wxDialog.__init__(self,parent,id,title)

	self.parent = parent
	nb = wxNotebook(self, -1)
	nbs = wxNotebookSizer(nb)
	self.serverpanel = ServerPanel(nb, parent.np.getencodings())
	self.sharespanel = SharesPanel(nb, self)
	self.transferspanel = TransfersPanel(nb)
	self.userinfopanel = UserinfoPanel(nb)
	self.uipanel = UiPanel(nb)
	self.miscpanel = MiscPanel(nb)
	nb.AddPage(self.serverpanel,"Server")
	nb.AddPage(self.sharespanel,"Shares")
	nb.AddPage(self.transferspanel,"Transfers")
	nb.AddPage(self.userinfopanel,"User info")
	nb.AddPage(self.uipanel,"Bloat")
	nb.AddPage(self.miscpanel,"Misc")



	self.ok = wxButton(self, wxID_OK, "OK")
	self.ok.SetDefault()
	self.cancel = wxButton(self, wxID_CANCEL, "Cancel")

	buttonssizer = wxBoxSizer(wxHORIZONTAL)
	buttonssizer.Add(self.ok)
	buttonssizer.Add(60,20)
	buttonssizer.Add(self.cancel)

	mainsizer = wxBoxSizer(wxVERTICAL)
	mainsizer.Add(nbs,flag=wxALL,border=5)
	mainsizer.Add(buttonssizer,flag=wxALL|wxALIGN_CENTER, border = 10)
	self.SetSizer(mainsizer)
	self.SetAutoLayout(True)
	mainsizer.Fit(self)

	EVT_BUTTON(self, self.ok.GetId(),self.OnOk) 

    def OnOk(self, event):
	self.Enable(0)
	self.parent.SettingsClosed()
	self.Enable(1)
	event.Skip()

    def SetSettings(self, config):
	server = config.sections["server"]
	transfers = config.sections["transfers"]
	userinfo = config.sections["userinfo"]
        logging = config.sections["logging"]
	searches = config.sections["searches"]
	ui = config.sections["ui"]
	if server["server"] is not None:
    	    self.serverpanel.serverctrl.SetValue(string.join([str(i) for i in server["server"]],":"))
	if server["login"] is not None:
	    self.serverpanel.loginctrl.SetValue(server["login"])
	if server["passw"] is not None:
	    self.serverpanel.passwctrl.SetValue(server["passw"])
	if server["enc"] is not None:
	    self.serverpanel.enc.SetValue(server["enc"])
	if server["banlist"] is not None:
	    self.miscpanel.banlist.setList(server["banlist"])
	if server["ignorelist"] is not None:
	    self.miscpanel.ignorelist.setList(server["ignorelist"])
	if server["portrange"] is not None:
	    self.serverpanel.firstport.SetValue(str(server["portrange"][0]))
	    self.serverpanel.lastport.SetValue(str(server["portrange"][1]))
	if server["autoaway"] is not None:
	    self.serverpanel.autoaway.SetValue(str(server["autoaway"]))
	if server["autoreply"] is not None:
	    self.serverpanel.autoreply.SetValue(server["autoreply"])
	if server["firewalled"] is not None:
	    self.serverpanel.directconn.SetValue(not server["firewalled"])
	if transfers["incompletedir"] is not None:
	    self.sharespanel.incompletedirctrl.SetValue(transfers["incompletedir"])
	if transfers["downloaddir"] is not None:
	    self.sharespanel.downloaddirctrl.SetValue(transfers["downloaddir"])
	if transfers["shared"] is not None:
	    self.sharespanel.uploaddirsctrl.Clear()
	    for i in transfers["shared"]:
		self.sharespanel.uploaddirsctrl.Append(i)
	if transfers["sharedfiles"] is not None:
	    self.sharespanel.sharedfiles = transfers["sharedfiles"]
	if transfers["sharedfilesstreams"] is not None:
	    self.sharespanel.sharedfilesstreams = transfers["sharedfilesstreams"]
	if transfers["wordindex"] is not None:
	    self.sharespanel.wordindex = transfers["wordindex"]
        if transfers["fileindex"] is not None:
            self.sharespanel.fileindex = transfers["fileindex"]
        if transfers["sharedmtimes"] is not None:
            self.sharespanel.sharedmtimes = transfers["sharedmtimes"]
	if transfers["rescanonstartup"] is not None:
	    self.sharespanel.rescanonstartup.SetValue(transfers["rescanonstartup"])
	if transfers["uploadbandwidth"] is not None:
	    self.transferspanel.uploadbandwidth.SetValue(str(transfers["uploadbandwidth"]))
	if transfers["uselimit"] is not None:
	    self.transferspanel.useuploadlimit.SetValue(transfers["uselimit"])
	if transfers["uploadlimit"] is not None:
	    self.transferspanel.uploadlimit.SetValue(str(transfers["uploadlimit"]))
	if transfers["limitby"] is not None:
	    self.transferspanel.limittotal.SetValue(transfers["limitby"])
	self.transferspanel.OnUseUploadLimit(None)
	if transfers["sharedownloaddir"] is not None:
	    self.sharespanel.sharedownloadctrl.SetValue(transfers["sharedownloaddir"])
	if transfers["queuelimit"] is not None:
	    self.transferspanel.queuelimit.SetValue(str(transfers["queuelimit"]))
	if transfers["totalqueue"] is not None:
	    self.transferspanel.totalqueue.SetValue(transfers["totalqueue"])
	if transfers["totalqueuelimit"] is not None:
	    self.transferspanel.totalqueuelimit.SetValue(str(transfers["totalqueuelimit"]))
        if transfers["friendsnolimits"] is not None:
            self.transferspanel.friendsnolimits.SetValue(transfers["friendsnolimits"])
	if transfers["usecustomban"] is not None:
	    self.miscpanel.usecustomban.SetValue(transfers["usecustomban"])
	if transfers["customban"] is not None:
	    self.miscpanel.customban.SetValue(transfers["customban"])
	if transfers["preferfriends"] is not None:
	    self.transferspanel.preferfriends.SetValue(transfers["preferfriends"])
	if transfers["uploadslots"] is not None:
	    self.transferspanel.upslots.SetValue(str(transfers["uploadslots"]))
	if transfers["useupslots"] is not None:
	    self.transferspanel.upload_use_slots.SetValue(transfers["useupslots"]);
        self.transferspanel.OnUploadChoose(None)
        if transfers["afterfinish"] is not None:
            self.uipanel.afterdownload.SetValue(transfers["afterfinish"])
        if transfers["afterfolder"] is not None:
            self.uipanel.afterfolder.SetValue(transfers["afterfolder"])
	if userinfo["descr"] is not None:
	    self.userinfopanel.descr.SetValue(eval(userinfo["descr"]))
	if userinfo["pic"] is not None:
	    self.userinfopanel.pic.SetValue(userinfo["pic"])
	if logging["logsdir"] is not None:
	    self.miscpanel.logsdirctrl.SetValue(logging["logsdir"])
        if logging["privatechat"] is not None:
            self.miscpanel.loggingprivatectrl.SetValue(logging["privatechat"])
        if logging["chatrooms"] is not None:
            self.miscpanel.loggingchatctrl.SetValue(logging["chatrooms"])
	if searches["maxresults"] is not None:
	    self.miscpanel.maxresults.SetValue(str(searches["maxresults"]))
	if searches["re_filter"] is not None:
	    self.miscpanel.re_filter.SetValue(searches["re_filter"])
	if ui["chatremote"] is not None:
	    self.uipanel.colourchatremote.SetValue(ui["chatremote"])
	if ui["chatlocal"] is not None:
	    self.uipanel.colourchatlocal.SetValue(ui["chatlocal"])
	if ui["chatme"] is not None:
	    self.uipanel.colourchatme.SetValue(ui["chatme"])
	if ui["chatme"] is not None:
	    self.uipanel.colourhighlight.SetValue(ui["chathilite"])
	if ui["search"] is not None:
	    self.uipanel.coloursearchnoqueue.SetValue(ui["search"])
	if ui["searchq"] is not None:
	    self.uipanel.coloursearchqueue.SetValue(ui["searchq"])
	if ui["decimalsep"] is not None:
	    self.uipanel.decimalsep.SetValue(ui["decimalsep"])


    def GetSettings(self):
        try:
            server = string.split(encode(self.serverpanel.serverctrl.GetValue()),":")
            server[1] = int(server[1])
	    server = tuple(server)
        except:
            server = None
	try:
	    autoaway = int(encode(self.serverpanel.autoaway.GetValue()))
	except:
	    autoaway = None
	shared = []
	for i in range(self.sharespanel.uploaddirsctrl.Number()):
	    shared.append(encode(self.sharespanel.uploaddirsctrl.GetString(i)))
	if self.sharespanel.needrescan:
	    self.sharespanel.rescandirs()
	    self.sharespanel.needrescan = 0 
	try:
	    uploadbandwidth = int(encode(self.transferspanel.uploadbandwidth.GetValue()))
	except:
	    uploadbandwidth = None
	try:
	    uploadlimit = int(encode(self.transferspanel.uploadlimit.GetValue()))
	except:
	    uploadlimit = None
        try:
	    queuelimit = int(encode(self.transferspanel.queuelimit.GetValue()))
	except:
	    queuelimit = None
        try:
	    totalqueuelimit = int(encode(self.transferspanel.totalqueuelimit.GetValue()))
	except:
	    totalqueuelimit = None
	try:
	    maxresults = int(encode(self.miscpanel.maxresults.GetValue()))
	except:
	    maxresults = None
	try:
	    firstport = int(encode(self.serverpanel.firstport.GetValue()))
	    lastport = int(encode(self.serverpanel.lastport.GetValue()))
	    if firstport < 1:
	        firstport = 2234
	    if lastport < firstport:
	        lastport = firstport
	    portrange = (firstport, lastport)
	except:
	    portrange = (2234, 2239)
 	try:
	    uploadslots = int(encode(self.transferspanel.upslots.GetValue()))
	except:
	    uploadslots = None
	useupslots = encode(self.transferspanel.upload_use_slots.GetValue())
	banlist = []
	for i in self.miscpanel.banlist.getList():
	    banlist.append(encode(i))
	ignorelist = []
	for i in self.miscpanel.ignorelist.getList():
	    ignorelist.append(encode(i))
	return {"server":{"server":server, \
		"login":encode(self.serverpanel.loginctrl.GetValue()), \
		"passw":encode(self.serverpanel.passwctrl.GetValue()), \
		"banlist":banlist, \
		"ignorelist":ignorelist, \
		"portrange":portrange, \
		"autoaway":autoaway, \
		"firewalled":not self.serverpanel.directconn.GetValue(), \
		"autoreply":encode(self.serverpanel.autoreply.GetValue()), \
		"enc":encode(self.serverpanel.enc.GetValue())},"transfers":{\
		"incompletedir":encode(self.sharespanel.incompletedirctrl.GetValue()), \
		"downloaddir":encode(self.sharespanel.downloaddirctrl.GetValue()), \
		"shared":shared, "sharedfiles":self.sharespanel.sharedfiles, \
		"sharedfilesstreams":self.sharespanel.sharedfilesstreams, \
		"fileindex":self.sharespanel.fileindex, \
                "wordindex":self.sharespanel.wordindex, \
	        "sharedmtimes":self.sharespanel.sharedmtimes, \
		"rescanonstartup":encode(self.sharespanel.rescanonstartup.GetValue()),\
		"uploadbandwidth":uploadbandwidth, \
		"uploadslots":uploadslots, \
		"useupslots":useupslots, \
		"afterfinish":encode(self.uipanel.afterdownload.GetValue()), \
		"afterfolder":encode(self.uipanel.afterfolder.GetValue()), \
		"preferfriends":encode(self.transferspanel.preferfriends.GetValue()), \
		"uselimit":encode(self.transferspanel.useuploadlimit.GetValue()), \
		"totalqueue":encode(self.transferspanel.totalqueue.GetValue()), \
		"totalqueuelimit":totalqueuelimit, \
		"friendsnolimits":encode(self.transferspanel.friendsnolimits.GetValue()), \
		"usecustomban":encode(self.miscpanel.usecustomban.GetValue()), \
		"customban":encode(self.miscpanel.customban.GetValue()), \
		"uploadlimit":uploadlimit, "queuelimit":queuelimit, \
		"limitby":encode(self.transferspanel.limittotal.GetValue()), \
		"sharedownloaddir":encode(self.sharespanel.sharedownloadctrl.GetValue())},"userinfo": \
		{"descr":encode(self.userinfopanel.descr.GetValue()).__repr__(), \
		"pic":encode(self.userinfopanel.pic.GetValue())},"logging":{ \
		"logsdir":encode(self.miscpanel.logsdirctrl.GetValue()), \
		"privatechat":encode(self.miscpanel.loggingprivatectrl.GetValue()), \
		"chatrooms":encode(self.miscpanel.loggingchatctrl.GetValue())},
		"searches":{"maxresults":maxresults,"re_filter":self.miscpanel.re_filter.GetValue()}, \
		"ui":{"chatremote":encode(self.uipanel.colourchatremote.GetValue()), \
		"chatlocal":encode(self.uipanel.colourchatlocal.GetValue()), \
		"chatme":encode(self.uipanel.colourchatme.GetValue()), \
		"chathilite":encode(self.uipanel.colourhighlight.GetValue()), \
		"search":encode(self.uipanel.coloursearchnoqueue.GetValue()), \
		"searchq":encode(self.uipanel.coloursearchqueue.GetValue()),
		"decimalsep":encode(self.uipanel.decimalsep.GetValue())}}
