[ x"$DC" = x"" ] && DC=gdc

BINDIR=../bin
SRCDIR=src


cd ${SRCDIR}
${DC} *.d -o${BINDIR}/soulfind -lsqlite3 $@
