# Copyright (c) 2001-2003 Alexander Kanavin. All rights reserved.

"""
This is the actual client code. Actual GUI classes are in the separate modules
"""

import time
from pysoulseek import slskproto
from pysoulseek import slskmessages
from pysoulseek.pysoulseek import *
from pysoulseek import utils
import Queue
import threading
import images
import about
import userinfobrowse
import search
import chat
import transfers
import userlist
import notebook
import buttonsplitter
from wxPython.wx import *
from configwindow import *

class NetworkEvent(wxPyEvent):
    """
    Special event that occurs when networking thread sends us some messages.
    msgs is a list of them.
    """
    def __init__(self,id,msgs):
	wxPyEvent.__init__(self)
	self.SetEventType(id)
	self.msgs = msgs

class SigChecker(wxTimer):
    def __init__(self, frame):
	wxTimer.__init__(self)
	self.frame = frame

    def Notify(self):
	try:
	    if self.frame.sigterm:
		self.frame.Close()
	except:
	    pass

class AwayTimer(wxTimer):
    def __init__(self, frame):
        wxTimer.__init__(self)
        self.frame = frame

    def Notify(self):
	if self.frame.np.serverconn is not None:
	    self.frame.autoaway = True
	    self.frame.away = True
            self.frame.np.queue.put(slskmessages.SetStatus(1))
            self.frame.SetStatusText("Away", 1)


class MainFrame(wxFrame):
    """ This is the very main window, with menu, status bar and notebook 
    that contains all other subwindows. Everything else is set up 
    from here""" 
    def __init__(self, parent, id, title, configfile, app): 
        wxFrame.__init__(self,parent,id,title, name=title, size = (800,600), style = wxDEFAULT_FRAME_STYLE|wxMAXIMIZE|wxNO_FULL_REPAINT_ON_RESIZE)
	self.EVT_NETWORK_ID = wxNewId()     
	self.EVT_NETWORK(self, self.EVT_NETWORK_ID, self.OnNetworkEvent)

	self.app = app

	self.transfermsgs = {}
	self.transfermsgspostedtime = time.time()

        self.np = NetworkEventProcessor(self,self.callback,self.logMessage,self.SetStatusText, configfile)
	self.away = 0
	self.manualdisconnect = 0

	self.sigterm = 0
	self.closing = 0

	# set icon here, see demo to know how
	self.SetIcon(images.getBirdIcon())

	# set task bar icon here, see demo to know how

        EVT_CLOSE(self, self.OnCloseWindow)
        self.Centre(wxBOTH)
        self.CreateStatusBar(4, wxST_SIZEGRIP)
	self.SetStatusWidths([-1, 50, 150, 150])
	self.SetStatusText("Offline", 1)
	self.updateBandwidth()

	self.configwindow = ConfigWindow(self, -1, "Settings")

        self.mainmenu = wxMenuBar()

        menu = wxMenu()
	if not self.np.config.needConfig():
	    self.serverstring =  '%s:%s'%(self.np.config.sections["server"]["server"][0],self.np.config.sections["server"]["server"][1])
	else:
	    self.serverstring = ''
	self.connectID = wxNewId()
	menu.Append(self.connectID, '&Connect\tAlt-C', 'Connect to ' + self.serverstring)
	menu.Enable(self.connectID, not self.np.config.needConfig())
        EVT_MENU(self, self.connectID, self.OnConnect)
	self.disconnectID = wxNewId()
	menu.Append(self.disconnectID, '&Disconnect\tAlt-D', 'Disconnect from ' + self.serverstring)
	menu.Enable(self.disconnectID, False)
        EVT_MENU(self, self.disconnectID, self.OnDisconnect)
	self.awayID = wxNewId()
	menu.Append(self.awayID, '&Away/Return\tAlt-A', 'Toggle Away/Online status')
	menu.Enable(self.awayID,False)
	EVT_MENU(self, self.awayID, self.OnAway)

	self.checkprivID = wxNewId()
	menu.Append(self.checkprivID, 'Check &privileges', 'Check download privileges')
	menu.Enable(self.checkprivID,False)
	EVT_MENU(self,self.checkprivID, self.OnCheckPrivileges)
	menu.AppendSeparator()
	self.debugID = wxNewId()
	menu.Append(self.debugID, 'Show de&bug info', 'Toggle the display of debug information in the log window',wxITEM_CHECK)
	
	self.settingsID = wxNewId()
	menu.Append(self.settingsID, '&Settings...', 'Set up server name, login, password')
	EVT_MENU(self, self.settingsID, self.OnSettings)
	menu.AppendSeparator()
        self.exitID = wxNewId()
        menu.Append(self.exitID, 'E&xit\tAlt-X', 'Get the heck outta here!')
        EVT_MENU(self, self.exitID, self.OnFileExit)

	
	helpmenu = wxMenu()
	aboutChatID = wxNewId()
	helpmenu.Append(aboutChatID, '&Chat room commands', 'About chat room commands')
	EVT_MENU(self,aboutChatID, self.OnAboutChatCommands)
	aboutPrivateID = wxNewId()
	helpmenu.Append(aboutPrivateID, '&Private chat commands', 'About private chat commands')
	EVT_MENU(self,aboutPrivateID, self.OnAboutPrivateCommands)
	helpmenu.AppendSeparator()
        aboutID = wxNewId()
        helpmenu.Append(aboutID, '&About', 'About PySoulSeek')
        EVT_MENU(self, aboutID, self.OnAbout)

        self.mainmenu.Append(menu, '&File')
	self.mainmenu.Append(helpmenu, '&Help')
        self.SetMenuBar(self.mainmenu)

        self.splitter = wxSplitterWindow(self, -1,style=wxSP_3DSASH)
	self.nb = notebook.IconNotebook(self.splitter, -1, style=wxCLIP_CHILDREN, frame = self)

	self.sx = self.sy = None
	
	self.log = chat.OutputWindow(self.splitter,-1,style = wxTE_MULTILINE|wxTE_READONLY|wxTE_RICH)
	
	EVT_RIGHT_UP(self.log, self.OnRightClickInLog)

        wxLog_SetActiveTarget(wxLogTextCtrl(self.log))
    
	self.splitter.SplitHorizontally(self.nb,self.log,400)	

	EVT_SIZE(self.splitter, self.OnSizeSplitter)


	self.sigchecker = SigChecker(self)
	self.sigchecker.Start(100)

	self.awaytimer = AwayTimer(self)
	self.networkevent = 0
	self.autoaway = False
	EVT_IDLE(self, self.OnIdle)

	if self.np.config.sections["transfers"]["rescanonstartup"]:
	    shared = self.np.config.sections["transfers"]["shared"][:]
	    if self.np.config.sections["transfers"]["sharedownloaddir"]:
	        shared.append(self.np.config.sections["transfers"]["downloaddir"])
            self.mainmenu.Enable(self.settingsID,0)
	    self.mainmenu.SetLabel(self.settingsID,"&Settings (scanning shares)...")
	    self.callback([slskmessages.RescanShares(shared,wxYield)])

	if not self.np.config.needConfig():
	    self.OnConnect(None)

    def RescanFinished(self):
	self.mainmenu.Enable(self.settingsID,1)
	self.mainmenu.SetLabel(self.settingsID,"&Settings...")

    def OnIdle(self, event):
	if self.networkevent > 0:
	    self.networkevent -= 1
	else:
	    timeout = self.np.config.sections["server"]["autoaway"]
	    if timeout > 0 and self.np.serverconn is not None:
		if self.away and self.autoaway:
        	    self.away = self.autoaway = False
                    self.np.queue.put(slskmessages.SetStatus(2))
                    self.SetStatusText("Online", 1)
		if not self.away:
	            self.awaytimer.Start(1000*60*timeout,True)


    def updateBandwidth(self):
	def _calc(l):
	    bandwidth = 0.0
	    users = 0 
	    for i in l:
		if i.conn is not None:
		    users = users + 1
		    if i.speed is not None:
		        bandwidth = bandwidth + i.speed
	    return users,bandwidth

	if self.np.transfers is not None:
	    usersdown, down = _calc(self.np.transfers.downloads)
	    usersup, up = _calc(self.np.transfers.uploads)
	else:
	    down = up = 0.0
	    usersdown = usersup = 0
	self.SetStatusText("Down: %i users, %.1f KB/s" % (usersdown,down), 2)
	self.SetStatusText("Up: %i users, %.1f KB/s" % (usersup,up), 3)

    def OnSizeSplitter(self,event):
	x,y = self.splitter.GetSize()
	if self.sx is None:
		self.sx = x
		self.sy = y
	self.splitter.SetSashPosition(self.splitter.GetSashPosition()+(y-self.sy))
	self.sx = x
	self.sy = y
	event.Skip()


    def OnRightClickInLog(self,event):
	""" Log window is not self-cleaning yet, unlike chat windows. Will change that when the client stabilizes."""
	menu = wxMenu()
	clearID=wxNewId()
	menu.Append(clearID, 'Clear')
	EVT_MENU(self,clearID, self.OnClearLog)
	self.log.PopupMenu(menu, wxPoint(event.GetX(),event.GetY()))
	event.Skip()

    def OnClearLog(self,event):
	self.log.Clear()

    def OnCloseWindow(self, event):
 	""" Close the window, but finish all filetransfers and stop the 
	networking thread first."""
	if not self.closing:
	    self.closing = 1
	else:
	    return
	if self.np.servertimer is not None:
	    self.np.servertimer.cancel()
	self.np.StopTimers()
	if self.np.transfers is not None:
            self.np.transfers.AbortTransfers()
	self.np.config.writeConfig()
	self.np.protothread.abort()
	while self.np.protothread.isAlive():
 	    self.app.Yield(True)
	    time.sleep(0.1)
        self.Destroy()
	self.app.Yield(True)

    """ Menu items handlers."""
    def OnFileExit(self, event):
        self.Close()

    def OnConnect(self, event):
	self.mainmenu.Enable(self.connectID,0)
	self.mainmenu.Enable(self.disconnectID,1)
	if self.np.serverconn is None:
	    server = self.np.config.sections["server"]["server"]
	    self.np.queue.put(slskmessages.ServerConn(None, server))
	    self.SetStatusText("Connecting to %s:%s" %(server[0],server[1]))
	    if self.np.servertimer is not None:
		self.np.servertimer.cancel()
		self.np.servertimer = None

    def OnDisconnect(self, event):
	self.manualdisconnect = 1
	self.np.queue.put(slskmessages.ConnClose(self.np.serverconn))

    def OnCheckPrivileges(self, event):
	self.np.queue.put(slskmessages.CheckPrivileges())

    def OnAway(self, event):
	self.away = not self.away
	self.autoaway = False
	if self.away == 1:
	    self.np.queue.put(slskmessages.SetStatus(1))
	    self.SetStatusText("Away", 1)
	else:
	    self.np.queue.put(slskmessages.SetStatus(2))
	    self.SetStatusText("Online", 1)

    def OnSettings(self, event):
	self.configwindow.SetSettings(self.np.config)
	val = self.configwindow.Show()

    def SettingsClosed(self):
	    self.mainmenu.Enable(self.settingsID,0)
	    self.mainmenu.SetLabel(self.settingsID,"&Settings (scanning shares)...")
	    settings = self.configwindow.GetSettings()
	    mtimes, files, streams, wordindex, fileindex = settings["transfers"]["sharedmtimes"],settings["transfers"]["sharedfiles"],settings["transfers"]["sharedfilesstreams"], settings["transfers"]["wordindex"], settings["transfers"]["fileindex"]
	    del settings["transfers"]["sharedmtimes"],settings["transfers"]["sharedfiles"],settings["transfers"]["sharedfilesstreams"], settings["transfers"]["wordindex"], settings["transfers"]["fileindex"]
	    self.np.config.setShares(files, streams, wordindex, fileindex, mtimes)
            for (i,j) in settings.items():
	        self.np.config.sections[i].update(j)
	    self.configwindow.SetSettings(self.np.config)
	    self.mainmenu.Enable(self.settingsID,1)
	    self.mainmenu.SetLabel(self.settingsID,"&Settings...")
	    if self.np.transfers is not None:
		self.np.sendNumSharedFoldersFiles()
	    uselimit = self.np.config.sections["transfers"]["uselimit"]
	    uploadlimit = self.np.config.sections["transfers"]["uploadlimit"]
	    limitby = self.np.config.sections["transfers"]["limitby"]
	    self.np.queue.put(slskmessages.SetUploadLimit(uselimit,uploadlimit,limitby))
	    self.np.config.writeConfig()
	    self.np.config.writeShares()
	    if not self.np.config.needConfig():
	        if not self.mainmenu.IsEnabled(self.disconnectID):
		    self.mainmenu.Enable(self.connectID,1)
		server = self.np.config.sections["server"]["server"]
	        self.serverstring = '%s:%s'%(server[0],server[1])
	        self.mainmenu.SetHelpString(self.connectID,'Connect to '+self.serverstring)
	        self.mainmenu.SetHelpString(self.disconnectID,'Disconnect from '+self.serverstring)

    def OnAbout(self, event):
	about.About(self, -1, "About PySoulSeek").ShowModal()

    def OnAboutChatCommands(self, event):
	about.AboutCommands(self, -1, "About Chat Commands").ShowModal()

    def OnAboutPrivateCommands(self, event):
	about.AboutCommands(self, -1, "About Chat Commands", True).ShowModal()

    def ConnectError(self,msg):
        self.mainmenu.Enable(self.connectID,1)
        self.mainmenu.Enable(self.disconnectID,0)
	self.mainmenu.Enable(self.checkprivID,0)
	self.mainmenu.Enable(self.awayID,0)

    def ConnClose(self,conn, addr):
	self.SetStatusText("Offline", 1)
        self.mainmenu.Enable(self.connectID,1)
        self.mainmenu.Enable(self.disconnectID,0)
        self.mainmenu.Enable(self.checkprivID,0)
        self.mainmenu.Enable(self.awayID,0)
	self.updateBandwidth()
        self.nb.DeleteAllPages()

    def logMessage(self, msg, debug = None):
	if (debug is None or self.mainmenu.IsChecked(self.debugID)):
	    wxLogMessage(msg)

    def InitInterface(self, msg):
        timeout = self.np.config.sections["server"]["autoaway"]
        if timeout > 0: 
            self.awaytimer.Start(1000*60*timeout,True)
	if self.autoaway:
	    self.autoaway = self.away = False

	self.SetStatusText("Online", 1)
        privatechat = chat.PrivateChatNotebook(self.nb, -1,self.np.queue,self.np)
        chatrooms = chat.ChatRooms(self.nb, -1,self.np.queue,privatechat,self.np.peerconns, self)
        globallist = chat.GlobalUsersList(self.nb, -1,self.np.queue,privatechat,self.np.peerconns, self)
        userinfo = userinfobrowse.UserNotebook(self.nb, -1, self.np.queue, userinfobrowse.UserInfoWindow, self)
        userbrowse = userinfobrowse.UserNotebook(self.nb, -1, self.np.queue, userinfobrowse.UserBrowseWindow, self)
        searchw = search.SearchWindow(self.nb, -1, self.np.queue, self.np.ProcessRequestToPeer, privatechat, userinfo, userbrowse, self.np.transfers,self.OnPageUpdated,self)
        downloads = transfers.TransfersPanel(self.nb, -1, self.np.transfers.downloads, self.np, self.np.transfers)
	uploads = transfers.TransfersPanel(self.nb, -1, self.np.transfers.uploads, self.np, self.np.transfers)
	userlistpanel = userlist.UserListPanel(self.nb,-1,self)

        self.nb.AddPage(chatrooms,"Chat Rooms")
        self.nb.AddPage(privatechat,"Private Chat")
#       self.nb.AddPage(globallist,"Global Users List")
        self.nb.AddPage(downloads,"Downloads")
	self.nb.AddPage(uploads,"Uploads")
        self.nb.AddPage(searchw, "Search Files")
        self.nb.AddPage(userinfo,"User Info")
        self.nb.AddPage(userbrowse,"User Browse")
	self.nb.AddPage(userlistpanel,"User List")

        self.mainmenu.Enable(self.checkprivID,1)
	self.mainmenu.Enable(self.awayID,1)
        chatrooms.roomsctrl.SetGreeting(msg.banner)
	return privatechat,chatrooms,userinfo,userbrowse,searchw,downloads,uploads, userlistpanel

    def BanUser(self,user):
    	if self.np.transfers is not None:
	    self.np.transfers.BanUser(user)

    def UnbanUser(self,user):
        if user in self.np.config.sections["server"]["banlist"]:
	    self.np.config.sections["server"]["banlist"].remove(user)
	    self.np.config.writeConfig()

    def IgnoreUser(self,user):
	 if user not in self.np.config.sections["server"]["ignorelist"]:
	     self.np.config.sections["server"]["ignorelist"].append(user)
	     self.np.config.writeConfig()
    
    def UnignoreUser(self,user):
	 if user in self.np.config.sections["server"]["ignorelist"]:
	     self.np.config.sections["server"]["ignorelist"].remove(user)
	     self.np.config.writeConfig()
	    

    def OnPageUpdated(self, pageobj, hilite=False):
	return self.nb.OnPageUpdated(pageobj, hilite)

    def callback(self, msgs):
        if len(msgs) > 0:
	    try:
                wxPostEvent(self, NetworkEvent(self.EVT_NETWORK_ID,msgs))
	    except wxPyDeadObjectError:
		print "Can't deliver events because the frame has been closed:", msgs
	    except wxPyAssertionError:
		print "Ugly workarounding wxGTK's probable non-thread-safety."

    def networkcallback(self,msgs):
#      """ Callback function called by networking thread."""
#      try:
	curtime = time.time()
	for i in msgs[:]:
	    if i.__class__ is slskmessages.DownloadFile or i.__class__ is slskmessages.UploadFile:
		self.transfermsgs[i.conn] = i
		msgs.remove(i)
	    if i.__class__ is slskmessages.ConnClose:
		msgs = self.postTransferMsgs(msgs,curtime)
	if curtime-self.transfermsgspostedtime > 1.0:
		msgs = self.postTransferMsgs(msgs,curtime)
	if len(msgs) > 0:
	  try:
	    wxPostEvent(self, NetworkEvent(self.EVT_NETWORK_ID,msgs))
          except wxPyAssertionError:
            print "Ugly workarounding wxGTK's probable non-thread-safety."

#      except wxPyDeadObjectError:
#	return

    def postTransferMsgs(self,msgs,curtime):
	trmsgs = []
        for i in self.transfermsgs.keys():
            trmsgs.append(self.transfermsgs[i])
	msgs = trmsgs+msgs
        self.transfermsgs = {}
        self.transfermsgspostedtime = curtime
	return msgs


    def OnNetworkEvent(self, event):
	""" Processes messages from networking thread."""
	for i in event.msgs:
	    if self.np.events.has_key(i.__class__):
		self.np.events[i.__class__](i)
	    else:
		self.logMessage("No handler for class %s %s" % (i.__class__, vars(i)))
	self.networkevent = 2
	

    def EVT_NETWORK(self, win, id, func):
	""" Network event macro """
	win.Connect(-1, -1, id, func) 

class MainApp(wxApp): 
    """ Application class. """
    def __init__(self,config):
	self.config = config
	wxApp.__init__(self)
    
    def OnInit(self):
	wxInitAllImageHandlers()
        self.frame = MainFrame(None,-1,'PySoulSeek', self.config, self) 
        self.frame.Show(True) 
        self.SetTopWindow(self.frame) 
        return True 


