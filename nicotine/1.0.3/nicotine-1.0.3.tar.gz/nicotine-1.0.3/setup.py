#!/usr/local/bin/python

"""To use this setup script to install Nicotine:

        python setup.py install

"""

import sys
import os

from distutils.core import setup
from distutils.sysconfig import get_python_lib

if sys.platform.startswith("win"):
  try:
    import py2exe
  except ImportError:
    pass

if __name__ == '__main__' :
    LONG_DESCRIPTION = \
""" Nicotine is a client for SoulSeek filesharing system. 
"""

    from pynicotine.utils import version

    setup(name                  = "nicotine",
          version               = version,
          license               = "GPL",
          description           = "Client for SoulSeek filesharing system.",
          author                = "Hyriand",
          author_email          = "hyriand@thegraveyard.org",
          url                   = "http://nicotine.thegraveyard.org/",
          packages              = [ 'pynicotine', 'pynicotine.gtkgui' ],
          scripts               = [ 'nicotine','nicotine-import-winconfig'],
          long_description      = LONG_DESCRIPTION
         )

