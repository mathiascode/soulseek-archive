# Copyright (c) 2001-2002 Alexander Kanavin. All rights reserved.

"""
This is the actual client code. Mostly consists of GUI classes and event 
handlers. Perhaps I should split them into several files - this one is getting
too big.
"""

import time
import slskproto
import slskmessages
import transfers
import Queue
import threading
import images
import about
import userinfobrowse
import search
from wxPython.wx import *
from config import *

class NetworkEvent(wxPyEvent):
    """
    Special event that occurs when networking thread sends us some messages.
    msgs is a list of them.
    """
    def __init__(self,id,msgs):
	wxPyEvent.__init__(self)
	self.SetEventType(id)
	self.msgs = msgs

class PeerConnection:
    """
    Holds information about a peer connection. Not every field may be set
    to something. addr is (ip,port) address, conn is a socket object, msgs is
    a list of outgoing pending messages, token is a reverse-handshake 
    number (protocol feature), init is a PeerInit protocol message. (read
    slskmessages docstrings for explanation of these)
    """
    def __init__(self, addr = None, username = None, conn = None, msgs = None, token = None, init = None):
	self.addr = addr
	self.username = username
	self.conn = conn
	self.msgs = msgs
	self.token = token
	self.init = init

class OutputWindow(wxTextCtrl):
    """
    Multiple-lines text control with a twist - cleans oldest 100 lines from 
    itself when 200 lines maximum is reached
    """
    def __init__(self, parent, id, style):
        wxTextCtrl.__init__(self,parent,id,style = style)
	self.lines = 1
	self.chars = 0

    def AppendText(self, text):
	wxTextCtrl.AppendText(self,text)
	self.lines = self.lines + 1
	if self.lines == 100:
	     self.chars = wxTextCtrl.GetLastPosition(self)
	if self.lines == 200:
	     wxTextCtrl.Remove(self,0,self.chars)
	     wxTextCtrl.SetInsertionPointEnd(self)
	     self.chars = wxTextCtrl.GetLastPosition(self)
	     self.lines = 100

class UsersList(wxListCtrl):
    """
    This is a list control for the users list in chat window. Gets users
    data from parent window (which should have a userslist attribute).
    """
    def __init__(self, parent, id, style = wxLC_REPORT|wxLC_VIRTUAL):
	wxListCtrl.__init__(self,parent,id,style = style)
	self.InsertColumn(0,"User", width=100)
        self.InsertColumn(1,"Speed",width=50)
        self.InsertColumn(2,"Files",width=50)
        self.SetItemCount(0)
	self.normal = wxListItemAttr()
	self.normal.SetTextColour("black")
	self.grey = wxListItemAttr()
	self.grey.SetTextColour("grey")

        self.imglist = wxImageList(18,18)
	self.online = self.imglist.Add(images.getOnlineBitmap())
	self.offline = self.imglist.Add(images.getOfflineBitmap())
	self.away = self.imglist.Add(images.getAwayBitmap())
	self.AssignImageList(self.imglist,wxIMAGE_LIST_SMALL)
	
	self.parent = parent

    def OnGetItemText(self, item, col):
	username =  self.parent.userslist[item]
	if col == 0:
	    return username
	elif col == 1:
	    return self.parent.users[username].avgspeed
	elif col == 2:
	    return self.parent.users[username].files
	else:
	    return None

    def OnGetItemAttr(self,item):
	username =  self.parent.userslist[item]
	if self.parent.users[username].slotsfull == 1:
	    return self.grey
	else:
	    return self.normal

    def OnGetItemImage(self,item):
	username = self.parent.userslist[item]
	if self.parent.users[username].status == 1:
	    return self.away
	elif self.parent.users[username].status == 2:
	    return self.online
	else:
	    return -1
   
class ChatWindow(wxSplitterWindow):
    """
    The chat window that holds a users list, info window and dialog window.
    Also contains users dictionary that holds info about every user in a room.
    """
    def __init__(self, parent, id, queue, privatechat, peerconns, frame, style = wxNO_3D|wxSP_3D):
	wxSplitterWindow.__init__(self,parent,id,wxDefaultPosition,wxDefaultSize,style,"splitterWindow")
	splitter = wxSplitterWindow(self,-1,style=wxNO_3D|wxSP_3DSASH)
	self.userslistctrl = UsersList(self,-1,style=wxLC_REPORT|wxLC_VIRTUAL)
        self.SplitVertically(splitter,self.userslistctrl)
        self.SetSashPosition(500, true)
	self.info = OutputWindow(splitter,-1,style = wxTE_MULTILINE|wxTE_READONLY|wxTE_RICH)

	chatpanel = wxPanel(splitter,-1)
	self.chat = OutputWindow(chatpanel,-1,style = wxTE_MULTILINE|wxTE_READONLY|wxTE_RICH)
        self.mychatphrase = wxTextCtrl(chatpanel,-1, style = wxTE_PROCESS_ENTER)
	chatsizer = wxBoxSizer(wxVERTICAL)
	chatsizer.Add(self.chat,1,wxEXPAND)
	chatsizer.Add(self.mychatphrase,0,wxEXPAND)
        chatpanel.SetSizer(chatsizer)
        chatpanel.SetAutoLayout(true)

	splitter.SplitHorizontally(self.info,chatpanel)
	splitter.SetSashPosition(100,true)

	self.queue = queue
	self.privatechat = privatechat
	self.users = {} #with IP cache
	self.peerconns = peerconns
	self.frame = frame

        self.menu = wxMenu()
        sendmessageID=wxNewId()
        self.menu.Append(sendmessageID, 'Send Message')
        EVT_MENU(self,sendmessageID, self.OnSendMessage)
        showipID=wxNewId()
        self.menu.Append(showipID, 'Show IP address')
        EVT_MENU(self,showipID, self.OnShowIp)
	getinfoID=wxNewId()
	self.menu.Append(getinfoID, 'Get User Info')
	EVT_MENU(self,getinfoID, self.OnGetInfo)
	browseID=wxNewId()
	self.menu.Append(browseID, 'Browse Files')
	EVT_MENU(self,browseID, self.OnBrowse)

        EVT_TEXT_ENTER(self,self.mychatphrase.GetId(),self.OnEnter)

	EVT_LIST_ITEM_RIGHT_CLICK(self.userslistctrl, -1,self.OnRightClick)
	EVT_RIGHT_UP(self.userslistctrl,self.OnRightUp)

    def OnRightClick(self,event):
        """ Saves name of a user in a lisr on a right-click."""
	id = event.GetIndex()
	self.userslistctrl.SetItemState(id,wxLIST_STATE_FOCUSED,wxLIST_STATE_FOCUSED)
	self.focuseduser = self.userslistctrl.GetItemText(id)

    def OnRightUp(self,event):
        """ Pops up a menu on a right-click in users list."""
        self.userslistctrl.PopupMenu(self.menu, wxPoint(event.GetX(),event.GetY()))
 
    """ Handlers for the menu items"""
    def OnSendMessage(self, event):
	self.privatechat.SendMessage(self.focuseduser)

    def OnShowIp(self, event):
	if self.users[self.focuseduser].addr is not None:
	    wxLogMessage("Already in cache: %s:%s" %(self.users[self.focuseduser].addr[0], self.users[self.focuseduser].addr[1]))
	else:
	    self.queue.put(slskmessages.GetPeerAddress(self.focuseduser))

    def OnGetInfo(self, event):
	self.ProcessRequestToPeer(self.focuseduser, slskmessages.UserInfoRequest(None), self.frame.userinfo)
    
    def OnBrowse(self, event):
	self.ProcessRequestToPeer(self.focuseduser, slskmessages.GetSharedFileList(None), self.frame.userbrowse)

    def ProcessRequestToPeer(self, user, message, window = None):
        """ 
	Sends message to a peer and possibly sets up a window to display 
	the result.
	"""
	conn = None
	if user in self.users.keys():
            for i in self.peerconns:
	        if i.username == user and i.init is not None and i.init.type == 'P':
	            conn = i
		    break
	    if conn is not None:
	        message.conn = conn.conn
	        self.queue.put(message)
	        if window is not None:	    
	  	    window.InitWindow(conn.username,conn.conn)
	    else:
	        addr = self.users[user].addr
	        behindfw = self.users[user].behindfw
	        token = None
	        if addr is None:
	            self.queue.put(slskmessages.GetPeerAddress(user))
	        elif behindfw is None:
	            self.queue.put(slskmessages.OutConn(None,addr))
	        else:
	            token = wxNewId()
                    self.queue.put(slskmessages.ConnectToPeer(token,user))
	        self.peerconns.append(PeerConnection(addr = addr, username = user, msgs = [message], token = token))

    def OnEnter(self, event):
	""" Processes chat phrase that we entered. """
        text = self.mychatphrase.GetLineText(0)
        self.queue.put(slskmessages.SayChatroom(self.roomid, text))
        self.mychatphrase.Clear()

    """ These functions process various messages from the server. """ 
    def UserJoinedRoom(self, msg):
	self.roomid = msg.roomid
	self.users[msg.username] = msg.userdata
        self.userslist = self.users.keys()
        self.userslist.sort()
	self.userslistctrl.SetItemCount(len(self.users))
	
	self.info.AppendText("* %s joined the room\n" %(msg.username))

    def JoinRoom(self,msg,frame):
	self.roomid = msg.roomid
	self.users = msg.users
        self.userslist = self.users.keys()
        self.userslist.sort()
	self.userslistctrl.SetItemCount(len(self.users))

	frame.SetStatusText("")

    def UserLeftRoom(self, msg):
	self.roomid = msg.roomid
	if msg.username in self.users.keys():
	    del self.users[msg.username]
	self.userslist = self.users.keys()
	self.userslist.sort()
	self.userslistctrl.SetItemCount(len(self.users))
        self.info.AppendText("* %s left the room\n" %(msg.username))
# update ip cache

    def SayChatRoom(self,msg):
	self.roomid = msg.roomid
	self.chat.AppendText("[%s] %s\n" %(msg.user,msg.msg))

    def QueuedDownloads(self,msg):
	self.users[msg.user].slotsfull = msg.slotsfull
        self.userslistctrl.SetItemCount(len(self.users))

    def GetUserStatus(self,msg):
	self.users[msg.user].status = msg.status
	if msg.status == 1:
	    text = "* %s has gone away\n"
	else:
	    text = "* %s has returned\n"
	self.info.AppendText(text %(msg.user))
	self.userslistctrl.SetItemCount(len(self.users))

    def GetUserStats(self,msg):
	self.users[msg.user].avgspeed = msg.avgspeed
	self.users[msg.user].downloadnum = msg.downloadnum
	self.users[msg.user].something = msg.something
	self.users[msg.user].files = msg.files
	self.users[msg.user].dirs = msg.dirs
	self.userslistctrl.SetItemCount(len(self.users))
	
class PrivateChatNotebook(wxNotebook):
    """
    This class is a notebook of private chat windows. Actual window 
    pointers are stored in user dictionary.
    """
    def __init__(self, parent, id, queue, style=wxCLIP_CHILDREN|wxNB_RIGHT):
	wxNotebook.__init__(self,parent,id,style = style)
	self.users={}
	self.queue = queue

    def ShowMessage(self,msg):
	""" Processes MessageUser message from the server. """
	if not self.users.has_key(msg.user):
	    self.users[msg.user]=PrivateChatWindow(self, -1, msg.user)
	    self.AddPage(self.users[msg.user],msg.user)
	self.users[msg.user].AddText("[%s] %s\n" %(msg.user, msg.msg))

    def SendMessage(self, user):
        """ Adds a notebook tab with a user's name on it, and prvate chat 
	window inside the tab
	"""
        if not self.users.has_key(user):
            self.users[user]=PrivateChatWindow(self, -1, user)
            self.AddPage(self.users[user],user)

class PrivateChatWindow(wxPanel):
    """ This is a window for chatting with someone in private"""
    def __init__(self, parent, id, user):
	wxPanel.__init__(self, parent, id)
	self.chat = wxTextCtrl(self,-1,style = wxTE_MULTILINE|wxTE_READONLY|wxTE_RICH)
        self.mychatphrase = wxTextCtrl(self,-1, style = wxTE_PROCESS_ENTER)
	self.close = wxButton(self, -1, "Close")
        sizerh = wxBoxSizer(wxHORIZONTAL)
        sizerh.Add(self.mychatphrase,1,wxEXPAND)
	sizerh.Add(self.close,0,wxEXPAND)
	sizerv = wxBoxSizer(wxVERTICAL)
        sizerv.Add(self.chat,1,wxEXPAND)
	sizerv.Add(sizerh,0,wxEXPAND)

        self.SetSizer(sizerv)
        self.SetAutoLayout(true)
	EVT_BUTTON(self,self.close.GetId(), self.OnClose)
	EVT_TEXT_ENTER(self,self.mychatphrase.GetId(),self.OnEnter)

	self.user = user
	self.parent = parent
	

    def AddText(self,text):
	""" Rather obvious really """
	self.chat.AppendText(text)

    def OnClose(self, event):
	""" Close the window and update notebook's window list."""
	del self.parent.users[self.user]
	self.parent.DeletePage(self.parent.GetSelection())
	self.parent.SetSelection(0)

    def OnEnter(self, event):
	""" Sends our chat phrase and updates the window."""
	text = self.mychatphrase.GetLineText(0)
	self.AddText("> "+ text+ "\n")
	self.parent.queue.put(slskmessages.MessageUser(self.user, text))
	self.mychatphrase.Clear()

class NetworkEventProcessor:
    """ This class contains handlers for various messages from the networking
    thread"""
    def __init__(self,frame):
	self.frame=frame

        self.events = {slskmessages.ConnectError:self.ConnectError,
		       slskmessages.IncPort:self.IncPort,
		       slskmessages.ServerConn:self.ServerConn,
		       slskmessages.ConnClose:self.ConnClose,
		       slskmessages.Login:self.Login,
		       slskmessages.MessageUser:self.MessageUser,
		       slskmessages.FileSearch:self.FileSearch,
		       slskmessages.UserJoinedRoom:self.UserJoinedRoom,
		       slskmessages.SayChatroom:self.SayChatRoom,
		       slskmessages.JoinRoom:self.JoinRoom,
		       slskmessages.UserLeftRoom:self.UserLeftRoom,
		       slskmessages.QueuedDownloads:self.QueuedDownloads,
		       slskmessages.GetPeerAddress:self.GetPeerAddress,
		       slskmessages.OutConn:self.OutConn,
		       slskmessages.UserInfoReply:self.UserInfoReply,
		       slskmessages.PierceFireWall:self.PierceFireWall,
		       slskmessages.CantConnectToPeer:self.CantConnectToPeer,
		       slskmessages.PeerTransfer:self.PeerTransfer,
		       slskmessages.SharedFileList:self.SharedFileList,
		       slskmessages.FileSearchResult:self.FileSearchResult,
		       slskmessages.ConnectToPeer:self.ConnectToPeer,
		       slskmessages.GetUserStatus:self.GetUserStatus,
		       slskmessages.GetUserStats:self.GetUserStats,
		       slskmessages.PeerInit:self.PeerInit,
		       slskmessages.FileResponse:self.FileResponse,
		       slskmessages.DownloadFile:self.FileDownload,
			slskmessages.FileRequest:self.FileRequest,
			slskmessages.PlaceInQueue:self.PlaceInQueue,
		        slskmessages.FileError:self.FileError,
			slskmessages.FolderContentsResponse:self.FolderContentsResponse}

    def ConnectError(self,msg):
	if msg.connobj.__class__ is slskmessages.ServerConn:
	    self.frame.SetStatusText("Can't connect to server %s:%s: %s" % (msg.connobj.addr[0],msg.connobj.addr[1],msg.err))
	    self.frame.serverconn = None
	    self.frame.mainmenu.Enable(self.frame.connectID,1)
	    self.frame.mainmenu.Enable(self.frame.disconnectID,0)
	elif msg.connobj.__class__ is slskmessages.OutConn:
            for i in self.frame.peerconns:
                if i.addr == msg.connobj.addr and i.conn is None: 
		    if i.token is None:
		        i.token = wxNewId()
		        self.frame.queue.put(slskmessages.ConnectToPeer(i.token,i.username))
		        self.frame.chat.users[i.username].behindfw = "yes"
			if len(i.msgs)>=1 and i.msgs[0].__class__ is slskmessages.FileRequest:
			    self.frame.transfers.gotConnectError(i.msgs[0].req)
		    elif len(i.msgs)==0:
			wxLogMessage("Can't connect to %s, sending notification via the server" %(i.username))
			self.frame.queue.put(slskmessages.CantConnectToPeer(i.token,i.username))
			self.frame.peerconns.remove(i)
			
	else:
	    wxLogMessage("%s %s" %(msg.__class__, vars(msg)))

    def IncPort(self, msg):
        self.frame.waitport = msg.port
	self.frame.SetStatusText("Listening on port %i" %(msg.port))

    def ServerConn(self, msg):
	self.frame.SetStatusText("Connected to server %s:%s, logging in..." %(msg.addr[0],msg.addr[1]))
	self.frame.serverconn = msg.conn
        self.frame.queue.put(slskmessages.Login(self.frame.config.sections["server"]["login"],self.frame.config.sections["server"]["passw"]))
        if self.frame.waitport is not None:	
	    self.frame.queue.put(slskmessages.SetWaitPort(self.frame.waitport))

    def PeerInit(self, msg):
	list = [i for i in self.frame.peerconns if i.conn == msg.conn.conn]
	if list == []:
	    self.frame.peerconns.append(PeerConnection(addr = msg.conn.addr, username = msg.user, conn = msg.conn.conn, init = msg, msgs = []))
	else:
	    for i in list:
		i.init = msg
		i.username = msg.user

    def ConnClose(self, msg):
	if msg.conn == self.frame.serverconn:
	    self.frame.SetStatusText("Disconnected from server %s:%s" %(msg.addr[0],msg.addr[1]))
	    self.frame.serverconn = None
	    self.frame.mainmenu.Enable(self.frame.connectID,1)
	    self.frame.mainmenu.Enable(self.frame.disconnectID,0)
	    self.frame.nb.DeleteAllPages()
	    self.frame.transfers.AbortTransfers()
	    self.frame.config.sections["transfers"]["downloads"] = self.frame.transfers.GetDownloads()
        else:
	    for i in self.frame.peerconns:
	        if i.conn == msg.conn:
		    wxLogMessage("Connection closed by peer: %s" %(vars(i)))
		    self.frame.peerconns.remove(i)
		    self.frame.transfers.ConnClose(msg)
	
    def Login(self,msg):
	conf = self.frame.config.sections
	self.frame.SetStatusText("Logged in, entering the room...")
	self.frame.privatechat = PrivateChatNotebook(self.frame.nb, -1,self.frame.queue)
	self.frame.chat = ChatWindow(self.frame.nb, -1,self.frame.queue,self.frame.privatechat,self.frame.peerconns, self.frame)
	self.frame.userinfo = userinfobrowse.UserNotebook(self.frame.nb, -1, self.frame.queue, userinfobrowse.UserInfoWindow, self.frame)
	self.frame.userbrowse = userinfobrowse.UserNotebook(self.frame.nb, -1, self.frame.queue, userinfobrowse.UserBrowseWindow, self.frame)
	self.frame.transfers = transfers.Transfers(self.frame.nb, conf["transfers"]["shared"],conf["transfers"]["downloaddir"],conf["transfers"]["uploadbandwidth"],conf["transfers"]["downloads"],self.frame.peerconns,self.frame.queue, self)
	self.frame.search = search.SearchWindow(self.frame.nb, -1, self.frame.queue, self.frame.chat, self.frame.userinfo, self.frame.userbrowse, self.frame.transfers)
	self.frame.nb.AddPage(self.frame.chat,"Chat")
	self.frame.nb.AddPage(self.frame.privatechat,"Private Chat")
	self.frame.nb.AddPage(self.frame.transfers.downloadspanel,"Downloads")
	self.frame.nb.AddPage(self.frame.search, "Search Files")
	self.frame.nb.AddPage(self.frame.userinfo,"User Info")
	self.frame.nb.AddPage(self.frame.userbrowse,"User Browse")
	self.frame.chat.info.AppendText(msg.banner)

    def MessageUser(self, msg):
	if self.frame.privatechat is not None:
	    self.frame.privatechat.ShowMessage(msg)
	    self.frame.queue.put(slskmessages.MessageAcked(msg.msgid))
       	else:
            wxLogMessage("%s %s" %(msg.__class__, vars(msg)))

    def UserJoinedRoom(self,msg):
	if self.frame.chat is not None:
	    self.frame.chat.UserJoinedRoom(msg)
	else:
            wxLogMessage("%s %s" %(msg.__class__, vars(msg)))
	if self.frame.search is not None:
	    self.frame.search.ChangeAttrs(msg.username)
	if self.frame.transfers is not None:
	    self.frame.transfers.UserJoinedRoom(msg.username)


    def JoinRoom(self,msg):
	if self.frame.chat is not None:
            self.frame.chat.JoinRoom(msg,self.frame)
	    self.frame.transfers.setUsers(self.frame.chat.users)
        else:
            wxLogMessage("%s %s" %(msg.__class__, vars(msg)))

    def SayChatRoom(self,msg):
        if self.frame.chat is not None:
            self.frame.chat.SayChatRoom(msg)
        else:
            wxLogMessage("%s %s" %(msg.__class__, vars(msg)))

    def GetUserStatus(self,msg):
	if self.frame.chat is not None:
            self.frame.chat.GetUserStatus(msg)
        else:
            wxLogMessage("%s %s" %(msg.__class__, vars(msg)))

    def GetUserStats(self,msg):
        if self.frame.chat is not None:
            self.frame.chat.GetUserStats(msg)
        else:
            wxLogMessage("%s %s" %(msg.__class__, vars(msg)))

    def UserLeftRoom(self,msg):
        if self.frame.chat is not None:
            self.frame.chat.UserLeftRoom(msg)
        else:
            wxLogMessage("%s %s" %(msg.__class__, vars(msg)))
	if self.frame.search is not None:
	    self.frame.search.ChangeAttrs(msg.username)
        if self.frame.transfers is not None:
            self.frame.transfers.UserLeftRoom(msg.username)


    def QueuedDownloads(self,msg): 
	if self.frame.chat is not None:
	    self.frame.chat.QueuedDownloads(msg) 
	else: 
	    wxLogMessage("%s %s" %(msg.__class__, vars(msg)))
	if self.frame.search is not None:
	    self.frame.search.ChangeAttrs(msg.user)

    def GetPeerAddress(self,msg):
	for i in self.frame.peerconns:
	    if i.username == msg.user and i.addr is None:
		i.addr = (msg.ip, msg.port)
		self.frame.queue.put(slskmessages.OutConn(None, i.addr))
                if len(i.msgs)>=1 and i.msgs[0].__class__ is slskmessages.FileRequest:
                    self.frame.transfers.gotAddress(i.msgs[0].req)
		break
	wxLogMessage("%s %s" %(msg.__class__, vars(msg)))
	self.frame.chat.users[msg.user].addr = (msg.ip,msg.port)

    def OutConn(self, msg):
	for i in self.frame.peerconns:
	    if i.addr == msg.addr and i.conn is None:
		if i.token is None:
		    if len(i.msgs)>=1 and i.msgs[0].__class__ is slskmessages.FileRequest:
			type='F'
		    else:
			type='P'
		    i.init = slskmessages.PeerInit(msg.conn,self.frame.config.sections["server"]["login"],type,300)
		    self.frame.queue.put(i.init)
		else:
		    self.frame.queue.put(slskmessages.PierceFireWall(msg.conn, i.token))
		i.conn = msg.conn
		for j in i.msgs:
		    if j.__class__ is slskmessages.UserInfoRequest:
			self.frame.userinfo.InitWindow(i.username,msg.conn)
		    if j.__class__ is slskmessages.GetSharedFileList:
			self.frame.userbrowse.InitWindow(i.username,msg.conn)
		    if j.__class__ is slskmessages.FileRequest:
			self.frame.transfers.gotConnect(j.req,msg.conn)
		    j.conn = msg.conn
		    self.frame.queue.put(j)
		    i.msgs.remove(j)
		break
		
	wxLogMessage("%s %s" %(msg.__class__, vars(msg)))

    def ConnectToPeer(self, msg):
        self.frame.queue.put(slskmessages.OutConn(None,(msg.ip,msg.port)))
        self.frame.peerconns.append(PeerConnection(addr = (msg.ip,msg.port), username = msg.user, msgs = [], token = msg.token))

        wxLogMessage("%s %s" %(msg.__class__, vars(msg)))


    def UserInfoReply(self,msg):
	for i in self.frame.peerconns:
	    if i.conn is msg.conn.conn:
		self.frame.userinfo.ShowInfo(i.username, msg)

    def SharedFileList(self, msg):
	for i in self.frame.peerconns:
	    if i.conn is msg.conn.conn:
		self.frame.userbrowse.ShowInfo(i.username, msg)

    def FileSearchResult(self, msg):
	for i in self.frame.peerconns:
	    if i.conn is msg.conn.conn:
		self.frame.search.ShowResult(msg, i.username)

    def PierceFireWall(self, msg):
	for i in self.frame.peerconns:
	    if i.token == msg.token and i.conn is None:
                if len(i.msgs)>=1 and i.msgs[0].__class__ is slskmessages.FileRequest:
                    type='F'
                else:
                    type='P'
		i.init = slskmessages.PeerInit(msg.conn.conn,self.frame.config.sections["server"]["login"],type,300)
                self.frame.queue.put(i.init)
                i.conn = msg.conn.conn
                for j in i.msgs:
                    if j.__class__ is slskmessages.UserInfoRequest:
                        self.frame.userinfo.InitWindow(i.username,msg.conn.conn)
                    if j.__class__ is slskmessages.GetSharedFileList:
                        self.frame.userbrowse.InitWindow(i.username,msg.conn.conn)
		    if j.__class__ is slskmessages.FileRequest:
			self.frame.transfers.gotConnect(j.req,msg.conn.conn)
                    j.conn = msg.conn.conn
                    self.frame.queue.put(j)
                    i.msgs.remove(j)
		break

        wxLogMessage("%s %s" %(msg.__class__, vars(msg)))

    def CantConnectToPeer(self, msg):
	for i in self.frame.peerconns:
	    if i.token == msg.token:
		self.frame.peerconns.remove(i)
	        wxLogMessage("Can't connect to %s (either way), giving up" % (i.username))
                if len(i.msgs)>=1 and i.msgs[0].__class__ is slskmessages.FileRequest:
                    self.frame.transfers.gotCantConnect(i.msgs[0].req)

    def FileResponse(self,msg):
        if self.frame.transfers is not None:
            self.frame.transfers.FileResponse(msg)
        else:
            wxLogMessage("%s %s" %(msg.__class__, vars(msg)))

    def FileDownload(self,msg):
        if self.frame.transfers is not None:
            self.frame.transfers.FileDownload(msg)
        else:
            wxLogMessage("%s %s" %(msg.__class__, vars(msg)))

    def FileRequest(self,msg):
        if self.frame.transfers is not None:
            self.frame.transfers.FileRequest(msg)
        else:
            wxLogMessage("%s %s" %(msg.__class__, vars(msg)))

    def FileError(self,msg):
        if self.frame.transfers is not None:
            self.frame.transfers.FileError(msg)
        else:
            wxLogMessage("%s %s" %(msg.__class__, vars(msg)))

    def PlaceInQueue(self,msg):
        if self.frame.transfers is not None:
            self.frame.transfers.PlaceInQueue(msg)
        else:
            wxLogMessage("%s %s" %(msg.__class__, vars(msg)))

    def FolderContentsResponse(self,msg):
        if self.frame.transfers is not None:
            self.frame.transfers.FolderContentsResponse(msg)
        else:
            wxLogMessage("%s %s" %(msg.__class__, vars(msg)))

    def PeerTransfer(self,msg):
	self.frame.userinfo.UpdateGauge(msg)
	self.frame.userbrowse.UpdateGauge(msg)
	
    def FileSearch(self, msg):
	pass #alright, alright, they take too much space in log window and i kinda don't know where to stick them, and server-side p2p is not yet done anyway
	

class MainFrame(wxFrame):
    """ This is the very main window, with menu, status bar and notebook 
    that contains all other subwindows. Everything else is set up 
    from here""" 
    def __init__(self, parent, id, title): 
        wxFrame.__init__(self,parent,id,title, size = (800,600), style = wxDEFAULT_FRAME_STYLE|wxMAXIMIZE|wxNO_FULL_REPAINT_ON_RESIZE)

	# set icon here, see demo to know how
	self.SetIcon(wxIconFromXPMData(images.getBirdData()))

	# set task bar icon here, see demo to know how

        EVT_CLOSE(self, self.OnCloseWindow)
        self.Centre(wxBOTH)
        self.CreateStatusBar(1, wxST_SIZEGRIP)

	self.config = Config()
	self.config.readConfig()
	self.configwindow = ConfigWindow(self, -1, "Settings")

        self.mainmenu = wxMenuBar()

        menu = wxMenu()
	if not self.config.needConfig():
	    self.serverstring =  '%s:%s'%(self.config.sections["server"]["server"][0],self.config.sections["server"]["server"][1])
	else:
	    self.serverstring = ''
	self.connectID = wxNewId()
	menu.Append(self.connectID, '&Connect\tAlt-C', 'Connect to ' + self.serverstring)
	menu.Enable(self.connectID, not self.config.needConfig())
        EVT_MENU(self, self.connectID, self.OnConnect)
	self.disconnectID = wxNewId()
	menu.Append(self.disconnectID, '&Disconnect\tAlt-D', 'Disconnect from ' + self.serverstring)
	menu.Enable(self.disconnectID, false)
        EVT_MENU(self, self.disconnectID, self.OnDisconnect)
	self.settingsID = wxNewId()
	menu.Append(self.settingsID, '&Settings...', 'Set up server name, login, password')
	EVT_MENU(self, self.settingsID, self.OnSettings)
	menu.AppendSeparator()
        exitID = wxNewId()
        menu.Append(exitID, 'E&xit\tAlt-X', 'Get the heck outta here!')
        EVT_MENU(self, exitID, self.OnFileExit)

	
	helpmenu = wxMenu()
        aboutID = wxNewId()
        helpmenu.Append(aboutID, '&About', 'About PySoulSeek')
        EVT_MENU(self, aboutID, self.OnAbout)

        self.mainmenu.Append(menu, '&File')
	self.mainmenu.Append(helpmenu, '&Help')
        self.SetMenuBar(self.mainmenu)
        aTable = wxAcceleratorTable([(wxACCEL_ALT,  ord('X'), exitID),(wxACCEL_ALT,  ord('C'), self.connectID),(wxACCEL_ALT,  ord('D'), self.disconnectID)])

        splitter = wxSplitterWindow(self, -1, style=wxNO_3D|wxSP_3D)
        self.nb = wxNotebook(splitter, -1, style=wxCLIP_CHILDREN)

	self.log = OutputWindow(splitter,-1,style = wxTE_MULTILINE|wxTE_READONLY|wxTE_RICH)
        EVT_RIGHT_UP(self.log, self.OnRightClickInLog)

        wxLog_SetActiveTarget(wxLogTextCtrl(self.log))

	splitter.SplitHorizontally(self.nb,self.log)	
	splitter.SetSashPosition(400, true)

	self.EVT_NETWORK_ID = wxNewId()     
	self.EVT_NETWORK(self, self.EVT_NETWORK_ID, self.OnNetworkEvent)

	self.np = NetworkEventProcessor(self)
	self.queue = Queue.Queue(0)
    	self.protothread = slskproto.SlskProtoThread(self.callback,self.queue)
	self.serverconn = None
	self.waitport = None
	self.peerconns = []
	self.chat = None
	self.privatechat = None
	self.userinfo = None
	self.userbrowse = None
	self.search = None
	self.transfers = None

    def OnRightClickInLog(self,event):
	""" Log window is not self-cleaning yet, unlike chat windows. Will change that when the client stabilizes."""
	menu = wxMenu()
	clearID=wxNewId()
	menu.Append(clearID, 'Clear')
	EVT_MENU(self,clearID, self.OnClearLog)
	self.log.PopupMenu(menu, wxPoint(event.GetX(),event.GetY()))
	event.Skip()

    def OnClearLog(self,event):
	self.log.Clear()

    def OnCloseWindow(self, event):
 	""" Close the window, but finish all filetransfers and stop the 
	networking thread first."""
	if self.transfers is not None:
            self.transfers.AbortTransfers()
            self.config.setConfig({"transfers":{"downloads":self.transfers.GetDownloads()}})
	    self.config.writeConfig()
        self.queue.put(slskmessages.ConnClose(self.serverconn)) 
	self.protothread.abort()
	while self.protothread.isAlive():
  	    wxYield()
	    time.sleep(0.1)
        self.Destroy()
	wxYield()

    """ Menu items handlers."""
    def OnFileExit(self, event):
        self.Close()

    def OnConnect(self, event):
	self.mainmenu.Enable(self.connectID,0)
	self.mainmenu.Enable(self.disconnectID,1)
	if self.serverconn is None:
	    server = self.config.sections["server"]["server"]
	    self.queue.put(slskmessages.ServerConn(None, server))
	    self.SetStatusText("Connecting to %s:%s" %(server[0],server[1]))

    def OnDisconnect(self, event):
	self.queue.put(slskmessages.ConnClose(self.serverconn))

    def OnSettings(self, event):
	self.configwindow.SetSettings(self.config)
	val = self.configwindow.ShowModal()
	if val == wxID_OK:
	    self.config.setConfig(self.configwindow.GetSettings())
	    if not self.config.needConfig():
		self.config.writeConfig()
	        if not self.mainmenu.IsEnabled(self.disconnectID):
		    self.mainmenu.Enable(self.connectID,1)
		server = self.config.sections["server"]["server"]
	        self.serverstring = '%s:%s'%(server[0],server[1])
	        self.mainmenu.SetHelpString(self.connectID,'Connect to '+self.serverstring)
	        self.mainmenu.SetHelpString(self.disconnectID,'Disconnect from '+self.serverstring)

    def OnAbout(self, event):
	about.About(self, -1, "About PySoulSeek").ShowModal()

    def callback(self,msgs):
	""" Callback function called by networking thread."""
	wxPostEvent(self, NetworkEvent(self.EVT_NETWORK_ID,msgs))

    def OnNetworkEvent(self, event):
	""" Processes messages from networking thread."""
	for i in event.msgs:
	    if self.np.events.has_key(i.__class__):
		self.np.events[i.__class__](i)
	    else:
		wxLogMessage("%s %s" % (i.__class__, vars(i)))

    def EVT_NETWORK(self, win, id, func):
	""" Network event macro """
	win.Connect(-1, -1, id, func) 

class MainApp(wxApp): 
    """ Application class. """
    def OnInit(self):
	wxInitAllImageHandlers()
        self.frame = MainFrame(None,-1,'PySoulSeek') 
        self.frame.Show(true) 
        self.SetTopWindow(self.frame) 
        return true 


