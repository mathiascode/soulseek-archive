# Copyright (c) 2001-2002 Alexander Kanavin. All rights reserved.

"""
This module provides an About dialog box
"""

from wxPython.wx import *
import images

class About(wxDialog):

    def __init__(self, parent, id, title):
        wxDialog.__init__(self,parent,id,title)

	sizer = wxStaticBoxSizer(wxStaticBox(self,-1,""),wxHORIZONTAL)

	mainsizer = wxBoxSizer(wxVERTICAL)

	img = images.getBirdBitmap()
        ok = wxButton(self, wxID_OK, "OK")
        ok.SetDefault()

	sizer.Add(wxStaticBitmap(self,-1,img,size=wxSize(img.GetWidth(), img.GetHeight())), flag=wxALL, border = 5)
	sizer.Add(wxStaticText(self,-1,"PySoulSeek 0.3.0\nCopyright (c) 2001-2002 by Alexander Kanavin\nhttp://www.sensi.org/~ak/\nak@sensi.org\n\nReleased under the GNU general public license",style=wxALIGN_CENTRE), flag = wxALL, border = 5)

	mainsizer.Add(sizer, flag=wxALL,border = 5)
	mainsizer.Add(ok, flag = wxALL|wxALIGN_CENTER,border = 10)
        self.SetSizer(mainsizer)
        self.SetAutoLayout(true)
        mainsizer.Fit(self)

