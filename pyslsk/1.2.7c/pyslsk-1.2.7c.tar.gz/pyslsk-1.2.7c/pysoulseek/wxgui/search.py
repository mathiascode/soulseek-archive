# Copyright (c) 2001-2003 Alexander Kanavin. All rights reserved.

"""
This module contains GUI classes for displaying search results.
"""

import time
from pysoulseek import slskproto
from pysoulseek import slskmessages
import Queue
import threading
import images
import about
import userinfobrowse
import search
import notebook
from sortablelist import sortableListCtrl
from wxPython.wx import *
import locale

class SearchWindow(wxPanel):
    """ A search window with notebook that contains search results.
    searches contains pointers to windows that display them."""
    def __init__(self, parent, id, queue, processrequest, privatechat, info, browse, transfers, onupdate,frame):
        wxPanel.__init__(self, parent, id)
        self.queue = queue
        self.processrequest = processrequest
	self.privatechat = privatechat
        self.info = info
        self.browse = browse
        self.transfers = transfers
	self.onupdate = onupdate
	self.frame = frame
	self.context = wxRadioBox(self, -1, "", choices = ["Global","Buddies","Joined rooms"], style = wxRA_SPECIFY_COLS | wxNO_BORDER)
	self.search =  wxComboBox(self,-1, choices=[""]+self.frame.np.config.sections["searches"]["history"])
        self.searchbutton = wxButton(self, -1, "Search")
        self.resultsnb = notebook.IconNotebook(self, -1, style = wxCLIP_CHILDREN)
        sizerh = wxBoxSizer(wxHORIZONTAL)
        sizerh.Add(self.search,1,wxALIGN_CENTER)
        sizerh.Add(self.searchbutton,0,wxALIGN_CENTER)
	sizerh.Add(self.context,0,wxALIGN_CENTER)
        sizerv = wxBoxSizer(wxVERTICAL)
        sizerv.Add(sizerh,0,wxEXPAND)
        sizerv.Add(self.resultsnb,1,wxEXPAND)

        self.SetSizer(sizerv)
        self.SetAutoLayout(True)

        self.interval = 0
        timerid = wxNewId()
        self.timer = wxTimer(self, timerid)
        self.searches = {}

        EVT_BUTTON(self, self.searchbutton.GetId(), self.OnSearch)
        EVT_TEXT_ENTER(self,self.search.GetId(), self.OnSearch)
	EVT_TIMER(self, timerid, self.OnTimer)
        for autosearch in frame.np.config.sections["server"]["autosearch"]:
            self.CreateTab(autosearch, True)


    def SetInterval(self, msg):
    	self.interval = msg.num
        self.timer.Start(self.interval*1000)
        self.AutoSearch()

    def AutoSearch(self):
        autosearches = self.frame.np.config.sections["server"]["autosearch"]
        if len(autosearches) == 0:
            return
	autosearch = autosearches.pop(0)
	autosearches.append(autosearch)
        for i in self.searches.keys():
            if self.searches[i][1] == autosearch and self.searches[i][2]:
                self.queue.put(slskmessages.WishlistSearch(i,autosearch))
                break
        else:
            # This should never happen.. But better safe than sorry
	    self.frame.np.config.sections["server"]["autosearch"].remove(autosearch)
	    self.frame.np.config.writeConfig()

    def OnTimer(self, event):
        self.AutoSearch()

    def OnSearch(self, event):
        """ Process search request"""
	context = self.context.GetSelection()
        text = wxGetApp().encode(self.search.GetValue())
        if not text.strip():
            return
        history = self.frame.np.config.sections["searches"]["history"]
        if text in history:
            history.remove(text)
        elif len(history) > 9:
           del history[-1]
        history.insert(0, text)
        self.frame.np.config.writeConfig()
        self.search.Clear()
        self.search.Append("")
        for item in history:
            self.search.Append(item)
	if context == 0:
	    self.DoGlobalSearch(text)
	elif context == 1:
	    self.DoBuddySearch(text)
	elif context == 2:
	    self.DoRoomsSearch(text)
        self.search.SetValue("")

    def CreateTab(self, text, auto, title = None):
	requestid = wxNewId()
	tab, list = self.MakeSearchTab(requestid)
	if auto:
	    tab.rememberctrl.SetValue(1)
        self.searches[requestid] = [list, text, auto]
        if title is None:
	    self.resultsnb.AddPage(tab,text)
	else:
	    self.resultsnb.AddPage(tab,"%s (%s)" %(text,title))
	return requestid

    def DoGlobalSearch(self, text):
        requestid = self.CreateTab(text, False)
        self.queue.put(slskmessages.FileSearch(requestid,text))

    def DoBuddySearch(self, text):
        users = [i[0] for i in self.frame.np.userlist.userlist if i[4] > 0]
        self.DoPeerSearch(text, users, "buddies")

    def DoRoomsSearch(self, text):
        roomlist = self.frame.np.chatrooms.roomsctrl.joinedroomslist
	users = []
	requestid = self.CreateTab(text, None, "rooms")
	for i in roomlist:
	    self.queue.put(slskmessages.RoomSearch(requestid,text,i))
#	    users = users + self.frame.np.chatrooms.roomsctrl.joinedrooms[i].users.keys()
#	usersdict = {}
#	for i in users:
#	    usersdict[i] = i
#	users = usersdict.keys()
#	self.DoPeerSearch(text, users, "rooms")

    def DoPeerSearch(self, text, users, title = ""):
	requestid = self.CreateTab(text, None, title)
        for user in users:
	     self.queue.put(slskmessages.UserSearch(requestid,text,user))
#            self.processrequest(user, slskmessages.FileSearchRequest(None,requestid,text))
 

    def ShowResult(self, msg, username):
        """ Show search result."""
        if self.searches.has_key(msg.token):
            if self.searches[msg.token][0] is None:
                text = self.searches[msg.token][1]
		remember = self.searches[msg.token][2]
                tab, list = self.MakeSearchTab(msg.token, not remember is None)
                self.searches[msg.token] = [list, text, remember]
                self.resultsnb.AddPage(tab,text)
            self.searches[msg.token][0].AddResult(msg, username)
	    self.onupdate(self)
	    self.resultsnb.OnPageUpdated(self.searches[msg.token][0].parent)

    def MakeSearchTab(self, requestid, canRemember = True):
        """ Create a result window, which is a notebook tab. """
        panel = wxPanel(self.resultsnb, -1)
        close = wxButton(panel, -1, "Close")
	ignore = wxButton(panel, -1, "Ignore")
	closeignore = wxButton(panel, -1, "Close and Ignore")
	panel.rememberctrl = wxCheckBox(panel, -1, label = "Repeat every %d seconds" %(self.interval))
        list = SearchList(panel, -1, self.processrequest, self.privatechat, self.info, self.browse, self.transfers,self.frame)
        sizerh = wxBoxSizer(wxHORIZONTAL)
        sizerh.Add((60,10),1,wxEXPAND)
	sizerh.Add(closeignore)
        sizerh.Add(ignore)
        sizerh.Add(close)
	sizerh.Add(panel.rememberctrl)
        sizerv = wxBoxSizer(wxVERTICAL)
        sizerv.Add(sizerh,0,wxEXPAND)
        sizerv.Add(list,1,wxEXPAND)
        panel.SetSizer(sizerv)
        panel.SetAutoLayout(True)
        EVT_BUTTON(self, close.GetId(), self.OnClose)
	EVT_BUTTON(self, ignore.GetId(), self.OnIgnore)
	EVT_BUTTON(self, closeignore.GetId(), self.OnCloseIgnore)
        EVT_CHECKBOX(self, panel.rememberctrl.GetId(), self.OnRememberCheckClick)
        if not canRemember:
           panel.rememberctrl.Enable(0)

        return panel,list

    def RemoveSearches(self, selectednum, ignore):
        selected = self.resultsnb.GetPage(selectednum)
        for i in self.searches.keys():
            if self.searches[i][0] is not None and self.searches[i][0].GetParent() == selected:
                self.searches[i] = [None,self.searches[i][1], self.searches[i][2]]
                if self.searches[i][1] in self.frame.np.config.sections["server"]["autosearch"]:
                   self.frame.np.config.sections["server"]["autosearch"].remove(self.searches[i][1])
                   self.frame.np.config.writeConfig()

		if ignore:
                    del self.searches[i]
                    title = "(Ig) " + self.resultsnb.GetPageText(selectednum)
                    self.resultsnb.SetPageText(selectednum, title)

        
    def Close(self, ignore):
        """ Close the search results window."""
        selectednum = self.resultsnb.GetSelection()
        self.RemoveSearches(selectednum, ignore)
	parent = self.resultsnb
        self.resultsnb.DeletePage(selectednum)
	if parent.GetPageCount() > 0:
	    parent.SetSelection(0)

    def OnClose(self, event):
	self.Close(0)

    def OnIgnore(self, event):
        selectednum = self.resultsnb.GetSelection()
	self.RemoveSearches(selectednum, 1)

    def OnCloseIgnore(self, event):
	self.Close(1)

    def OnRememberCheckClick(self, event):
	value = event.GetEventObject().GetValue()
	panel = event.GetEventObject().GetParent()
	for id,(list,text,remember) in self.searches.items():
	     if list is not None and list.GetParent() == panel:
		if value:
		    self.frame.np.config.sections["server"]["autosearch"].append(text)
		else:
		    self.frame.np.config.sections["server"]["autosearch"].remove(text)
	     self.frame.np.config.writeConfig()
	     self.searches[id][2] = value

class SearchList(sortableListCtrl):
    """ List of search results."""
    def __init__(self, parent, id, processrequest, privatechat, info, browse, transfers,frame,style = wxLC_REPORT|wxLC_VIRTUAL|wxLC_VRULES|wxSUNKEN_BORDER):
        sortableListCtrl.__init__(self,parent,id,style = style)
	self.InsertColumn(0,"", width = 30,format=wxLIST_FORMAT_RIGHT)
        self.InsertColumn(1,"Filename", width=250)
        self.InsertColumn(2,"User", width = 100)
        self.InsertColumn(3,"Size",width=100,format=wxLIST_FORMAT_RIGHT)
	self.InsertColumn(4,"Speed",width=50,format=wxLIST_FORMAT_RIGHT)
	self.InsertColumn(5,"In queue",width=50,format=wxLIST_FORMAT_RIGHT)
	self.InsertColumn(6,"Immediate download",width=20)
        self.InsertColumn(7,"Bitrate",width=50,format=wxLIST_FORMAT_RIGHT)
	self.InsertColumn(8,"Length",width=50,format=wxLIST_FORMAT_RIGHT)
        self.InsertColumn(9,"Directory",width=500)
        self.SetItemCount(0)

        self.normal = wxListItemAttr()
        self.grey = wxListItemAttr()
        self.grey.SetTextColour("darkgrey")
        self.red = wxListItemAttr()
        self.red.SetTextColour("red")

        self.parent = parent
        self.processrequest = processrequest
        self.privatechat = privatechat
        self.info = info
        self.browse = browse
        self.transfers = transfers
	self.frame = frame

        self.results = []

        self.menu = wxMenu()
        downloadID=wxNewId()
        self.menu.Append(downloadID, 'Download File(s)')
        EVT_MENU(self,downloadID, self.OnDownload)
        downloadfolderID=wxNewId()
        self.menu.Append(downloadfolderID, 'Download Containing Folder')
        EVT_MENU(self,downloadfolderID, self.OnDownloadFolder)
	self.menu.AppendSeparator()
        sendmessageID=wxNewId()
        self.menu.Append(sendmessageID, 'Send Message')
        EVT_MENU(self,sendmessageID, self.OnSendMessage)
        getinfoID=wxNewId()
        self.menu.Append(getinfoID, 'Get User Info')
        EVT_MENU(self,getinfoID, self.OnGetInfo)
        browseID=wxNewId()
        self.menu.Append(browseID, 'Browse Files')
        EVT_MENU(self,browseID, self.OnBrowse)
        showIpID=wxNewId()
        self.menu.Append(showIpID, "Show IP address")
        EVT_MENU(self,showIpID, self.OnShowIP)
        addtolistID=wxNewId()
        self.menu.Append(addtolistID, 'Add to User List')
        EVT_MENU(self,addtolistID, self.OnAddToList)
        banuserID=wxNewId()
        self.menu.Append(banuserID, 'Ban this User')
        EVT_MENU(self,banuserID, self.OnBanUser)

        EVT_RIGHT_UP(self,self.OnRightUp)


    def OnRightUp(self,event):
        """ Pops up a menu on a right-click in users list."""
	pt = event.GetPosition()
        item, flags = self.HitTest(pt)
        self.id = item
	if item >= 0:
            self.selecteduser = self.results[self.id][2]
    	    self.SetItemState(item,wxLIST_STATE_FOCUSED,wxLIST_STATE_FOCUSED)
            self.PopupMenu(self.menu, pt)

    """ Handlers for the menu items"""
    def OnSendMessage(self, event):
        self.privatechat.SendMessage(self.selecteduser)

    def OnGetInfo(self, event):
        self.processrequest(self.selecteduser, slskmessages.UserInfoRequest(None), self.info)

    def OnBrowse(self, event):
        self.processrequest(self.selecteduser, slskmessages.GetSharedFileList(None), self.browse)

    def OnAddToList(self, event):
        self.frame.np.userlist.AddToList(self.selecteduser)

    def OnBanUser(self, event):
        self.frame.BanUser(self.selecteduser)

    def OnShowIP(self, event):
        self.frame.np.queue.put(slskmessages.GetPeerAddress(self.selecteduser))


    def OnDownload(self, event):
        item = -1
        while 1:
            item = self.GetNextItem(item,wxLIST_NEXT_ALL,wxLIST_STATE_SELECTED|wxLIST_STATE_FOCUSED)
            if item == -1:
                break
            self.transfers.getFile(self.results[item][2],self.results[item][9]+self.results[item][1])

    def OnDownloadFolder(self,event):
        self.processrequest(self.selecteduser, slskmessages.FolderContentsRequest(None,self.results[self.id][9]))
 
    def AddResult(self, msg, username):
        """ Add a result to the list."""
        for i in msg.list:
            name = i[1].split('\\')[-1]
            dir = i[1][:-len(name)]
            user = username
            size = i[2]

            if i[3] == 'mp3' and len(i[4]) == 3:
                attrs = i[4]
                if attrs[2] == 1:
                    brs = '(vbr)'
                else:
                    brs = ''
                bitrate = str(attrs[0]) + brs
                length = '%i:%02i' %(attrs[1] / 60, attrs[1] % 60)
            elif i[3] == '':
                bitrate = length =  ""
            else:
                bitrate = length = str(i[4])
	    if msg.freeulslots:
		immdownload = "Y"
	    else:
		immdownload = ""
            self.results.append([len(self.results)+1,name,user,size,msg.ulspeed,msg.inqueue,immdownload,bitrate,length,dir])
	if self.sortcol != -1:
	    self.SortList(self.sortcol, self.sortorder)
        self.SetItemCount(len(self.results))

    def OnGetItemText(self, item, col):
	import types
	text = self.results[item][col]
	if type(text) == types.StringType:
	    if len(text) > 0:
	        return wxGetApp().decode(text)
	    else:
		return ''
	else:
            return locale.format("%s",text,1)

    def OnGetItemAttr(self, item):
        if self.results[item][6] == "":
            return self.grey
        else:
            return self.normal

    def OnGetItemImage(self, item):
	return -1

    def SortList(self, col, order):
        if order == 0:
            self.results.sort(lambda x,y: self.cmp(x[col],y[col]))
        else:
            self.results.sort(lambda y,x: self.cmp(x[col],y[col]))

