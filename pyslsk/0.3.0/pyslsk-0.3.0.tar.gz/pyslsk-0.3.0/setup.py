#!/usr/local/bin/python

"""To use this setup script to install PySoulSeek:

        python setup.py install

"""

import sys
import os

from distutils.core import setup

if __name__ == '__main__' :
#    DOC_FILES = [ 'CHANGELOG', 'COPYING', 'KNOWN_BUGS', \
#    'MAINTAINERS', 'README', 'slskproto.txt', 'TODO','VERSION', ]
    LONG_DESCRIPTION = \
""" PySoulSeek is a client for SoulSeek filesharing system. 
"""
    versionf = open("VERSION")

    import encode_bitmaps
    encode_bitmaps.encode()

    setup(name                  = "pyslsk",
          version               = versionf.readline(),
          license               = "GPL",
          description           = "Client for SoulSeek filesharing system.",
          author                = "Alexander Kanavin",
          author_email          = "ak@sensi.org",
          url                   = "http://www.sensi.org/~ak/pyslsk/",
          packages              = [ 'pysoulseek' ],
#         data_files            = DOC_FILES,
          scripts               = [ 'pyslsk.py', ],
          long_description      = LONG_DESCRIPTION
         )

