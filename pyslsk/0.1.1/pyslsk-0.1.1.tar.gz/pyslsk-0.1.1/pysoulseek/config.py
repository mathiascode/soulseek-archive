# Copyright (c) 2001-2002 Alexander Kanavin. All rights reserved.

"""
This module contains configuration classes for pyslsk.
"""

import ConfigParser
import string
import os.path

class Config:
    """ 
    This class holds configuration information and provides the 
    following methods:

    needConfig() - returns true if configuration information is incomplete
    readConfig() - reads configuration information from ~/.pyslsk
    setConfig(config_info_dict) - sets configuration information
    writeConfig - writes configuration information to ~/.pyslsk

    The actual configuration information is stored as a two-level dictionary.
    First-level keys are config sections, second-level keys are config 
    parameters.
    """
    def __init__(self):
	self.parser = ConfigParser.ConfigParser()
	self.parser.read([os.path.join(os.path.expanduser("~"),'.pyslsk')])
	self.sections = {"server":{"server":None,"login":None,"passw":None},"transfers":{"downloaddir":None,"shared":None,"uploadbandwidth":None,"downloads":[]}}

    def needConfig(self):
	for i in self.sections.keys():
	    for j in self.sections[i].keys():
		if self.sections[i][j] is None or self.sections[i][j] == '':
		    return 1
	return 0

    def readConfig(self):
	for i in self.parser.sections():
	    for j in self.parser.options(i):
		val = self.parser.get(i,j)
		if j == 'server' or j == 'shared' or j == 'uploadbandwidth' or j == 'downloads':
		    try:
		        self.sections[i][j] = eval(val)
		    except:
			self.sections[i][j] = None
		else:
		    self.sections[i][j] = val
 
    def setConfig(self, sections):
	for i in sections.keys():
	    if not self.parser.has_section(i):
	 	self.parser.add_section(i)
	    if not self.sections.has_key(i):
		self.sections[i] = sections[i]
	    for j in sections[i].keys():
		self.parser.set(i,j,sections[i][j])
		self.sections[i][j] = sections[i][j]

    def writeConfig(self):
	f = open(os.path.join(os.path.expanduser("~"),'.pyslsk'),"w")
	self.parser.write(f)
	f.close()

from wxPython.wx import *

class ServerList(wxListCtrl):
    """ This is a list control that contains list of official servers """
    def __init__(self,parent,id, size, style = wxLC_REPORT|wxLC_VIRTUAL|wxSUNKEN_BORDER):
	wxListCtrl.__init__(self,parent,id, style = style, size = size)
	self.InsertColumn(0,"Description", width=250)
	self.InsertColumn(1,"Hostname",width=150)
	self.SetItemCount(0)

    def setList(self,list):
	self.SetItemCount(len(list))
	self.list = list

    def OnGetItemText(self, item,col):
	return self.list[item][col]

class ServerChoose(wxDialog):
    """ This class defines a servers list window that is used to let user
	select one of the official servers from the list """
    def __init__(self,parent,id, title):
	wxDialog.__init__(self,parent,id,title)

	self.serverlistctrl = ServerList(self, -1, size=wxSize(420,200))
        self.ok = wxButton(self, wxID_OK, "OK")
        self.ok.SetDefault()
        self.cancel = wxButton(self, wxID_CANCEL, "Cancel")

        buttonssizer = wxBoxSizer(wxHORIZONTAL)
        buttonssizer.Add(self.ok)
        buttonssizer.Add(60,20)
        buttonssizer.Add(self.cancel)

        mainsizer = wxBoxSizer(wxVERTICAL)
        mainsizer.Add(self.serverlistctrl,flag=wxALL, border = 10)
        mainsizer.Add(buttonssizer,flag=wxALL|wxALIGN_CENTER, border = 10)
        self.SetSizer(mainsizer)
        self.SetAutoLayout(true)
        mainsizer.Fit(self)
	self.CenterOnParent()

	serverlist=self.getServerList("http://www.soulseek.org/slskinfo")
	self.serverlistctrl.setList(serverlist)

    def getServerList(self,url):
	""" Parse server text file from http://www.soulseek.org and 
	return a list of servers """
	import urllib,string
	try:
	    f = urllib.urlopen(url)
	    list = [string.strip(i) for i in f.readlines()]
	except:
	    return []
	try:
	    list = list[list.index("--servers")+1:]
	except:
	    return []
	list = [string.split(i,":",2) for i in list]
	try:
	    return [[i[0],i[2]]  for i in list]
	except:
	    return []

    def getServer(self):
	item = self.serverlistctrl.GetNextItem(-1,wxLIST_NEXT_ALL,wxLIST_STATE_SELECTED)
	if item == -1:
	    return None
	else:
	    return self.serverlistctrl.list[item][1]

class ConfigWindow(wxDialog):
    """
    This class defines a settings window that the main application should 
    display on request. 

    Methods:
    SetSettings(config) - fills widgets in the window 
    with provided values
    GetSettings - returns a tuple of settings from window widgets (possibly 
    modified by user
    """
    def __init__(self, parent, id, title):
	wxDialog.__init__(self,parent,id,title)

	self.serverctrl = wxTextCtrl(self,-1,size=wxSize(250, 25))
	self.loginctrl = wxTextCtrl(self,-1,size=wxSize(100, 25))
	self.passwctrl = wxTextCtrl(self,-1,size=wxSize(100, 25))
	self.serverchoose = wxButton(self, -1, "Choose...")
	EVT_BUTTON(self,self.serverchoose.GetId(),self.OnServerChoose)

	hostsizer = wxBoxSizer(wxHORIZONTAL)
	hostsizer.Add(self.serverctrl)
	hostsizer.Add(self.serverchoose,flag=wxALIGN_CENTER)

	serversizer = wxStaticBoxSizer(wxStaticBox(self,-1,"Server settings:"),wxVERTICAL)
	serversizer.Add(wxStaticText(self, -1, "Server (hostname:port):"),flag=wxTOP|wxLEFT, border = 10)
	serversizer.Add(hostsizer,flag=wxLEFT|wxRIGHT, border = 10)
	serversizer.Add(wxStaticText(self, -1, "Login:"),flag=wxTOP|wxLEFT, border = 10)
	serversizer.Add(self.loginctrl,flag=wxLEFT, border = 10)
	serversizer.Add(wxStaticText(self, -1, "Password:"),flag=wxTOP|wxLEFT, border = 10)
	serversizer.Add(self.passwctrl,flag=wxLEFT|wxBOTTOM, border = 10)

	self.downloaddirctrl = wxTextCtrl(self,-1,size=wxSize(250, 25))
	self.uploaddirsctrl = wxListBox(self, -1, size=wxSize(250,100))
	self.uploadbandwidth = wxTextCtrl(self,-1,size=wxSize(30, 25))
	self.downloaddirchoose = wxButton(self, -1, "Choose...")
	self.uploaddiradd = wxButton(self, -1, "Add...")
	self.uploaddirrem = wxButton(self, -1, "Remove")
	EVT_BUTTON(self,self.downloaddirchoose.GetId(),self.OnDownloadChoose)
	EVT_BUTTON(self,self.uploaddiradd.GetId(),self.OnUploadAdd)
	EVT_BUTTON(self,self.uploaddirrem.GetId(),self.OnUploadRem)

	downloadsizer = wxBoxSizer(wxHORIZONTAL)
        downloadsizer.Add(self.downloaddirctrl)
        downloadsizer.Add(self.downloaddirchoose,flag=wxALIGN_CENTER)
	
	uploadbuttonssizer = wxBoxSizer(wxVERTICAL)
        uploadbuttonssizer.Add(self.uploaddiradd)
        uploadbuttonssizer.Add(self.uploaddirrem)
	uploadsizer = wxBoxSizer(wxHORIZONTAL)
	uploadsizer.Add(self.uploaddirsctrl)
	uploadsizer.Add(uploadbuttonssizer)

	bandwidthsizer = wxBoxSizer(wxHORIZONTAL)
	bandwidthsizer.Add(wxStaticText(self, -1, "upload speed exceeds "),flag=wxALIGN_CENTER)
	bandwidthsizer.Add(self.uploadbandwidth)
	bandwidthsizer.Add(wxStaticText(self, -1, " KBytes/sec"),flag=wxALIGN_CENTER)
	
	transferssizer = wxStaticBoxSizer(wxStaticBox(self,-1,"Transfers settings:"),wxVERTICAL)
	transferssizer.Add(wxStaticText(self, -1, "Download directory:"),flag=wxTOP|wxLEFT, border = 10)
	transferssizer.Add(downloadsizer,flag=wxLEFT|wxRIGHT, border = 10)
	transferssizer.Add(wxStaticText(self, -1, "Shared directories:"),flag=wxTOP|wxLEFT, border = 10)
	transferssizer.Add(uploadsizer, flag=wxLEFT|wxRIGHT, border = 10)
	transferssizer.Add(wxStaticText(self, -1, "Locally queue remote requests if current"),flag=wxTOP|wxLEFT, border = 10)
	transferssizer.Add(bandwidthsizer,flag=wxBOTTOM|wxLEFT, border = 10)

	settingssizer=wxBoxSizer(wxVERTICAL)
	settingssizer.Add(serversizer, flag=wxALL,border = 5)
	settingssizer.Add(transferssizer, flag=wxALL,border = 5)

	self.ok = wxButton(self, wxID_OK, "OK")
	self.ok.SetDefault()
	self.cancel = wxButton(self, wxID_CANCEL, "Cancel")

	buttonssizer = wxBoxSizer(wxHORIZONTAL)
	buttonssizer.Add(self.ok)
	buttonssizer.Add(60,20)
	buttonssizer.Add(self.cancel)

	mainsizer = wxBoxSizer(wxVERTICAL)
	mainsizer.Add(settingssizer,1,wxEXPAND)
	mainsizer.Add(buttonssizer,flag=wxALL|wxALIGN_CENTER, border = 10)
	self.SetSizer(mainsizer)
	self.SetAutoLayout(true)
	mainsizer.Fit(self)

    def OnServerChoose(self,event):
	serverchoose = ServerChoose(self,-1,"Choose server")
	val = serverchoose.ShowModal()
	if val == wxID_OK:
	    server = serverchoose.getServer()
	    if server is not None:
		self.serverctrl.SetValue(server)

    def OnDownloadChoose(self,event):
	downloadchoose = wxDirDialog(self)
	val = downloadchoose.ShowModal()
	if val == wxID_OK:
	    dir = downloadchoose.GetPath()
	    if dir is not None:
		self.downloaddirctrl.SetValue(dir)

    def OnUploadAdd(self,event):
        uploadadd = wxDirDialog(self)
        val = uploadadd.ShowModal()
        if val == wxID_OK:
            dir = uploadadd.GetPath()
            if dir is not None:
                self.uploaddirsctrl.Append(dir)

    def OnUploadRem(self,event):
	num = self.uploaddirsctrl.GetSelection()
	self.uploaddirsctrl.Delete(num)

    def SetSettings(self, config):
	server = config.sections["server"]
	transfers = config.sections["transfers"]
	if server["server"] is not None:
    	    self.serverctrl.SetValue(string.join([str(i) for i in server["server"]],":"))
	if server["login"] is not None:
	    self.loginctrl.SetValue(server["login"])
	if server["passw"] is not None:
	    self.passwctrl.SetValue(server["passw"])
	if transfers["downloaddir"] is not None:
	    self.downloaddirctrl.SetValue(transfers["downloaddir"])
	if transfers["shared"] is not None:
	    for i in transfers["shared"]:
		self.uploaddirsctrl.Append(i)
	if transfers["uploadbandwidth"] is not None:
	    self.uploadbandwidth.SetValue(str(transfers["uploadbandwidth"]))

    def GetSettings(self):
        try:
            server = string.split(self.serverctrl.GetValue(),":")
            server[1] = string.atoi(server[1])
	    server = tuple(server)
        except:
            server = None
	shared = []
	for i in range(self.uploaddirsctrl.Number()):
	    shared.append(self.uploaddirsctrl.GetString(i))
	return {"server":{"server":server, "login":self.loginctrl.GetValue(), "passw":self.passwctrl.GetValue()},"transfers":{"downloaddir":self.downloaddirctrl.GetValue(), "shared":shared, "uploadbandwidth":self.uploadbandwidth.GetValue()}}

