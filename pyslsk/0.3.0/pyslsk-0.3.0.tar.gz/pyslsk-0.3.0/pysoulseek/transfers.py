# Copyright (c) 2001-2002 Alexander Kanavin. All rights reserved.

""" This module contains classes that deal with file transfers: the 
transfer manager, and GUIs.
"""

from wxPython.wx import *
import slskmessages
import os
import pysoulseek
import string

class TransfersList(wxListCtrl):
    """ This is a list control for transfers. Gets transfer data from transfer
    manager.
    """
    def __init__(self, parent, id, list, style = wxLC_REPORT|wxLC_VIRTUAL|wxSUNKEN_BORDER):
        wxListCtrl.__init__(self,parent,id, style = style)
	self.list = list
	self.InsertColumn(0,"Filename", width = 250)
	self.InsertColumn(1,"User", width = 100)
	self.InsertColumn(2,"Status", width  = 150)
	self.InsertColumn(3,"Size", width = 100)
	self.InsertColumn(4,"Path", width = 100)
	self.SetItemCount(len(list))


    def OnGetItemText(self, item,col):
	item = self.list[item]
	if col == 0:
	    return string.split(item.filename,'\\')[-1]
	if col == 1:
	    return item.user
	if col == 2:
	    return item.status
	if col == 3:
	    return item.size
	if col == 4:
	    return item.path

class TransfersPanel(wxPanel):
    """ This is the transfer panel that contains transfers list control.
    The right-click pop--up menu is implemented here."""
    def __init__(self, parent, id, list, eventprocessor, transfermanager):
	wxPanel.__init__(self,parent,id)
	self.list = list
	self.eventprocessor = eventprocessor
	self.transfermanager = transfermanager

	self.processrequest = self.eventprocessor.frame.ProcessRequestToPeer
	self.info = self.eventprocessor.frame.userinfo
	self.browse = self.eventprocessor.frame.userbrowse
	self.privatechat = self.eventprocessor.frame.privatechat
	self.users = self.transfermanager.users
	self.queue = self.eventprocessor.frame.queue
	self.listctrl = TransfersList(self,-1,list)
	sizer = wxBoxSizer(wxVERTICAL)
	sizer.Add(self.listctrl,1,wxEXPAND, border = 10)
	self.SetSizer(sizer)
	self.SetAutoLayout(true)

	self.menu = wxMenu()
        sendmessageID=wxNewId()
        self.menu.Append(sendmessageID, 'Send Message')
        EVT_MENU(self,sendmessageID, self.OnSendMessage)
        getinfoID=wxNewId()
        self.menu.Append(getinfoID, 'Get User Info')
        EVT_MENU(self,getinfoID, self.OnGetInfo)
        browseID=wxNewId()
        self.menu.Append(browseID, 'Browse Files')
        EVT_MENU(self,browseID, self.OnBrowse)
	self.menu.AppendSeparator()

        abortID=wxNewId()
        self.menu.Append(abortID, 'Abort')
        EVT_MENU(self,abortID, self.OnAbort)
        retryID=wxNewId()
        self.menu.Append(retryID, 'Retry')
        EVT_MENU(self,retryID, self.OnRetry)
        clearID=wxNewId()
        self.menu.Append(clearID, 'Clear')
        EVT_MENU(self,clearID, self.OnClear)
        self.menu.AppendSeparator()

        clearfaID=wxNewId()
        self.menu.Append(clearfaID, 'Clear finished/aborted')
        EVT_MENU(self,clearfaID, self.OnClearFinAb)
        clearfID=wxNewId()
        self.menu.Append(clearfID, 'Clear finished')
        EVT_MENU(self,clearfID, self.OnClearFin)
        clearaID=wxNewId()
        self.menu.Append(clearaID, 'Clear aborted')
        EVT_MENU(self,clearaID, self.OnClearAb)
        clearqID=wxNewId()
        self.menu.Append(clearqID, 'Clear queued')
        EVT_MENU(self,clearqID, self.OnClearQueued)


	EVT_RIGHT_UP(self.listctrl, self.OnRightUp)

    def update(self):
	""" Call this to make the transfer panel update the data."""
	self.listctrl.SetItemCount(len(self.list))

    def OnRightUp(self, event):
	""" Show the pop-up menu"""
        pt = event.GetPosition()
        item, flags = self.listctrl.HitTest(pt)
	self.item = item
        self.listctrl.SetItemState(item,wxLIST_STATE_FOCUSED,wxLIST_STATE_FOCUSED)
        self.listctrl.PopupMenu(self.menu, pt)

    """ Handlers for the menu items """

    def OnSendMessage(self, event):
	""" Sends user a private message """
        self.privatechat.SendMessage(self.list[self.item].user)

    def OnGetInfo(self, event):
	""" Gets info about a user """
	user = self.list[self.item].user
        if user in self.users.keys() and self.users[user].status > 0:
            self.processrequest(user, slskmessages.UserInfoRequest(None), self.info)

    def OnBrowse(self, event):
	""" Browse user's files """
	user = self.list[self.item].user
        if user in self.users.keys() and self.users[user].status > 0:
            self.processrequest(user, slskmessages.GetSharedFileList(None), self.browse)

    def OnAbort(self, event):
	""" Abort all selected transfers """
	item = -1
	while 1:
	    item = self.listctrl.GetNextItem(item,wxLIST_NEXT_ALL,wxLIST_STATE_SELECTED|wxLIST_STATE_FOCUSED)
	    if item == -1:
		break

	    transfer = self.list[item]
            if transfer.status != "Finished" and transfer.status != "Old":
                if transfer.conn is not None:
                    self.queue.put(slskmessages.ConnClose(transfer.conn))
                    transfer.conn = None
                if transfer.file is not None:
                    try:
                        transfer.file.close()
                    except:
                        pass
                transfer.status = "Aborted"
		transfer.req = None
		transfer.remotereq = None
	self.update()

    def OnRetry(self,event):
	""" Retry all selected transfers, if they're not active 
	and not finished and a user is online """
        item = -1
        while 1:
            item = self.listctrl.GetNextItem(item,wxLIST_NEXT_ALL,wxLIST_STATE_SELECTED|wxLIST_STATE_FOCUSED)
            if item == -1:
                break
            transfer = self.list[item]
            if transfer.status != "Finished" and transfer.status != "Old":
                if transfer.conn is not None:
                    self.queue.put(slskmessages.ConnClose(transfer.conn))
                    transfer.conn = None
                if transfer.file is not None:
                    try:
                        transfer.file.close()
                    except:
                        pass
                transfer.req = None
                transfer.remotereq = None
		self.transfermanager.getFile(transfer.user, transfer.filename, transfer.path, transfer)

    def OnClear(self,event):
	""" Remove all selected transfers. Abort those that are in progress."""
        item = -1
        while 1:
            item = self.listctrl.GetNextItem(item,wxLIST_NEXT_ALL,wxLIST_STATE_SELECTED|wxLIST_STATE_FOCUSED)
            if item == -1:
                break
            transfer = self.list[item]
            if transfer.conn is not None:
                self.queue.put(slskmessages.ConnClose(transfer.conn))
            if transfer.file is not None:
                try:
                    transfer.file.close()
                except:
                    pass
	    self.list[item] = None
	while self.list.count(None) > 0:
	    self.list.remove(None)
	self.update()

    def OnClearFinAb(self,event):
	""" Remove all finished or aborted transfers"""
	for i in self.list:
	    if i.status == "Finished" or i.status == "Aborted":
		self.list.remove(i)
	self.update()

    def OnClearFin(self,event):
	""" Remove just the finished transfers."""
        for i in self.list:
            if i.status == "Finished":
                self.list.remove(i)
        self.update()

    def OnClearAb(self,event):
	""" Remove just the aborted transfers. """
        for i in self.list:
            if i.status == "Aborted":
                self.list.remove(i)
        self.update()

    def OnClearQueued(self,event):
	""" Remove all (locally or remotely) queued transfers. """
        for i in self.list:
            if i.status == "Queued":
                self.list.remove(i)
        self.update()

class Transfer:
    """ This class holds information about a single transfer. """
    def __init__(self, conn = None, user = None, filename = None, path = None, status = None, req=None, remotereq = None, size = None, file = None):
	self.user = user
	self.filename = filename
	self.conn = conn
	self.path = path
	self.status = status
	self.req = req
	self.remotereq = remotereq
	self.size = size
	self.file = file

class Transfers:
    """ This is the transfers manager"""
    def __init__(self, parent, shareddirs, downloaddir, bandwidth, downloads, peerconns, queue, eventprocessor, users, frame):
	self.shareddirs = shareddirs
	self.downloaddir = downloaddir
	self.bandwidth = bandwidth
	self.peerconns = peerconns
	self.queue = queue
	self.eventprocessor = eventprocessor
#	self.sharedfiles = self.buildFileList(self.shareddirs)
	self.downloads = []
	for i in downloads:
	    self.downloads.append(Transfer(user = i[0], filename=i[1], path=i[2], status = 'Old'))
	    self.queue.put(slskmessages.GetUserStatus(i[0]))
	self.users = users
	self.downloadspanel = TransfersPanel(parent, -1, self.downloads, eventprocessor, self)
	self.frame = frame

    def getAddUser(self,msg):
	""" Server tells us it'll notify us about a change in user's status """
	if not msg.userexists:
	    wxLogMessage("User %s does not exist" % (msg.user))

    def GetUserStatus(self,msg):
	""" We get a status of a user and if he's online, we request a file from 	him """
	for i in self.downloads:
	    if msg.user == i.user and i.conn is None and i.req is None:
		if msg.status != 0:
                    self.getFile(i.user, i.filename, i.path, i)
	        else:
                    i.status = "User logged off"

    def getFile(self, user, filename, path="", transfer = None):
	""" Get a single file. path is a local path. if transfer object is 
	not None, update it, otherwise create a new one."""
	if user in self.users.keys():
	    addr = self.users[user].addr
	    behindfw = self.users[user].behindfw
	    status = self.users[user].status
	else:
	    addr = None
	    behindfw = None
	    status = None

	if status is None:
	    if transfer is None:
		self.downloads.append(Transfer(user = user, filename= filename, path=path, status = 'Old'))
            self.queue.put(slskmessages.GetUserStatus(user))

	else:
	    req = wxNewId()
	    if addr is None:
		status = "Getting address"
	    elif behindfw is None:
		status = "Connecting"
            else:
		status = "Waiting for peer to connect"
	    self.frame.ProcessRequestToPeer(user,slskmessages.TransferRequest(None,0,req,filename))
	    if transfer is None:
	        self.downloads.append(Transfer(user = user,filename = filename ,path = path ,status = status ,req = req))
	    else:
		transfer.status = status
		transfer.req = req
	    self.downloadspanel.update()
	    try:
		os.mkdir(os.path.join(self.downloaddir,path))
	    except:
		pass

    def gotAddress(self, req):
	""" A connection is in progress, we got the address for a user we need
	to connect to."""
	for i in self.downloads:
	    if i.req == req:
		i.status = "Connecting"
                self.downloadspanel.update()


    def gotConnectError(self,req):
	""" We couldn't connect to the user, now we are waitng for him to 
	connect to us. Note that all this logic is handled by the network
	event processor, we just provide a visual feedback to the user."""
	for i in self.downloads:
	    if i.req == req:
		i.status = "Waiting for peer to connect"
                self.downloadspanel.update()

    def gotCantConnect(self,req):
	""" We can't connect to the user, either way. """
	for i in self.downloads:
	    if i.req == req:
		i.status = "Cannot connect"
                self.downloadspanel.update()


    def gotConnect(self, req, conn):
	""" A connection has been established, now exchange initialisation
	messages."""
	for i in self.downloads:
	    if i.req == req:
		i.status = "Initializing"
		self.downloadspanel.update()

    def TransferRequest(self,msg):
	if msg.conn is not None:
	    user = msg.conn.user
	elif msg.tunneleduser is not None:
	    user = msg.tunneleduser
	else:
	    return
	if msg.direction == 1:
	    for i in self.downloads:
		if i.filename == msg.file and user == i.user:
		    i.size = msg.filesize
		    i.req = msg.req
		    i.status = "Waiting for connection"
		    response = slskmessages.TransferResponse(msg.conn,1,req = i.req)
                    self.downloadspanel.update()
		    break
	    else:
		response = slskmessages.TransferResponse(msg.conn,0,reason = "Cancelled")
		wxLogMessage("Denied file request: "+str(vars(msg)))
	    if msg.conn is not None:
		self.queue.put(response)
	    else:
		self.frame.ProcessRequestToPeer(user,response)
	    	

    def TransferResponse(self,msg):
	""" Got a response to the file request from the peer."""
	for i in self.downloads:
	    if i.req == msg.req:
		if not msg.allowed:
		    i.status = msg.reason
		else:
		    i.size = msg.filesize
		    i.status = "Establishing connection"
		    #Have to establish 'F' connection here
		    self.frame.ProcessRequestToPeer(i.user,slskmessages.FileRequest(None,msg.req))

		    
                self.downloadspanel.update()

    def FileRequest(self, msg):
	""" Got an incoming file request. Could be an upload request or a 
	request to get the file that was previously queued"""
	for i in self.downloads:
	    if msg.req == i.req:
		i.conn = msg.conn
		try:
                    f = open(os.path.join(self.downloaddir,i.path,"INCOMPLETE"+string.split(i.filename,'\\')[-1]),'ab+')
                    f.seek(0,2)
		    self.queue.put(slskmessages.DownloadFile(i.conn,f.tell(),f,i.size))
                    i.status = "%i" %(f.tell())
                    i.file = f
                except:
                    i.status = "Local file error"
                    try:
                        f.close()
                    except:
                        pass
                    i.conn = None
                    self.queue.put(slskmessages.ConnClose(msg.conn.conn))

                self.downloadspanel.update()
		break

    def FileDownload(self, msg):
	""" A file download is in progress"""
	for i in self.downloads:
	    if i.conn == msg.conn.conn:
		    try:
		        i.status = "%i" %(msg.file.tell())
		        if i.size <= msg.file.tell():
		            msg.file.close()
		            os.rename(msg.file.name,self.getRenamed(msg.file.name))
		            i.status = "Finished"
			    i.conn = None
		    except:
                        i.status = "Local file error"
	                try:
	                    msg.file.close()
	                except:
	                    pass
	                i.conn = None
	                self.queue.put(slskmessages.ConnClose(msg.conn.conn))

		    self.downloadspanel.update()

    def ConnClose(self, msg):
	""" The remote user has closed the connection either because
	he logged off, or because there's a network problem."""
	for i in self.downloads:
	    if i.conn == msg.conn:
		if i.file is not None:
		    i.file.close()
		if i.user in self.users.keys() and self.users[i.user].status == 0:
		    i.status = "User logged off"
		else:
		    i.status = "Connection closed by peer"
		i.conn = None
	    self.downloadspanel.update()

    def getRenamed(self,name):
	""" When a transfer is finished, we remove INCOMPLETE prefix from the
	file's name. """
	path,filename = os.path.split(name)
	if filename[0:10] == "INCOMPLETE":
	    filename = filename[10:]
	return os.path.join(path,filename)

    def PlaceInQueue(self,msg):
	""" The server tells us our place in queue for a particular transfer."""
	wxLogMessage("PlaceInQueue: "+str(vars(msg)))

    def FileError(self, msg):
	""" Networking thread encountered a local file error"""
	for i in self.downloads:
	    if i.conn == msg.conn.conn:
		i.status = "Local file error"
		try:
		    msg.file.close()
		except:
		    pass
		i.conn = None
		self.queue.put(slskmessages.ConnClose(msg.conn.conn))

    def FolderContentsResponse(self,msg):
	""" When we got a contents of a folder, get all the files in it, but
	skip the files in subfolders"""
        for i in self.peerconns:
            if i.conn is msg.conn.conn:
                username = i.username

	topdir = os.path.commonprefix(msg.list.keys())
	if topdir in msg.list.keys():
	    dir = string.split(topdir,'\\')[-1]
	    for k in msg.list[topdir]:
		self.getFile(username, topdir+ '\\' + k[1], dir)

    def AbortTransfers(self):
	""" Stop all transfers """
	for i in self.downloads:
	    if i.status != "Finished":
		if i.conn is not None:
                    self.queue.put(slskmessages.ConnClose(i.conn))
		    i.conn = None
		if i.file is not None:
		    try:
			i.file.close()
		    except:
			pass
		i.status = "Old"

    def GetDownloads(self):
	""" Get a list of incomplete and not aborted downloads """
	list = []
	for i in self.downloads:
	    if i.status != 'Finished' and i.status != 'Aborted':
		list.append([i.user, i.filename, i.path])
	return list
