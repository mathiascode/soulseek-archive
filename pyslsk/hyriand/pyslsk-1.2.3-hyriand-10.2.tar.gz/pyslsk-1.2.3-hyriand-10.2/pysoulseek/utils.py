# Copyright (c) 2001-2003 Alexander Kanavin. All rights reserved.

"""
This module contains utility fuctions.
"""

import string
import os.path
import os,dircache
import mp3

version = "1.2.3-hyriand-10.2"

def getServerList(url):
        """ Parse server text file from http://www.slsk.org and 
        return a list of servers """
        import urllib,string
        try:
            f = urllib.urlopen(url)
            list = [string.strip(i) for i in f.readlines()]
        except:
            return []
        try:
            list = list[list.index("--servers")+1:]
        except:
            return []
        list = [string.split(i,":",2) for i in list]
        try:
            return [[i[0],i[2]]  for i in list]
        except:
            return []

def rescandirs(shared, sharedmtimes, sharedfiles, sharedfilesstreams, yieldfunction):
        newmtimes = getDirsMtimes(shared,yieldfunction)
        newsharedfiles = getFilesList(newmtimes, sharedmtimes, sharedfiles,yieldfunction)
        newsharedfilesstreams = getFilesStreams(newmtimes, sharedmtimes, sharedfilesstreams, newsharedfiles,yieldfunction)
        newwordindex, newfileindex = getFilesIndex(newmtimes, sharedmtimes, shared, newsharedfiles,yieldfunction)
        return newsharedfiles,newsharedfilesstreams,newwordindex,newfileindex, newmtimes
    

def getDirsMtimes(dirs, yieldcall = None):
    list = {}
    for i in dirs:
	i = i.replace("//","/")
	try:
	    contents = dircache.listdir(i)
	    mtime = os.path.getmtime(i)
	except OSError, errtuple:
	    print errtuple
	    continue
	list[i] = mtime
        for f in contents:
	    pathname = os.path.join(i, f)
            try:
                isdir = os.path.isdir(pathname)
		mtime = os.path.getmtime(pathname)
            except OSError, errtuple:
                print errtuple
		continue
	    else:
		if isdir:
		    list[pathname] = mtime
		    dircontents = getDirsMtimes([pathname])
		    for k in dircontents:
			list[k] = dircontents[k]
		if yieldcall is not None:
		    yieldcall()
    return list


def getFilesList(mtimes, oldmtimes, oldlist, yieldcall = None):
    """ Get a list of files with their filelength and 
    (if mp3) bitrate and track length in seconds """
    list = {}
    for i in mtimes:
	if oldmtimes.has_key(i):
	  if mtimes[i] == oldmtimes[i]:
	    list[i] = oldlist[i]
	    continue
	list[i] = []
	try:
	    contents = dircache.listdir(i)
	except OSError, errtuple:
	    print errtuple
	    continue
	for f in contents:
	    pathname = os.path.join(i, f)
	    try:
	        isfile = os.path.isfile(pathname)
	    except OSError, errtuple:
	        print errtuple
	        continue
	    else:
		if isfile:
                    # It's a file, check if it is mp3
	            list[i].append(getFileInfo(f,pathname))
	    if yieldcall is not None:
                yieldcall()
    return list

def getFileInfo(name, pathname):
    size = os.path.getsize(pathname)   
    if name[-4:] == ".mp3" or name[-4:] == ".MP3":
	mp3info=mp3.detect_mp3(pathname)
        if mp3info:
            if mp3info["vbr"]:
                bitrateinfo = (mp3info["vbrrate"],1)
            else:
                bitrateinfo = (mp3info["bitrate"],0)
            fileinfo = (name,size,bitrateinfo,mp3info["time"])
        else:
            fileinfo = (name,size,None,None)
    elif name[-4:] == ".ogg" or name[-4:] == ".OGG":
	try:
	    import ogg.vorbis
	    vf = ogg.vorbis.VorbisFile(pathname)
	    time = int(vf.time_total(0))
	    bitrate = vf.bitrate(0)/1000
	    fileinfo = (name,size, (bitrate,0), time)
	except:
	    fileinfo = (name,size,None,None)
    else:
	fileinfo = (name,size,None,None)
    return fileinfo


def getFilesStreams(mtimes, oldmtimes, oldstreams, sharedfiles, yieldcall = None):
    streams = {}
    for i in mtimes.keys():
	if oldmtimes.has_key(i):
	  if mtimes[i] == oldmtimes[i]:
	    streams[i] = oldstreams[i]
	    continue
	streams[i] = getDirStream(sharedfiles[i])
        if yieldcall is not None:
            yieldcall()
    return streams

def getDirStream(dir):
    from slskmessages import SlskMessage
    msg = SlskMessage()
    stream = msg.packObject(len(dir))
    for i in dir:
	stream = stream + getByteStream(i)
    return stream
	
def getByteStream(fileinfo):
    from slskmessages import SlskMessage
    self = SlskMessage()
    stream = chr(1) + self.packObject(fileinfo[0]) + self.packObject(fileinfo[1]) + self.packObject(0)
    if fileinfo[2] is not None:
        stream = stream + self.packObject('mp3') + self.packObject(3)
        stream = stream + self.packObject(0)+ self.packObject(fileinfo[2][0])+self.packObject(1)+ self.packObject(fileinfo[3])+self.packObject(2)+self.packObject(fileinfo[2][1])
    else:
        stream = stream + self.packObject('') + self.packObject(0)
    return stream


def getFilesIndex(mtimes, oldmtimes, shareddirs,sharedfiles, yieldcall = None):
    wordindex = {}
    fileindex = {}
    index = 0

    for i in mtimes.keys():
	for j in sharedfiles[i]:
	    indexes = getIndexWords(i,j[0],shareddirs)
	    for k in indexes:
		wordindex.setdefault(k,[]).append(index)
	    fileindex[str(index)] = (os.path.join(i,j[0]),)+j[1:]
	    index += 1
	if yieldcall is not None:
	    yieldcall()
    return wordindex, fileindex

def getIndexWords(dir,file,shareddirs):
    import os.path,string
    for i in shareddirs:
	if os.path.commonprefix([dir,i]) == i:
	    dir = dir[len(i):]
    words = string.split(string.lower(string.translate(dir+' '+file, string.maketrans(string.punctuation,string.join([' ' for i in string.punctuation],'')))))
    # remove duplicates
    d = {}
    for x in words:
	d[x] = x
    return d.values()
     
def Humanize(number,fashion):
    if fashion == "" or fashion == "<none>":
        return str(number)
    elif fashion == "<space>":
        fashion = " "
    number = str(number)
    ret = ""
    while number[-3:]:
        part, number = number[-3:], number[:-3]
        ret = "%s%s%s" % (part, fashion, ret)
    return ret[:-1]
 
def expand_alias(aliases, cmd):
    def getpart(line):
        if line[0] != "(":
            return ""
        ix = 1
        ret = ""
        level = 0
        while ix < len(line):
            if line[ix] == "(":
                level = level + 1
            if line[ix] == ")":
                if level == 0:
                    return ret
                else:
                    level = level - 1
            ret = ret + line[ix]
            ix = ix + 1
        return ""

    if not cmd:
        return None
    if cmd[0] != "/":
        return None
    cmd = cmd[1:].split(" ")
    if not aliases.has_key(cmd[0]):
        return None
    alias = aliases[cmd[0]]
    ret = ""
    i = 0
    while i < len(alias):
        if alias[i:i+2] == "$(":
            arg=getpart(alias[i+1:])
            if not arg:
                ret = ret + "$"
                i = i + 1
                continue
            i = i + len(arg) + 3
            args = arg.split("=",1)
            if len(args) > 1:
                default = args[1]
            else:
                default = ""
            args = args[0].split(":")
            if len(args) == 1:
                first = last = int(args[0])
            else:
               if args[0]:
                   first = int(args[0])
               else:
                   first = 1
               if args[1]:
                   last = int(args[1])
               else:
                   last = len(cmd)
            v = string.join(cmd[first:last+1])
            if not v: v = default
            ret = ret + v
        elif alias[i:i+2] == "|(":
            arg = getpart(alias[i+1:])
            if not arg:
                ret = ret + "|"
                i = i + 1
                continue
            i = i + len(arg) + 3
            for j in range(len(cmd)-1, -1, -1):
                arg = arg.replace("$%i" % j, cmd[j])
            arg = arg.replace("$@", string.join(cmd[1:], " "))
            stdin, stdout = os.popen2(arg)
            v = stdout.read().split("\n")
            r = ""
            for l in v:
                l = l.strip()
                if l:
                    r = r + l + "\n"
            ret = ret + r.strip()
            stdin.close()
            stdout.close()
            os.wait()
        else:
            ret = ret + alias[i]
            i = i + 1
    return ret

def escapeCommand(filename):
    """Escapes special characters for command execution"""
    escaped = ""
    for ch in filename:
       if ch not in string.ascii_letters+string.digits+"/":
           escaped += "\\"
       escaped += ch
    return escaped
