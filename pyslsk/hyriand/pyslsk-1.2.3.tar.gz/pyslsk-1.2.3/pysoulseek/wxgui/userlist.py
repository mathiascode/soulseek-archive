# Copyright (c) 2001-2003 Alexander Kanavin. All rights reserved.

"""
This module contains GUI classes for the userlist.
"""

import time
from pysoulseek import slskproto
from pysoulseek import slskmessages
import Queue
import threading
import images
import about
import userinfobrowse
import search
import types
import locale
from sortablelist import sortableListCtrl
from wxPython.wx import *


class UserListPanel(wxPanel): 
    def __init__(self, parent, id,frame):
        wxPanel.__init__(self, parent, id, style = wxSUNKEN_BORDER)
	self.frame = frame
        self.userlistctrl = UserListCtrl(self,-1)
        self.adduser = wxTextCtrl(self,-1, style = wxTE_PROCESS_ENTER, size=wxSize(130,25))
        self.add = wxStaticText(self, -1, "Add:")

        sizerh = wxBoxSizer(wxHORIZONTAL)
        sizerh.Add(self.add,0,wxALIGN_CENTER)
        sizerh.Add(self.adduser,1,wxEXPAND)
        sizerv = wxBoxSizer(wxVERTICAL)
        sizerv.Add(self.userlistctrl,1,wxEXPAND)
        sizerv.Add(sizerh,0,wxEXPAND)

        self.SetSizer(sizerv)
        self.SetAutoLayout(True)
        EVT_TEXT_ENTER(self,self.adduser.GetId(),self.OnEnter)

	self.configuserlist = self.frame.np.config.sections["server"]["userlist"]
	# userlist used to be stored as a list of users, 
	# now it's a list of tuples (user, comment)
	if len(self.configuserlist) > 0 and type(self.configuserlist[0]) == types.StringType:
	    for i in range(len(self.configuserlist)):
	 	self.configuserlist[i] = [self.configuserlist[i],""]
	    self.frame.np.config.writeConfig()
	self.userlist = [[i[0],None,None,i[1],0] for i in self.configuserlist]
	for i in self.userlist:
	    self.frame.np.queue.put(slskmessages.GetUserStatus(i[0]))
	    self.frame.np.queue.put(slskmessages.GetUserStats(i[0]))
	self.userlistctrl.SetItemCount(len(self.userlist))

        
    def OnEnter(self, event):
        text = self.frame.np.encode(self.adduser.GetLineText(0))
        self.adduser.Clear()
	self.AddToList(text)

    def AddToList(self,user):
        if user not in [i[0] for i in self.userlist]:
	    dlg = wxTextEntryDialog(self.frame, "Comments:", caption = "Add your comments for this user")
	    comments = ""
	    if (dlg.ShowModal() == wxID_OK):
		comments = self.frame.np.encode(dlg.GetValue())
            self.frame.np.queue.put(slskmessages.GetUserStatus(user))
	    self.frame.np.queue.put(slskmessages.GetUserStats(user))
            self.userlist.append([user,None,None,comments,0])
	    self.configuserlist.append([user,comments])
            self.frame.np.config.writeConfig()
	    self.userlistctrl.SetItemCount(len(self.userlist))
	else:
	    item = [i[0] for i in self.userlist].index(user)
	    self.EditComments(item)

    def GetUserStatus(self,msg):
        for i in self.userlist:
           if i[0] == msg.user:
                i[4] = msg.status
                self.userlistctrl.SetItemCount(len(self.userlist))
                break

    def GetUserStats(self, msg):
	for i in self.userlist:
	    if i[0] == msg.user:
		i[1] = msg.avgspeed
		i[2] = msg.files
		self.userlistctrl.SetItemCount(len(self.userlist))
		break

    def RemoveFromList(self, item):
	del self.userlist[item]
	del self.configuserlist[item]
	self.frame.np.config.writeConfig()

    def EditComments(self, item):
	dlg = wxTextEntryDialog(self.frame, "Comments:", caption = "Edit your comments for this user",defaultValue=self.userlist[item][3])
        if (dlg.ShowModal() == wxID_OK):
            comments = self.frame.np.encode(dlg.GetValue())
            self.userlist[item][3] = comments
            self.configuserlist[item][1] = comments
            self.frame.np.config.writeConfig()
            self.userlistctrl.SetItemCount(len(self.userlist))

class UserListCtrl(sortableListCtrl):
    """
    This is a list control for the users list 
    """
    def __init__(self, parent, id, style = wxLC_REPORT|wxLC_VIRTUAL):
        sortableListCtrl.__init__(self,parent,id,style = style)
        self.InsertColumn(0,"User", width=130)
	self.InsertColumn(1,"Speed",width=50,format=wxLIST_FORMAT_RIGHT)
	self.InsertColumn(2,"Files",width=50,format=wxLIST_FORMAT_RIGHT)
	self.InsertColumn(3,"Comments", width=540)

	self.SetItemCount(0)

        self.online = self.imglist.Add(images.getOnlineBitmap())
        self.offline = self.imglist.Add(images.getOfflineBitmap())
        self.away = self.imglist.Add(images.getAwayBitmap())
#        self.AssignImageList(self.imglist,wxIMAGE_LIST_SMALL)

        self.parent = parent

        self.menu = wxMenu()
        sendmessageID=wxNewId()
        self.menu.Append(sendmessageID, 'Send Message')
        EVT_MENU(self,sendmessageID, self.OnSendMessage)
        showipID=wxNewId()
        self.menu.Append(showipID, 'Show IP address')
        EVT_MENU(self,showipID, self.OnShowIp)
        getinfoID=wxNewId()
        self.menu.Append(getinfoID, 'Get User Info')
        EVT_MENU(self,getinfoID, self.OnGetInfo)
        browseID=wxNewId()
        self.menu.Append(browseID, 'Browse Files')
        EVT_MENU(self,browseID, self.OnBrowse)
        banuserID=wxNewId()
        self.menu.Append(banuserID, 'Ban this User')
        EVT_MENU(self,banuserID, self.OnBanUser)
	self.menu.AppendSeparator()
	editID = wxNewId()
	self.menu.Append(editID, 'Edit comments')
	EVT_MENU(self,editID, self.OnEdit)
	removeID=wxNewId()
	self.menu.Append(removeID, 'Remove')
	EVT_MENU(self,removeID,self.OnRemove)

        EVT_RIGHT_UP(self,self.OnRightUp)

    def OnRightUp(self,event):
        """ Pops up a menu on a right-click in users list."""
        pt = event.GetPosition()
        item, flags = self.HitTest(pt)
        self.item = item
        if item >= 0:
	    self.focuseduser = self.parent.userlist[self.item][0]
            self.SetItemState(item,wxLIST_STATE_FOCUSED,wxLIST_STATE_FOCUSED)
            self.PopupMenu(self.menu, wxPoint(event.GetX(),event.GetY()))

    """ Handlers for the menu items"""
    def OnSendMessage(self, event):
        self.parent.frame.np.privatechat.SendMessage(self.focuseduser)

    def OnShowIp(self, event):
        self.parent.frame.np.queue.put(slskmessages.GetPeerAddress(self.focuseduser))

    def OnGetInfo(self, event):
        self.parent.frame.np.ProcessRequestToPeer(self.focuseduser, slskmessages.UserInfoRequest(None), self.parent.frame.np.userinfo)

    def OnBrowse(self, event):
        self.parent.frame.np.ProcessRequestToPeer(self.focuseduser, slskmessages.GetSharedFileList(None), self.parent.frame.np.userbrowse)

    def OnEdit(self, event):
	self.parent.EditComments(self.item)

    def OnRemove(self,event):
	length = len(self.parent.userlist)
	for i in range(length):
            self.SetItemState(i,0,wxLIST_STATE_SELECTED|wxLIST_STATE_FOCUSED)
	self.parent.RemoveFromList(self.item)

	self.SetItemCount(length-1)

    def OnBanUser(self,event):
        self.parent.frame.BanUser(self.focuseduser)

    def OnGetItemText(self, item, col):
        user = self.parent.userlist[item]
        return self.GetColumnValue(user,col)

    def GetColumnValue(self,user,col):
        if col == 0:
            return user[0]
	elif col == 1:
	    return locale.format("%s",user[1],1)
	elif col == 2:
	    return locale.format("%s",user[2],1)
	elif col == 3:
	    return user[3]
        else:
            return None

    def OnGetItemImage(self,item):
        if self.parent.userlist[item][4] == 1:
            return self.away
        elif self.parent.userlist[item][4] == 2:
            return self.online
        elif self.parent.userlist[item][4] == 0:
            return self.offline
        else:
            return -1

    def SortList(self, col, order):
        if order == 0:
            self.parent.userlist.sort(lambda x,y: self.cmp(x[col],y[col]))
        else:
            self.parent.userlist.sort(lambda y,x: self.cmp(x[col],y[col]))
	self.parent.configuserlist = [(i[0],i[3]) for i in self.parent.userlist]
	self.parent.frame.np.config.writeConfig()
