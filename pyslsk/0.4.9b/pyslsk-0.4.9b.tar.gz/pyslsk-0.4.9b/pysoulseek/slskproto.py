# Copyright (c) 2001-2002 Alexander Kanavin. All rights reserved.

"""
This module implements SoulSeek networking protocol.
"""

from slskmessages import *
import SocketServer
import socket
import select
import threading
import struct
import random
import time

class Connection:
    """
    Holds data about a connection. conn is a socket object, 
    addr is (ip,port) pair, ibuf and obuf are input and output buffer,
    init is a PeerInit object (see slskmessages docstrings).
    """
    def __init__(self, conn = None, addr = None, ibuf = "", obuf = ""):
	self.conn = conn
	self.addr = addr
	self.ibuf = ibuf
	self.obuf = obuf
	self.init = None
	self.lastwritelength = 10*1024
	self.lastreadlength = 100*1024

class ServerConnection(Connection):
    pass

class PeerConnection(Connection):
    def __init__(self, conn = None, addr = None, ibuf = "", obuf = "", init = None):
	Connection.__init__(self,conn,addr,ibuf,obuf)
	self.filereq = None
	self.filedown = None
	self.fileupl = None
	self.filereadbytes = 0
	self.bytestoread = 0
	self.init = init
	self.piercefw = None
	self.lastactive = time.time()


class PeerConnectionInProgress:
    """ As all p2p connect()s are non-blocking, this class is used to
    hold data about a connection that is not yet established. msgObj is 
    a message to be sent after the connection has been established.
    """
    def __init__(self, conn = None, msgObj = None):
        self.conn = conn
        self.msgObj = msgObj

class SlskProtoThread(threading.Thread):
    """ This is a netwroking thread that actually does all the communication.
    It sends data to the UI thread via a callback function and receives data
    via a Queue object.
    """

    """ Server and peers send each other small binary messages, that start
    with length and message code followed by the actual messsage data. 
    These are the codes."""
    servercodes = {Login:1,SetWaitPort:2,
                   GetPeerAddress:3,AddUser:5,GetUserStatus:7,SayChatroom:13,
                   JoinRoom:14,LeaveRoom:15,UserJoinedRoom:16,UserLeftRoom:17,
                   ConnectToPeer:18,MessageUser:22,MessageAcked:23,
		   FileSearch:26,SetStatus:28,SharedFoldersFiles:35, 
		   GetUserStats:36,QueuedDownloads:40,
		   PlaceInLineResponse:60,RoomAdded:62,RoomRemoved:63,
		   RoomList:64,ExactFileSearch:65,AdminMessage:66, 
		   GlobalUserList:67,TunneledMessage:68,PrivilegedUsers:69,
		   CheckPrivileges:92,CantConnectToPeer:1001}
    peercodes = {GetSharedFileList:4, SharedFileList:5, FileSearchResult:9,
		UserInfoRequest:15,UserInfoReply:16, FolderContentsRequest:36,
		FolderContentsResponse:37, TransferRequest:40,
		TransferResponse:41,PlaceholdUpload:42,QueueUpload:43,
		PlaceInQueue:44,UploadFailed:46,QueueFailed:50,PlaceInQueueRequest:51}

    def __init__(self, ui_callback, queue):
	""" ui_callback is a UI callback function to be called with messages 
	list as a parameter. queue is Queue object that holds messages from UI
	thread.
	"""
        threading.Thread.__init__(self) 
        self._ui_callback = ui_callback
        self._queue = queue
        self._want_abort = 0
	self._stopped = 0

        self.serverclasses = {}
        for i in self.servercodes.keys():
            self.serverclasses[self.servercodes[i]]=i
        self.peerclasses = {}
        for i in self.peercodes.keys():
            self.peerclasses[self.peercodes[i]]=i
	self._p = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	self._conns = {}
	self._connsinprogress={}

	for listenport in range(2234,2240):
		try:
		    self._p.bind(('',listenport))
		except socket.error:
		    listenport = None
		else:
		    self._p.listen(1)
		    self._ui_callback([IncPort(listenport)])
		    break
	if listenport is not None:
	    self.start()
    
    def run(self):
	""" Actual networking loop is here."""
	p = self._p
	s = None
	conns = self._conns
	connsinprogress = self._connsinprogress
	queue = self._queue

        while not self._want_abort:
            if not queue.empty():
		conns, connsinprogress, s = self.process_queue(queue, conns, connsinprogress,s)
	    outsock = [i for i in conns.keys() if len(conns[i].obuf) > 0 or (i is not s and conns[i].fileupl is not None)]
#	    print outsock
	    try:
            	input,output,exc = select.select(conns.keys()+connsinprogress.keys()+[p],connsinprogress.keys()+outsock,[],0.5)
#            	input,output,exc = select.select(conns.keys()+connsinprogress.keys(),connsinprogress.keys()+outsock,[],0.5)
	    except select.error:
		self._want_abort = 1
	    for i in conns.keys():
		if i in output:
		    try:
			conns[i].lastactive = time.time()
			i.setblocking(0)
			bytes_send = i.send(conns[i].obuf)
			i.setblocking(1)
			bufsize = len(conns[i].obuf)
			conns[i].obuf = conns[i].obuf[bytes_send:]
			if bufsize == bytes_send and bufsize > 0:
			    conns[i].lastwritelength = conns[i].lastwritelength * 2
			if i is not s:
			    if conns[i].fileupl is not None and conns[i].fileupl.offset is not None:
			        conns[i].fileupl.sentbytes = conns[i].fileupl.sentbytes + bytes_send
				try:
				    if conns[i].fileupl.offset + conns[i].fileupl.sentbytes + len(conns[i].obuf) < conns[i].fileupl.size:
					read = conns[i].fileupl.file.read(conns[i].lastwritelength)
                                	conns[i].obuf = conns[i].obuf + read
                                except:
                                    self._ui_callback([FileError(conns[i],conns[i].fileupl.file)])
				
				if bytes_send > 0:
			            self._ui_callback([conns[i].fileupl])
		    except socket.error, err:
			self._ui_callback([ConnectError(conns[i],err)])
	    if p in input:
		try:
		    incconn, incaddr = p.accept()
		    conns[incconn] = PeerConnection(incconn,incaddr,"","")
		    self._ui_callback([IncConn(incconn, incaddr)])
		except:
		    time.sleep(1)
	    for i in connsinprogress.keys():
		if i in output:
		    try:
			msgObj = connsinprogress[i].msgObj
			if i in input:
		            i.recv(0)
#			i.connect(msgObj.addr)
		    except socket.error,err:
                        self._ui_callback([ConnectError(msgObj,err)])
                    else:
		        conns[i]=PeerConnection(i,msgObj.addr,"","",msgObj.init)
		        self._ui_callback([OutConn(i,msgObj.addr)])
		    del connsinprogress[i]
	    for i in conns.keys():
		if i in input:
		    try:
			conns[i].lastactive = time.time()
		        data = i.recv(conns[i].lastreadlength)
                        conns[i].ibuf = conns[i].ibuf + data
			if len(data) >= conns[i].lastreadlength/2:
			    conns[i].lastreadlength = conns[i].lastreadlength * 2 
			if not data:
	                    self._ui_callback([ConnClose(i,conns[i].addr)])
	                    i.close()
	                    del conns[i]
			    continue

		    except socket.error, err:
			self._ui_callback([ConnectError(conns[i],err)])
	        if len(conns[i].ibuf) > 0:
			    if i is s:
			        msgs,conns[s].ibuf = self.process_server_input(conns[s].ibuf)
				self._ui_callback(msgs)
			    else:
				if conns[i].init is None or conns[i].init.type != 'F':
				    msgs, conns[i] = self.process_peer_input(conns[i],conns[i].ibuf)
				    self._ui_callback(msgs)
				if conns[i].init is not None and conns[i].init.type == 'F':
			            msgs, conns[i] = self.process_file_input(conns[i],conns[i].ibuf)
				    self._ui_callback(msgs)
	    curtime = time.time()
	    for i in conns.keys()[:]:
		if i is not s:
		    if curtime - conns[i].lastactive > 120:
			self._ui_callback([ConnClose(i,conns[i].addr)])
                        i.close()
                        del conns[i]
	    self._ui_callback([])	
	if s is not None:
            s.close()
	self._stopped = 1

    def process_server_input(self,buffer):
 	""" Server has sent us something, this function retrieves messages 
	from the buffer, creates message objects and returns them and the rest 
	of the buffer.
	"""
        msgs=[]
        while len(buffer) >=8:
            msgsize, msgtype = struct.unpack("<ii",buffer[:8])
            if msgsize + 4 > len(buffer):
                break
            elif self.serverclasses.has_key(msgtype):
                msg = self.serverclasses[msgtype]()
                msg.parseNetworkMessage(buffer[8:msgsize+4])
                msgs.append(msg)
            else:
                print "Server message type", msgtype, "size",msgsize-4,"unknown"
	    buffer = buffer[msgsize+4:]
        return msgs,buffer

    def parseFileReq(self,conn,buffer):
	msg = None
	if len(buffer) >= 4:
	    reqnum = struct.unpack("<i",buffer[:4])[0]
	    msg = FileRequest(conn.conn,reqnum)
	    buffer = buffer[4:]
	return msg,buffer

    def parseOffset(self,conn,buffer):
        offset = None
        if len(buffer) >= 8:
            offset = struct.unpack("<i",buffer[:4])[0]
            buffer = buffer[8:]
        return offset,buffer

    def process_file_input(self,conn,buffer):
            """ We have a "F" connection (filetransfer) , peer has sent us 
	    something, this function retrieves messages 
            from the buffer, creates message objects and returns them 
	    and the rest of the buffer.
            """
	    msgs=[]
	    if conn.filereq is None:
		filereq,buffer = self.parseFileReq(conn,buffer)
		if filereq is not None:
		    msgs.append(filereq)
		    conn.filereq = filereq
	    elif conn.filedown is not None:
		leftbytes = conn.bytestoread - conn.filereadbytes
		if leftbytes > 0:
		    try:
		        conn.filedown.file.write(buffer[:leftbytes])
		    except:
			self._ui_callback([FileError(conn,conn.filedown.file)])
		    self._ui_callback([DownloadFile(conn.conn,len(buffer[:leftbytes]),conn.filedown.file)])
		conn.filereadbytes = conn.filereadbytes + len(buffer[:leftbytes])
		buffer = buffer[leftbytes:]
	    elif conn.fileupl is not None:
		if conn.fileupl.offset is None:
		    offset,buffer = self.parseOffset(conn,buffer)
		    if offset is not None:
			try:
			    conn.fileupl.file.seek(offset)
			except:
			    self._ui_callback([FileError(conn,conn.fileupl.file)])
			conn.fileupl.offset = offset
		    
	    conn.ibuf = buffer
	    return msgs, conn

    def process_peer_input(self,conn,buffer):
        """ We have a "P" connection (p2p exchange) , peer has sent us 
        something, this function retrieves messages 
        from the buffer, creates message objects and returns them 
        and the rest of the buffer.
        """
        msgs=[]
	while (conn.init is None or conn.init.type != 'F') and len(buffer) >= 8:
	    msgsize = struct.unpack("<i",buffer[:4])[0]
            self._ui_callback([PeerTransfer(conn,msgsize,len(buffer)-4)])
	    if msgsize + 4 > len(buffer):
		break
	    elif conn.init is None:
		if buffer[4] == chr(0):
		    msg = PierceFireWall(conn)
		    msg.parseNetworkMessage(buffer[5:msgsize+4])
		    conn.piercefw = msg
		    msgs.append(msg)
		elif buffer[4] == chr(1):
		    msg = PeerInit(conn)
		    msg.parseNetworkMessage(buffer[5:msgsize+4])
		    conn.init = msg
		    msgs.append(msg)
		else:
		    print "Unknown peer init code:", ord(buffer[4])
		buffer = buffer[msgsize+4:]
            elif conn.init.type == 'P':
		msgtype = struct.unpack("<i",buffer[4:8])[0]
		if self.peerclasses.has_key(msgtype):
                    msg = self.peerclasses[msgtype](conn)
                    msg.parseNetworkMessage(buffer[8:msgsize+4])
                    msgs.append(msg)
            	else:
                    print "Peer message type", msgtype, "size",msgsize-4,"unknown"
	        buffer = buffer[msgsize+4:]
	    else:
		print "Can't handle connection type", conn.init.type
		buffer = buffer[msgsize+4:]
	conn.ibuf = buffer
	return msgs,conn

    def process_queue(self,queue, conns, connsinprogress, s):
	""" Processes messages sent by UI thread. s is a server connection 
	socket object, queue holds the messages, conns ans connsinprogess 
	are dictionaries holding Connection and PeerConnectionInProgress 
	messages."""
	list = []
	needsleep = 0
        while not queue.empty():
            list.append(queue.get())
	for msgObj in list:
	    if issubclass(msgObj.__class__,ServerMessage):
            	msg = msgObj.makeNetworkMessage()
            	conns[s].obuf = conns[s].obuf + struct.pack("<ii",len(msg)+4,self.servercodes[msgObj.__class__]) + msg
	    elif issubclass(msgObj.__class__,PeerMessage):
	      if msgObj.conn in conns.keys():
		if msgObj.__class__ is PierceFireWall:
                    conns[msgObj.conn].piercefw = msgObj
		    msg = msgObj.makeNetworkMessage()
		    conns[msgObj.conn].obuf = conns[msgObj.conn].obuf + struct.pack("<i", len(msg) + 1) + chr(0) + msg
		elif msgObj.__class__ is PeerInit:
		    conns[msgObj.conn].init = msgObj
		    msg = msgObj.makeNetworkMessage()
		    if conns[msgObj.conn].piercefw is None:
			conns[msgObj.conn].obuf = conns[msgObj.conn].obuf + struct.pack("<i", len(msg) + 1) + chr(1) + msg
		elif msgObj.__class__ is FileRequest:
		    conns[msgObj.conn].filereq = msgObj
		    msg = msgObj.makeNetworkMessage()
		    conns[msgObj.conn].obuf = conns[msgObj.conn].obuf + msg
		    self._ui_callback([msgObj])
		else:
		    msg = msgObj.makeNetworkMessage()
		    conns[msgObj.conn].obuf = conns[msgObj.conn].obuf + struct.pack("<ii", len(msg) + 4, self.peercodes[msgObj.__class__]) + msg
	    elif issubclass(msgObj.__class__,InternalMessage):
		if msgObj.__class__ is ServerConn:
		    try:
			s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
			s.connect(msgObj.addr)
		    except socket.error,err:
			self._ui_callback([ConnectError(msgObj,err)])
		    else:
		        conns[s]=ServerConnection(s,msgObj.addr,"","")
		        self._ui_callback([ServerConn(s,msgObj.addr)])
		elif msgObj.__class__ is ConnClose and msgObj.conn in conns.keys():
			msgObj.conn.close()
			self._ui_callback([ConnClose(msgObj.conn,conns[msgObj.conn].addr)])
			del conns[msgObj.conn]
		elif msgObj.__class__ is OutConn:
		    try:
		        conn = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		        conn.setblocking(0)
		        conn.connect_ex(msgObj.addr)
		        conn.setblocking(1)
		        connsinprogress[conn]=PeerConnectionInProgress(conn,msgObj)
		    except:
			queue.put(msgObj)
			needsleep = 1
		elif msgObj.__class__ is DownloadFile and msgObj.conn in conns.keys():
		    conns[msgObj.conn].filedown = msgObj
		    conns[msgObj.conn].obuf = conns[msgObj.conn].obuf + struct.pack("<i", msgObj.offset) + struct.pack("<i", 0)
		    conns[msgObj.conn].bytestoread = msgObj.filesize - msgObj.offset
		elif msgObj.__class__ is UploadFile and msgObj.conn in conns.keys():
		    conns[msgObj.conn].fileupl = msgObj
	if needsleep:
	    time.sleep(1)
	    
        return conns,connsinprogress,s

    def abort(self):
	""" Call this to abort the thread"""
        self._want_abort = 1 

    def stopped(self):
	""" returns true if thread has stopped """
	return self._stopped
