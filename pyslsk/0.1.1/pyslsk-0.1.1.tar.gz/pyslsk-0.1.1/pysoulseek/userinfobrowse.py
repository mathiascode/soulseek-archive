# Copyright (c) 2001-2002 Alexander Kanavin. All rights reserved.

"""
This module contains GUI classes for displaying user's info and filelist.
"""

import time
import slskproto
import slskmessages
import transfers
import Queue
import threading
import images
import about
import userinfobrowse
import search
from wxPython.wx import *
from config import *

class UserNotebook(wxNotebook):
    """ This is a notebook with user's information. Used to show either
    user's info itself or their filelists (this is determined by 
    subwindow class)"""
    def __init__(self, parent, id, queue, subwindow, frame, style=wxCLIP_CHILDREN|wxNB_RIGHT):
        wxNotebook.__init__(self,parent,id,style = style)
        self.users={}
        self.queue = queue
        self.subwindow = subwindow
        self.frame = frame

    def InitWindow(self,user,conn):
        """ Creates subwindow if necessary"""
        if not self.users.has_key(user):
            self.users[user]= self.subwindow(self, -1, user, conn, self.frame)
            self.AddPage(self.users[user],user)
        else:
            self.users[user].conn = conn

    def ShowInfo(self, user, msg):
        """ Shows info in a subwindow, creating it if necessary."""
        if not self.users.has_key(user):
            self.InitWindow(user, msg.conn)
        self.users[user].ShowInfo(msg) # deletes conn attr

    def UpdateGauge(self, msg):
        """Updates gauge in a subwindow if a transfer is in progress"""
        for i in self.users.values():
            if i.conn == msg.conn.conn:
                i.UpdateGauge(msg)

class UserInfoWindow(wxPanel):
    """ This is a window that shows user's information, picture, description
    and all. Was rather hard to get the layout of widgets just right."""
    def __init__(self, parent, id, user, conn, frame):
        wxPanel.__init__(self, parent, id)
        self.gauge = wxGauge(self,-1,100,size=wxSize(250, 25),style=wxGA_HORIZONTAL|wxGA_SMOOTH)
        self.close = wxButton(self, -1, "Close")
        self.descr = wxTextCtrl(self,-1,size=wxSize(250,100),style = wxTE_MULTILINE|wxTE_READONLY|wxTE_RICH)
        self.infobox = wxStaticBoxSizer(wxStaticBox(self, -1, "Information:"),wxVERTICAL)
        self.info = wxStaticText(self,-1,"\n\n\n")
        self.infobox.Add(self.info,1,wxEXPAND)
        self.picbox = wxStaticBoxSizer(wxStaticBox(self, -1, "Picture:"),wxVERTICAL)
        self.picpanel = wxPanel(self, -1)
        self.picbox.Add(self.picpanel,1,wxEXPAND)
        self.bitmap = None

        sizerlowh = wxBoxSizer(wxHORIZONTAL)
        sizerlowh.Add(self.gauge,0,wxEXPAND)
        sizerlowh.Add(60,20,1,wxEXPAND)
        sizerlowh.Add(self.close,0,wxEXPAND)

        sizerv = wxBoxSizer(wxVERTICAL)
        sizerv.Add(wxStaticText(self,-1, "Self-description:"))
        sizerv.Add(self.descr,1,wxEXPAND)
        sizerv.Add(self.infobox,0,wxEXPAND)

        sizeruph = wxBoxSizer(wxHORIZONTAL)
        sizeruph.Add(sizerv,0,wxEXPAND)
        sizeruph.Add(self.picbox,1,wxEXPAND)

        mainsizerv = wxBoxSizer(wxVERTICAL)
        mainsizerv.Add(sizeruph,1,wxEXPAND)
        mainsizerv.Add(sizerlowh,0,wxEXPAND)

        self.SetSizer(mainsizerv)
        self.SetAutoLayout(true)
        EVT_BUTTON(self,self.close.GetId(), self.OnClose)

        self.user = user
        self.conn = conn
        self.parent = parent

    def ShowInfo(self,msg):
        """ Actually displays the info"""
        self.conn = None
        self.descr.Clear()
        self.descr.AppendText(msg.descr)
        self.info.SetLabel("Per user uploads allowed: %i\nTotal uploads allowed: %i\nQueue size: %i\nSlots available: %i" %(msg.userupl,msg.totalupl,msg.queuesize,ord(msg.slotsavail)))
        self.picbox.Remove(0)
        if self.bitmap is not None:
            self.bitmap.Destroy()
        if ord(msg.has_pic):
            import os, tempfile
            name = tempfile.mktemp()
            f = open(name,"w")
            f.write(msg.pic)
            f.close()
            img = wxImage(name).ConvertToBitmap()
            os.remove(name)
            self.bitmap =  wxStaticBitmap(self.picpanel, -1, img,size=wxSize(img.GetWidth(), img.GetHeight()))
        else:
            self.bitmap = wxStaticText(self.picpanel,-1,"No picture available")

        sizer = wxBoxSizer(wxVERTICAL)
        sizer.Add(self.bitmap,1,wxALIGN_CENTER|wxEXPAND)
        self.picpanel.SetSizer(sizer)
        self.picpanel.SetAutoLayout(true)
        self.picbox.Add(self.picpanel,1,wxEXPAND)
        self.picbox.Layout()

    def UpdateGauge(self,msg):
        self.gauge.SetRange(msg.total)
        self.gauge.SetValue(msg.bytes)

    def OnClose(self, event):
        """ Closes the window"""
        del self.parent.users[self.user]
        self.parent.DeletePage(self.parent.GetSelection())
        self.parent.SetSelection(0)

class FileListCtrl(wxListCtrl):
    """ This is a list of a user's files in a particular directory"""
    def __init__(self, parent, id, style = wxLC_REPORT|wxLC_VIRTUAL|wxSUNKEN_BORDER|wxLC_VRULES):
        wxListCtrl.__init__(self,parent,id,style = style)
        self.InsertColumn(0,"Filename", width=200)
        self.InsertColumn(1,"Size",width=100)
        self.InsertColumn(2,"Attributes",width=150)
        self.SetItemCount(0)
        self.list = None
        self.dir = None

        self.parent = parent

    def SetFileList(self, list):
        """ Actually sets the list."""
        if list is None:
            self.SetItemCount(0)
        else:
            self.dir = list[0]
            self.list = list[1]
            self.SetItemCount(len(self.list))

    def OnGetItemText(self, item, col):
        """ Returns item in (item,col) cell."""
        import string
        if col == 0:
            return self.list[item][1]
        if col == 1:
            return '%i' %(self.list[item][2])
        if col == 2:
            if self.list[item][3] == 'mp3':
                attrs = self.list[item][4]
                if len(attrs) >= 3:
                    if attrs[2] == 1:
                        brs = 'VBR'
                    else:
                        brs = 'Bitrate'
                    br = attrs[0]
                    length = '%i:%02i' %(attrs[1] / 60, attrs[1] % 60)
                    return '%s: %i, Length: %s' %(brs,br,length)
                return ""
            elif self.list[item][3] == '':
                return ""
            else:
                return str(self.list[item][4])

class DirTreeCtrl(wxTreeCtrl):
    """ A tree of user's directories"""
    def __init__(self, parent, id, style = wxTR_HIDE_ROOT|wxTR_HAS_BUTTONS):
        wxTreeCtrl.__init__(self,parent, id, style = style)

    def OnCompareItems(self, item1, item2):
        t1 = self.GetItemText(item1)
        t2 = self.GetItemText(item2)
        if t1 < t2: return -1
        if t1 == t2: return 0
        return 1

class UserBrowseWindow(wxPanel):
    """ A window that lets you browse user's files. Contains a directory 
    tree on the left and a file list on the right"""
    def __init__(self, parent, id, user, conn, frame):
        wxPanel.__init__(self, parent, id)
        self.gauge = wxGauge(self,-1,100,size=wxSize(250, 25),style=wxGA_HORIZONTAL|wxGA_SMOOTH)
        self.close = wxButton(self, -1, "Close")
        splitter = wxSplitterWindow(self,-1,style=wxNO_3D|wxSP_3DSASH)
        self.tree = DirTreeCtrl(splitter, -1)
        self.listctrl = FileListCtrl(splitter,-1)

        sizerlowh = wxBoxSizer(wxHORIZONTAL)
        sizerlowh.Add(self.gauge,0,wxEXPAND)
        sizerlowh.Add(60,20,1,wxEXPAND)
        sizerlowh.Add(self.close,0,wxEXPAND)

        mainsizerv = wxBoxSizer(wxVERTICAL)
        mainsizerv.Add(splitter,1,wxEXPAND)
        mainsizerv.Add(60,20,0,wxEXPAND)
        mainsizerv.Add(sizerlowh,0,wxEXPAND)

        splitter.SplitVertically(self.tree,self.listctrl)
        splitter.SetSashPosition(250,true)

        self.SetSizer(mainsizerv)
        self.SetAutoLayout(true)
        EVT_BUTTON(self,self.close.GetId(), self.OnClose)
        EVT_TREE_SEL_CHANGED (self, self.tree.GetId(), self.OnTreeSelChanged)

        self.user = user
        self.conn = conn
        self.parent = parent
        self.queue = frame.queue
        self.processrequest = frame.chat.ProcessRequestToPeer
        self.privatechat = frame.privatechat
        self.info = frame.userinfo
        self.transfers = frame.transfers

        self.treemenu = wxMenu()
        self.listmenu = wxMenu()
        downloaddirID=wxNewId()
        self.treemenu.Append(downloaddirID, 'Download Directory')
        EVT_MENU(self.tree,downloaddirID, self.OnDownloadDir)
        downloadfileID=wxNewId()
        self.listmenu.Append(downloadfileID, 'Download File')
        EVT_MENU(self.listctrl,downloadfileID, self.OnDownloadFile)
        sendmessageID=wxNewId()
        self.treemenu.Append(sendmessageID, 'Send Message')
        self.listmenu.Append(sendmessageID, 'Send Message')
        EVT_MENU(self,sendmessageID, self.OnSendMessage)
        getinfoID=wxNewId()
        self.treemenu.Append(getinfoID, 'Get User Info')
        self.listmenu.Append(getinfoID, 'Get User Info')
        EVT_MENU(self,getinfoID, self.OnGetInfo)

        EVT_LIST_ITEM_RIGHT_CLICK(self.listctrl, -1,self.OnRightClickList)
        EVT_RIGHT_UP(self.listctrl,self.OnRightUpList)
        EVT_RIGHT_UP(self.tree, self.OnRightUpTree)

    def OnRightClickList(self,event):
        """ Saves item number in a filelist on a right-click."""
        self.id = event.GetIndex()
        self.listctrl.SetItemState(self.id,wxLIST_STATE_FOCUSED,wxLIST_STATE_FOCUSED)

    def OnRightUpList(self,event):
        """ Pops up a menu on a right-click in files list."""
        self.listctrl.PopupMenu(self.listmenu, wxPoint(event.GetX(),event.GetY()))

    def OnRightUpTree(self,event):
        """ Pops up a menu on a right click in dirs tree. """
        pt = event.GetPosition()
        item, flags = self.tree.HitTest(pt)
        self.tree.SelectItem(item)
        self.tree.PopupMenu(self.treemenu, pt)

    """ Handlers for the menu items"""
    def OnSendMessage(self, event):
        self.privatechat.SendMessage(self.user)

    def OnGetInfo(self, event):
        self.processrequest(self.user, slskmessages.UserInfoRequest(None), self.info)

    def ShowInfo(self,msg):
        """ We got the filelist, now set up the directory tree and sort it."""
        self.conn = None
        self.list = msg.list
        self.tree.DeleteAllItems()
        root = self.tree.AddRoot("The Root Item")
        treedict = { "root": (root,{}) }
        for i in self.list.keys():
            dirs = i.split('\\')
            node = treedict["root"]
            for j in dirs:
                if not node[1].has_key(j):
                     node[1][j] = (self.tree.AppendItem(node[0],j),{})
                node = node[1][j]
            self.tree.SetPyData(node[0], (i, self.list[i]))
        self.SortTree(treedict["root"])

    def SortTree(self,node):
        self.tree.SortChildren(node[0])
        for i in node[1].keys():
            self.SortTree(node[1][i])

    def OnTreeSelChanged(self, event):
        """ On selection of a tree item, display the filelist"""
        self.listctrl.SetFileList(self.tree.GetPyData(event.GetItem()))

    def OnDownloadDir(self,event):
        """ Get every file in the directory """
        import string
        dir = string.split(self.listctrl.dir,'\\')[-1]
        for i in self.listctrl.list:
            self.transfers.getFile(self.user, self.listctrl.dir+'\\'+i[1], dir)

    def OnDownloadFile(self,event):
        """ Get single file """
        self.transfers.getFile(self.user,self.listctrl.dir+'\\'+self.listctrl.list[self.id][1])

    def UpdateGauge(self,msg):
        """ If the filelist is long, this is handy"""
        self.gauge.SetRange(msg.total)
        self.gauge.SetValue(msg.bytes)

    def OnClose(self, event):
        """ Closes the window."""
        del self.parent.users[self.user]
        self.parent.DeletePage(self.parent.GetSelection())
        self.parent.SetSelection(0)


