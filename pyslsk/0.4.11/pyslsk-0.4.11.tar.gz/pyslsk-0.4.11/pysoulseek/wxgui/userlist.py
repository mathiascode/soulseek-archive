# Copyright (c) 2001-2002 Alexander Kanavin. All rights reserved.

"""
This module contains GUI classes for the userlist.
"""

import time
from pysoulseek import slskproto
from pysoulseek import slskmessages
import Queue
import threading
import images
import about
import userinfobrowse
import search
from sortablelist import sortableListCtrl
from wxPython.wx import *


class UserListPanel(wxPanel): 
    """ This panel contains a rooms list and an input box to create a room """
    def __init__(self, parent, id,frame):
        wxPanel.__init__(self, parent, id)
	self.frame = frame
        self.userlist = UserListCtrl(self,-1)
        self.adduser = wxTextCtrl(self,-1, style = wxTE_PROCESS_ENTER)
        self.add = wxStaticText(self, -1, "Add:")

        sizerh = wxBoxSizer(wxHORIZONTAL)
        sizerh.Add(self.add,0,wxALIGN_CENTER)
        sizerh.Add(self.adduser,1,wxEXPAND)
        sizerv = wxBoxSizer(wxVERTICAL)
        sizerv.Add(self.userlist,1,wxEXPAND)
        sizerv.Add(sizerh,0,wxEXPAND)

        self.SetSizer(sizerv)
        self.SetAutoLayout(true)
        EVT_TEXT_ENTER(self,self.adduser.GetId(),self.OnEnter)

        
    def OnEnter(self, event):
        """ Add a room or join an existing one """
        text = self.adduser.GetLineText(0)
        self.adduser.Clear()
	self.frame.AddToList(text)

    def update(self):
	self.userlist.SetItemCount(len(self.frame.userlist))

class UserListCtrl(sortableListCtrl):
    """
    This is a list control for the users list 
    """
    def __init__(self, parent, id, style = wxLC_REPORT|wxLC_VIRTUAL):
        sortableListCtrl.__init__(self,parent,id,style = style)
        self.InsertColumn(0,"User", width=130)

        self.online = self.imglist.Add(images.getOnlineBitmap())
        self.offline = self.imglist.Add(images.getOfflineBitmap())
        self.away = self.imglist.Add(images.getAwayBitmap())
#        self.AssignImageList(self.imglist,wxIMAGE_LIST_SMALL)

        self.parent = parent
	self.SetItemCount(len(self.parent.frame.userlist))

        self.menu = wxMenu()
        sendmessageID=wxNewId()
        self.menu.Append(sendmessageID, 'Send Message')
        EVT_MENU(self,sendmessageID, self.OnSendMessage)
        showipID=wxNewId()
        self.menu.Append(showipID, 'Show IP address')
        EVT_MENU(self,showipID, self.OnShowIp)
        getinfoID=wxNewId()
        self.menu.Append(getinfoID, 'Get User Info')
        EVT_MENU(self,getinfoID, self.OnGetInfo)
        browseID=wxNewId()
        self.menu.Append(browseID, 'Browse Files')
        EVT_MENU(self,browseID, self.OnBrowse)
	self.menu.AppendSeparator()
	removeID=wxNewId()
	self.menu.Append(removeID, 'Remove')
	EVT_MENU(self,removeID,self.OnRemove)

        EVT_RIGHT_UP(self,self.OnRightUp)

    def OnRightUp(self,event):
        """ Pops up a menu on a right-click in users list."""
        pt = event.GetPosition()
        item, flags = self.HitTest(pt)
        self.item = item
        if item >= 0:
	    self.focuseduser = self.parent.frame.userlist[self.item][0]
            self.SetItemState(item,wxLIST_STATE_FOCUSED,wxLIST_STATE_FOCUSED)
            self.PopupMenu(self.menu, wxPoint(event.GetX(),event.GetY()))

    """ Handlers for the menu items"""
    def OnSendMessage(self, event):
        self.parent.frame.np.privatechat.SendMessage(self.focuseduser)

    def OnShowIp(self, event):
        self.parent.frame.np.queue.put(slskmessages.GetPeerAddress(self.focuseduser))

    def OnGetInfo(self, event):
        self.parent.frame.np.ProcessRequestToPeer(self.focuseduser, slskmessages.UserInfoRequest(None), self.parent.frame.np.userinfo)

    def OnBrowse(self, event):
        self.parent.frame.np.ProcessRequestToPeer(self.focuseduser, slskmessages.GetSharedFileList(None), self.parent.frame.np.userbrowse)

    def OnRemove(self,event):
	length = len(self.parent.frame.userlist)
	for i in range(length):
            self.SetItemState(i,0,wxLIST_STATE_SELECTED|wxLIST_STATE_FOCUSED)
	del self.parent.frame.userlist[self.item]

	self.SetItemCount(length-1)

    def OnGetItemText(self, item, col):
        username =  self.parent.frame.userlist[item][0]
        return self.GetColumnValue(username,col)

    def GetColumnValue(self,username,col):
        if col == 0:
            return username
        else:
            return None

    def OnGetItemImage(self,item):
        if self.parent.frame.userlist[item][1] == 1:
            return self.away
        elif self.parent.frame.userlist[item][1] == 2:
            return self.online
        elif self.parent.frame.userlist[item][1] == 0:
            return self.offline
        else:
            return -1

    def SortList(self, col, order):
        if order == 0:
            self.parent.frame.userlist.sort(lambda x,y: cmp(self.GetColumnValue(x,col),self.GetColumnValue(y,col)))
        else:
            self.parent.frame.userlist.sort(lambda y,x: cmp(self.GetColumnValue(x,col),self.GetColumnValue(y,col)))

