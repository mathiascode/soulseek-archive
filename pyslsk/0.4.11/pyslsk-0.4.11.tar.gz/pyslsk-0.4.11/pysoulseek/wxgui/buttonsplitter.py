# Copyright (c) 2001-2002 Alexander Kanavin. All rights reserved.

"""
This is the client code for the notebook with bird icons.
"""

from wxPython.wx import *
import images

class ButtonSplitterWindow(wxSplitterWindow):
    def __init__(self, parent, id, getleft, getright, style = wxSP_3D): 
        wxSplitterWindow.__init__(self,parent,id, style = style)

	self.panel = wxPanel(self, -1)
	self.expbutton = wxButton(self.panel,-1,"<",size=(10,100))
        
        self.sizer = wxBoxSizer(wxHORIZONTAL)
        self.sizer.Add(self.expbutton,0,wxALIGN_CENTER)
        self.panel.SetSizer(self.sizer)
        self.panel.SetAutoLayout(true)
        self.splitterpos = 650
        self.Initialize(self.panel)
	self.sx = self.sy = None
	EVT_BUTTON(self, self.expbutton.GetId(),self.OnExpButton)
	self.getleft = getleft
	self.getright = getright
	self.left = None
	self.right = None

    def InitLeft(self):
	self.left = self.getleft()
        self.sizer.Prepend(self.left,1,wxEXPAND)
        EVT_SIZE(self, self.OnSizeSplitter)

	
    def OnExpButton(self,event):
        if self.expbutton.GetLabel() == "<":
            self.expbutton.SetLabel(">")
            self.right = self.getright()
            self.SplitVertically(self.panel,self.right,self.splitterpos)
        else:
            self.expbutton.SetLabel("<")
            self.splitterpos = self.GetSashPosition()
            self.Unsplit()
            self.right = None

    def OnSizeSplitter(self,event):
        x,y = self.GetSize()
        if self.sx is None:
             self.sx = x
             self.sy = y
        self.SetSashPosition(self.GetSashPosition()+(x-self.sx))
        self.splitterpos = self.splitterpos+(x-self.sx)
        self.sx = x
        self.sy = y

