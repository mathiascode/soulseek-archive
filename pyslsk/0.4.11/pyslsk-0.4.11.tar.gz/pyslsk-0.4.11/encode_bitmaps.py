#!/usr/bin/env python

import sys, string

from wxPython.tools import img2py


command_lines = [
    "   -i -n Bird img/bird.jpg pysoulseek/wxgui/images.py",
    "-a -n Away img/away.gif pysoulseek/wxgui/images.py",
    "-a -n Online img/online.gif pysoulseek/wxgui/images.py",
    "-a -n Offline img/offline.gif pysoulseek/wxgui/images.py",
    "-a -n Down img/sm_down.png pysoulseek/wxgui/images.py",
    "-a -n Up img/sm_up.png pysoulseek/wxgui/images.py",
    
    ]


def encode():
    for line in command_lines:
        args = string.split(line)
        img2py.main(args)

if __name__ == '__main__':
    encode()
