#!/usr/bin/env python

import sys, string
sys.path.insert(0, "tools")

import img2py


command_lines = [
    "   -n Away img/away.bmp pysoulseek/images.py",
    "-a -n Online img/online.bmp pysoulseek/images.py",
    "-a -n Offline img/offline.bmp pysoulseek/images.py",
    "-a -n Bird img/bird.jpg pysoulseek/images.py",
    ]


def encode():
    for line in command_lines:
        args = string.split(line)
        img2py.main(args)

if __name__ == '__main__':
    encode()
