import time
from pysoulseek import slskproto
from pysoulseek import slskmessages
import Queue
import threading
import images
import about
import userinfobrowse
import search
import notebook
import buttonsplitter
import os
from sortablelist import sortableListCtrl
from wxPython.wx import *

class OutputWindow(wxTextCtrl):
    """
    Multiple-lines text control with a twist - cleans oldest 100 lines from 
    itself when 200 lines maximum is reached
    """
    def __init__(self, parent, id, style):
        wxTextCtrl.__init__(self,parent,id,style = style)
        self.lines = 1
        self.chars = 0

    def AppendText(self, text):
        wxTextCtrl.AppendText(self,text)
        self.lines = self.lines + 1
        if self.lines == 100:
             self.chars = wxTextCtrl.GetLastPosition(self)
        if self.lines == 200:
             wxTextCtrl.Remove(self,0,self.chars)
             wxTextCtrl.SetInsertionPointEnd(self)
             self.chars = wxTextCtrl.GetLastPosition(self)
             self.lines = 100

class ChatRooms(buttonsplitter.ButtonSplitterWindow):
    """ This window contains a rooms list and a rooms notebook """
    def __init__(self, parent, id, queue, privatechat, peerconns, frame,  style = wxNO_3D|wxSP_3D):
	self.queue = queue
	self.privatechat = privatechat
	self.peerconns = peerconns
	self.frame = frame

        buttonsplitter.ButtonSplitterWindow.__init__(self,parent,id,self.getLeft,self.getRight,style = style)
        self.roomsnotebook = notebook.IconNotebook(self.panel, -1, style=wxCLIP_CHILDREN)
        self.roomsctrl = None
	self.InitLeft()
	self.splitterpos = -180
        self.OnExpButton(None)


    def getLeft(self):
	return self.roomsnotebook

    def getRight(self):
	self.roomsctrl = RoomsCtrl(self,-1, self.queue, self.privatechat, self.peerconns, self.frame, self.roomsnotebook, self.roomsctrl)
	return self.roomsctrl	

class RoomsCtrl(wxPanel):
    """ This panel contains a rooms list and an input box to create a room """
    def __init__(self, parent, id, queue, privatechat, peerconns, frame, roomsnotebook, oldroomsctrl = None):
        wxPanel.__init__(self, parent, id)
	if oldroomsctrl is None:
            self.joinedrooms = {}
            self.joinedroomslist = []
            self.rooms = []
	else:
	    self.joinedrooms = oldroomsctrl.joinedrooms
	    self.joinedroomslist = oldroomsctrl.joinedroomslist
	    self.rooms = oldroomsctrl.rooms
        self.roomlist = RoomListCtrl(self,-1)
        self.addroom = wxTextCtrl(self,-1, style = wxTE_PROCESS_ENTER)
        self.create = wxStaticText(self, -1, "Create:")

        sizerh = wxBoxSizer(wxHORIZONTAL)
        sizerh.Add(self.create,0,wxALIGN_CENTER)
        sizerh.Add(self.addroom,1,wxEXPAND)
        sizerv = wxBoxSizer(wxVERTICAL)
        sizerv.Add(self.roomlist,1,wxEXPAND)
        sizerv.Add(sizerh,0,wxEXPAND)

        self.SetSizer(sizerv)
        self.SetAutoLayout(true)
        EVT_TEXT_ENTER(self,self.addroom.GetId(),self.OnEnter)
	

        self.parent = parent
        self.queue = queue
        self.privatechat = privatechat
        self.peerconns = peerconns
        self.frame = frame
        self.roomsnotebook = roomsnotebook

        self.menu = wxMenu()
        self.joinID = wxNewId()
        self.menu.Append(self.joinID, 'Join Room')
        EVT_MENU(self,self.joinID, self.OnJoinRoom)
        self.leaveID = wxNewId()
        self.menu.Append(self.leaveID, 'Leave Room')
        EVT_MENU(self,self.leaveID, self.OnLeaveRoom)
	self.menu.AppendSeparator()
        self.addautojoinID = wxNewId()
        self.menu.Append(self.addautojoinID, 'Add to Auto-Join')
        EVT_MENU(self,self.addautojoinID, self.OnAddAutoJoin)
        self.removeautojoinID=wxNewId()
        self.menu.Append(self.removeautojoinID, 'Remove from Auto-Join')
        EVT_MENU(self,self.removeautojoinID, self.OnRemoveAutoJoin)
        self.menu.AppendSeparator()
        refreshID=wxNewId()
        self.menu.Append(refreshID, 'Refresh Room List')
        EVT_MENU(self,refreshID, self.OnRefresh)

        EVT_RIGHT_UP(self.roomlist, self.OnRightUp)

    def OnEnter(self, event):
	""" Add a room or join an existing one """
        text = self.addroom.GetLineText(0)
        self.queue.put(slskmessages.JoinRoom(text))
        self.addroom.Clear()

    def OnRightUp(self, event):
        """ Show the pop-up menu"""
        pt = event.GetPosition()
        item, flags = self.roomlist.HitTest(pt)
        self.item = item
        if item != -1:
            self.roomlist.SetItemState(item,wxLIST_STATE_FOCUSED,wxLIST_STATE_FOCUSED)
            if self.rooms[self.item][0] in self.joinedrooms.keys():
                self.menu.Enable(self.joinID,0)
                self.menu.Enable(self.leaveID,1)
            else:
                self.menu.Enable(self.joinID,1)
                self.menu.Enable(self.leaveID,0)
	    if self.rooms[self.item][0] in self.frame.np.config.sections["server"]["autojoin"]:
		self.menu.Enable(self.addautojoinID,0)
		self.menu.Enable(self.removeautojoinID,1)
	    else:
                self.menu.Enable(self.addautojoinID,1)
                self.menu.Enable(self.removeautojoinID,0)
            self.roomlist.PopupMenu(self.menu, pt)

    def OnJoinRoom(self, event):
        self.queue.put(slskmessages.JoinRoom(self.rooms[self.item][0]))

    def OnLeaveRoom(self, event):
        self.queue.put(slskmessages.LeaveRoom(self.rooms[self.item][0]))

    def OnAddAutoJoin(self, event):
	 self.frame.np.config.sections["server"]["autojoin"].append(self.rooms[self.item][0])

    def OnRemoveAutoJoin(self, event):
	self.frame.np.config.sections["server"]["autojoin"].remove(self.rooms[self.item][0])

    def OnRefresh(self,event):
        self.queue.put(slskmessages.RoomList())

    def SetGreeting(self, text):
# Don't know where to put that at the moment
        self.greeting = text
	self.frame.logMessage("Server greeting:\n" + text)

    def SetRoomList(self, msg):
        self.rooms = msg.rooms
        self.rooms.sort(self.SortRoomList)
        self.roomlist.SetItemCount(len(self.rooms))
	for i in self.frame.np.config.sections["server"]["autojoin"]:
		self.queue.put(slskmessages.JoinRoom(i))

    def SortRoomList(self, item1, item2):
        if item1[1] > item2[1]:
            return -1
        elif item1[1] < item2[1]:
            return 1
        else:
            return 0

    def UserJoinedRoom(self, msg):
        self.CreateRoomWindow(msg.room)
        self.joinedrooms[msg.room].UserJoinedRoom(msg)

    def JoinRoom(self,msg):
        self.CreateRoomWindow(msg.room)
        self.joinedrooms[msg.room].JoinRoom(msg)

    def SayChatRoom(self,msg,text):
        self.CreateRoomWindow(msg.room)
        self.joinedrooms[msg.room].SayChatRoom(msg,text)
	self.frame.OnPageUpdated(self.parent)

    def UserLeftRoom(self,msg):
        self.CreateRoomWindow(msg.room)
        self.joinedrooms[msg.room].UserLeftRoom(msg)

    def QueuedDownloads(self, msg):
        for i in self.joinedrooms.keys():
            if msg.user in self.joinedrooms[i].users.keys():
                self.joinedrooms[i].QueuedDownloads(msg)

    def GetUserStatus(self, msg):
        for i in self.joinedrooms.keys():
            if msg.user in self.joinedrooms[i].users.keys():
                self.joinedrooms[i].GetUserStatus(msg)

    def GetUserStats(self, msg):
        for i in self.joinedrooms.keys():
            if msg.user in self.joinedrooms[i].users.keys():
                self.joinedrooms[i].GetUserStats(msg)

    def LeaveRoom(self,msg):
        self.roomsnotebook.DeletePage(self.joinedroomslist.index(msg.room))
        self.joinedroomslist.remove(msg.room)
        del self.joinedrooms[msg.room]

    def CreateRoomWindow(self, room):
        if room not in self.joinedrooms.keys():
            self.joinedrooms[room] = ChatWindow(self.roomsnotebook, -1, self.queue, self.privatechat, self.peerconns, self.frame)

            self.roomsnotebook.AddPage(self.joinedrooms[room],room)
            self.joinedroomslist.append(room)
            


class RoomListCtrl(sortableListCtrl):
    """ Actual room list control """
    def __init__(self, parent, id, style = wxLC_REPORT|wxLC_VIRTUAL):
        sortableListCtrl.__init__(self,parent,id,style = style)
        self.InsertColumn(0,"Room", width=100)
        self.InsertColumn(1,"Users",width=50)
        self.SetItemCount(len(parent.rooms))

        self.parent = parent

    def OnGetItemText(self, item, col):
        return self.parent.rooms[item][col]

    def OnGetItemImage(self,item):
	return -1

    def SortList(self, col, order):
        if order == 0:
            self.parent.rooms.sort(lambda x,y: cmp(x[col],y[col]))
        else:
            self.parent.rooms.sort(lambda y,x: cmp(x[col],y[col]))


class GlobalUsersList(wxPanel):
    """ This window contains a global list of users. """
    def __init__(self, parent, id, queue, privatechat, peerconns, frame):
        wxPanel.__init__(self, parent, id)

	self.queue = queue
	self.privatechat = privatechat
	self.peerconns = peerconns
	self.frame = frame

	self.userslistctrl = UsersList(self, -1,style = wxLC_REPORT|wxLC_VIRTUAL|wxSUNKEN_BORDER)
	self.userslist = []
	self.users = {}

        self.note = wxStaticText(self, -1, "This list does not auto-update")
	self.update = wxButton(self, -1, "Update")
	
        sizerh = wxBoxSizer(wxHORIZONTAL)
        sizerh.Add(self.update,0,wxEXPAND)
        sizerh.Add(self.note,1,wxALIGN_CENTER)
        sizerv = wxBoxSizer(wxVERTICAL)
        sizerv.Add(sizerh,0,wxEXPAND)
        sizerv.Add(self.userslistctrl,1,wxEXPAND)
        self.SetSizer(sizerv)
        self.SetAutoLayout(true)

        EVT_BUTTON(self,self.update.GetId(), self.OnUpdate)

    def OnUpdate(self, event):
        self.queue.put(slskmessages.GlobalUserList())

    def setGlobalUsersList(self, msg):
        self.users = msg.users
        self.userslist = self.users.keys()
        self.userslist.sort()
        self.userslistctrl.SetItemCount(len(self.users))
	privileged = self.frame.np.transfers.privilegedusers
	numprivonline = len([i for i in privileged if i in self.userslist])
	self.frame.logMessage("Currently %i users online (%i or %.1f" % (len(self.users),numprivonline, float(numprivonline)/len(self.users)*100) + " percent of them are privileged)") 
        self.frame.OnPageUpdated(self)


class UsersList(sortableListCtrl):
    """
    This is a list control for the users list in chat window and in global 
    users list. Gets users
    data from parent window (which should have a userslist attribute).
    """
    def __init__(self, parent, id, style = wxLC_REPORT|wxLC_VIRTUAL):
        sortableListCtrl.__init__(self,parent,id,style = style)
        self.InsertColumn(0,"User", width=100)
        self.InsertColumn(1,"Speed",width=50)
        self.InsertColumn(2,"Files",width=50)
        self.SetItemCount(0)
        self.normal = wxListItemAttr()
        self.normal.SetTextColour("black")
        self.grey = wxListItemAttr()
        self.grey.SetTextColour("grey")

        self.online = self.imglist.Add(images.getOnlineBitmap())
        self.offline = self.imglist.Add(images.getOfflineBitmap())
        self.away = self.imglist.Add(images.getAwayBitmap())
#        self.AssignImageList(self.imglist,wxIMAGE_LIST_SMALL)

        self.parent = parent.GetParent()

        self.menu = wxMenu()
        sendmessageID=wxNewId()
        self.menu.Append(sendmessageID, 'Send Message')
        EVT_MENU(self,sendmessageID, self.OnSendMessage)
        showipID=wxNewId()
        self.menu.Append(showipID, 'Show IP address')
        EVT_MENU(self,showipID, self.OnShowIp)
        getinfoID=wxNewId()
        self.menu.Append(getinfoID, 'Get User Info')
        EVT_MENU(self,getinfoID, self.OnGetInfo)
        browseID=wxNewId()
        self.menu.Append(browseID, 'Browse Files')
        EVT_MENU(self,browseID, self.OnBrowse)
        addtolistID=wxNewId()
        self.menu.Append(addtolistID, 'Add to User List')
        EVT_MENU(self,addtolistID, self.OnAddToList)


        EVT_RIGHT_UP(self,self.OnRightUp)

    def OnRightUp(self,event):
        """ Pops up a menu on a right-click in users list."""
        pt = event.GetPosition()
        item, flags = self.HitTest(pt)
        if item >= 0:
	    self.focuseduser=self.GetItemText(item)
            self.SetItemState(item,wxLIST_STATE_FOCUSED,wxLIST_STATE_FOCUSED)
            self.PopupMenu(self.menu, pt)

    """ Handlers for the menu items"""
    def OnSendMessage(self, event):
        self.parent.privatechat.SendMessage(self.focuseduser)

    def OnShowIp(self, event):
        self.parent.queue.put(slskmessages.GetPeerAddress(self.focuseduser))

    def OnGetInfo(self, event):
        self.parent.frame.np.ProcessRequestToPeer(self.focuseduser, slskmessages.UserInfoRequest(None), self.parent.frame.np.userinfo)

    def OnBrowse(self, event):
        self.parent.frame.np.ProcessRequestToPeer(self.focuseduser, slskmessages.GetSharedFileList(None), self.parent.frame.np.userbrowse)

    def OnAddToList(self, event):
	self.parent.frame.AddToList(self.focuseduser)


    def OnGetItemText(self, item, col):
        username =  self.parent.userslist[item]
	return self.GetColumnValue(username,col)

    def GetColumnValue(self,username,col):
        if col == 0:
            return username
        elif col == 1:
            return self.parent.users[username].avgspeed
        elif col == 2:
            return self.parent.users[username].files
        else:
            return None

    def OnGetItemAttr(self,item):
        username =  self.parent.userslist[item]
        if self.parent.users[username].slotsfull == 1:
            return self.grey
        else:
            return self.normal

    def OnGetItemImage(self,item):
        username = self.parent.userslist[item]
        if self.parent.users[username].status == 1:
            return self.away
        elif self.parent.users[username].status == 2:
            return self.online
        else:
            return -1

    def SortList(self, col, order):
	if order == 0:
	    self.parent.userslist.sort(lambda x,y: cmp(self.GetColumnValue(x,col),self.GetColumnValue(y,col)))
	else:
	    self.parent.userslist.sort(lambda y,x: cmp(self.GetColumnValue(x,col),self.GetColumnValue(y,col)))


class ChatWindow(wxSplitterWindow):
    """
    The chat window that holds a users list, info window and dialog window.
    Also contains users dictionary that holds info about every user in a room.
    """
    def __init__(self, parent, id, queue, privatechat, peerconns, frame, style = wxNO_3D|wxSP_3D):
        wxSplitterWindow.__init__(self,parent,id,wxDefaultPosition,wxDefaultSize,style,"splitterWindow")
        splitter = wxSplitterWindow(self,-1,style=wxNO_3D|wxSP_3DSASH)
	userlistpanel = wxPanel(self,-1)
        self.userslistctrl = UsersList(userlistpanel,-1,style=wxLC_REPORT|wxLC_VIRTUAL)
	self.leave = wxButton(userlistpanel, -1, "Leave")
        self.logctrl = wxCheckBox(userlistpanel, -1, "Log");
        self.logctrl.SetValue(frame.np.config.sections["logging"]["chatrooms"])
        EVT_CHECKBOX(self, self.logctrl.GetId(), self.OnLogCheckClick)

        sizerh = wxBoxSizer(wxHORIZONTAL)
        sizerh.Add(self.logctrl,1,wxALIGN_LEFT)
        sizerh.Add(self.leave,0,wxALIGN_RIGHT)

        sizerv = wxBoxSizer(wxVERTICAL)
        sizerv.Add(self.userslistctrl,1,wxEXPAND)
        sizerv.Add(sizerh,0,wxEXPAND)
        
        userlistpanel.SetSizer(sizerv)
        userlistpanel.SetAutoLayout(true)
        self.SplitVertically(splitter,userlistpanel,-220)
        self.info = OutputWindow(splitter,-1,style = wxTE_MULTILINE|wxTE_READONLY|wxTE_RICH)

        chatpanel = wxPanel(splitter,-1)
        self.chat = OutputWindow(chatpanel,-1,style = wxTE_MULTILINE|wxTE_READONLY|wxTE_RICH)
        self.mychatphrase = wxTextCtrl(chatpanel,-1, style = wxTE_PROCESS_ENTER)

        chatsizer = wxBoxSizer(wxVERTICAL)
        chatsizer.Add(self.chat,1,wxEXPAND)
        chatsizer.Add(self.mychatphrase,0,wxEXPAND)
        chatpanel.SetSizer(chatsizer)
        chatpanel.SetAutoLayout(true)

        splitter.SplitHorizontally(self.info,chatpanel,100)

        self.queue = queue
        self.privatechat = privatechat
        self.users = {} #without IP/fw cache
        self.peerconns = peerconns
        self.frame = frame
	self.room = None
	self.parent = parent
        self.logfile = None

        EVT_TEXT_ENTER(self,self.mychatphrase.GetId(),self.OnEnter)
	EVT_BUTTON(self,self.leave.GetId(),self.OnLeave)

        EVT_SIZE(self, self.OnSize) 
        self.x,self.y = self.GetSize()

    def OnSize(self, event):
        x,y = self.GetSize()
        self.SetSashPosition(self.GetSashPosition()+(x-self.x))
        self.x = x
        self.y = y
        event.Skip()

    def OnEnter(self, event):
        """ Processes chat phrase that we entered. """
        text = self.mychatphrase.GetLineText(0)
        self.queue.put(slskmessages.SayChatroom(self.room, self.frame.np.encodestring(text)))
        self.mychatphrase.Clear()

    def OnLeave(self, event):
	if self.room is not None:
	    self.queue.put(slskmessages.LeaveRoom(self.room))
	    self.leave.Enable(0)

    """ These functions process various messages from the server. """
    def UserJoinedRoom(self, msg):
        self.room = msg.room
	if msg.username not in self.users.keys():
            self.info.AppendText("%s %s joined the room\n" %(time.strftime("%X"),msg.username))	
        self.users[msg.username] = msg.userdata
        self.userslist = self.users.keys()
	if self.userslistctrl.sortcol == -1:
            self.userslist.sort()
	else:
	    self.userslistctrl.SortList(self.userslistctrl.sortcol,self.userslistctrl.sortorder)
        self.userslistctrl.SetItemCount(len(self.users))


    def JoinRoom(self, msg):
        self.room = msg.room
        self.users = msg.users
        self.userslist = self.users.keys()
        self.userslist.sort()
        self.userslistctrl.SetItemCount(len(self.users))
        if self.logctrl.GetValue() == 1:
            self.OnLogCheckClick(None)

    def UserLeftRoom(self, msg):
        self.room = msg.room
        if msg.username in self.users.keys():
            del self.users[msg.username]
            self.info.AppendText("%s %s left the room\n" %(time.strftime("%X"),msg.username))
        self.userslist = self.users.keys()
        if self.userslistctrl.sortcol == -1:
            self.userslist.sort()
        else:
            self.userslistctrl.SortList(self.userslistctrl.sortcol,self.userslistctrl.sortorder)
        self.userslistctrl.SetItemCount(len(self.users))


    def SayChatRoom(self, msg, text):
        self.room = msg.room

	if text[:4] == "/me ":
	    str = "%s * %s %s\n" %(time.strftime("%X"),msg.user,text[4:])
	    color = "FOREST GREEN"
	else:
	    str = "%s [%s] %s\n" %(time.strftime("%X"),msg.user,text)
	    if msg.user == self.frame.np.config.sections["server"]["login"]:
		color = "BLUE"
	    else:
		color = "BLACK"

        style = self.chat.GetDefaultStyle()
        self.chat.SetDefaultStyle(wxTextAttr(color))
        self.chat.AppendText(str)
        self.chat.SetDefaultStyle(style)
	self.parent.OnPageUpdated(self)
        if self.logctrl.GetValue():
            self.logfile.write(str)

    def QueuedDownloads(self, msg):
        self.users[msg.user].slotsfull = msg.slotsfull
        self.userslistctrl.SetItemCount(len(self.users))

    def GetUserStatus(self, msg):
        if msg.status != self.users[msg.user].status:
            if msg.status == 1:
                text = "%s %s has gone away\n"
            else:
                text = "%s %s has returned\n"
            self.info.AppendText(text %(time.strftime("%X"),msg.user))	
            self.users[msg.user].status = msg.status
            self.userslistctrl.SetItemCount(len(self.users))

    def GetUserStats(self, msg):
        self.users[msg.user].avgspeed = msg.avgspeed
        self.users[msg.user].downloadnum = msg.downloadnum
        self.users[msg.user].something = msg.something
        self.users[msg.user].files = msg.files
        self.users[msg.user].dirs = msg.dirs
        self.userslistctrl.SetItemCount(len(self.users))

    def OnLogCheckClick(self, event):
        """ This is called when the 'Log' checkbox is clicked """
        if self.logctrl.GetValue() == 1:
            oldumask = os.umask(0077)
            self.logfile = open(os.path.join(self.frame.np.config.sections["transfers"]["downloaddir"], string.replace(self.room, os.sep, "-") + ".log"), 'a', 0)
            os.umask(oldumask)
        else:
            self.logfile.close()

class PrivateChatNotebook(notebook.IconNotebook):
    """
    This class is a notebook of private chat windows. Actual window 
    pointers are stored in user dictionary.
    """
    def __init__(self, parent, id, queue, np, style=wxCLIP_CHILDREN|wxNB_RIGHT):
        notebook.IconNotebook.__init__(self,parent,id,style = style)
        self.users={}
        self.queue = queue
	self.np = np

    def ShowMessage(self, msg, text):
        """ Processes MessageUser message from the server. """
	import time
        if not self.users.has_key(msg.user):
            self.users[msg.user] = PrivateChatWindow(self, -1, msg.user)
            self.AddPage(self.users[msg.user], msg.user)
       	    self.np.queue.put(slskmessages.GetUserStatus(msg.user))

	if text[:4] == "/me ":
	    str = "%s * %s %s\n" %(time.strftime("%c",time.localtime()),msg.user,text[4:])
	    color = "FOREST GREEN"
	else:
	    str = "%s [%s] %s\n" %(time.strftime("%c",time.localtime()),msg.user,text)
	    color = wxBLACK
	self.users[msg.user].AddText(str,color)
	self.np.frame.OnPageUpdated(self)
	self.OnPageUpdated(self.users[msg.user])
        if self.users[msg.user].logctrl.GetValue():
            self.users[msg.user].logfile.write(str)

    def SendMessage(self, user):
        """ Adds a notebook tab with a user's name on it, and private chat 
        window inside the tab
        """
        if not self.users.has_key(user):
            self.users[user] = PrivateChatWindow(self, -1, user)
            self.AddPage(self.users[user],user)
	    self.np.queue.put(slskmessages.GetUserStatus(user))

    def GetUserStatus(self, msg):
	if self.users.has_key(msg.user):
	    for i in range(self.GetPageCount()):
	        if self.GetPage(i) == self.users[msg.user] and self.GetPage(i).status != msg.status:
		    self.users[msg.user].status = msg.status
		    str = "%s * %s's status is unknown"
		    color = "RED3"
		    if msg.status == 0:
			self.SetPageText(i, msg.user + " (offline)")
			str = "%s * %s is offline\n"
		    elif msg.status == 1:
			self.SetPageText(i, msg.user + " (away)")
			str = "%s * %s is away\n"
                    elif msg.status == 2:
                        self.SetPageText(i, msg.user + " (online)")
			str = "%s * %s is online\n"
		    str = str %(time.strftime("%c",time.localtime()),msg.user)
		    self.users[msg.user].AddText(str,color)
                    if self.users[msg.user].logctrl.GetValue():
                        self.users[msg.user].logfile.write(str)

class PrivateChatWindow(wxPanel):
    """ This is a window for chatting with someone in private """
    def __init__(self, parent, id, user):
        wxPanel.__init__(self, parent, id)
        self.chat = wxTextCtrl(self,-1,style = wxTE_MULTILINE|wxTE_READONLY|wxTE_RICH)
        self.mychatphrase = wxTextCtrl(self,-1, style = wxTE_PROCESS_ENTER)
        self.close = wxButton(self, -1, "Close")
        self.logctrl = wxCheckBox(self, -1, "Log");
        self.logctrl.SetValue(parent.np.config.sections["logging"]["privatechat"])
        EVT_CHECKBOX(self, self.logctrl.GetId(), self.OnLogCheckClick)
        
        sizerh = wxBoxSizer(wxHORIZONTAL)
        sizerh.Add(self.mychatphrase,1,wxEXPAND)
        sizerh.Add(self.logctrl,0,wxEXPAND)
        sizerh.Add(self.close,0,wxEXPAND)
        sizerv = wxBoxSizer(wxVERTICAL)
        sizerv.Add(self.chat,1,wxEXPAND)
        sizerv.Add(sizerh,0,wxEXPAND)

        self.SetSizer(sizerv)
        self.SetAutoLayout(true)
        EVT_BUTTON(self,self.close.GetId(), self.OnClose)
        EVT_TEXT_ENTER(self,self.mychatphrase.GetId(),self.OnEnter)

        self.user = user
        self.parent = parent
	self.status = -1
        self.logfile = None

        if self.logctrl.GetValue() == 1:
            self.OnLogCheckClick(None)

    def AddText(self,text, color = wxBLACK):
        """ Rather obvious really """
	style = self.chat.GetDefaultStyle()
	self.chat.SetDefaultStyle(wxTextAttr(color))
        self.chat.AppendText(text)
	self.chat.SetDefaultStyle(style)

    def OnClose(self, event):
        """ Close the window and update notebook's window list."""
	parent = self.parent
        del parent.users[self.user]
	parent.DeletePage(parent.GetSelection())
	if parent.GetPageCount() > 0:
	    parent.SetSelection(0)

    def OnEnter(self, event):
        """ Sends our chat phrase and updates the window."""
        text = self.mychatphrase.GetLineText(0)
	username = self.parent.np.config.sections["server"]["login"]
        if text[:4] == "/me ":
            str = "%s * %s %s\n" %(time.strftime("%c",time.localtime()),username,text[4:])
            color = "FOREST GREEN"
        else:
            str = "%s %s\n" %(time.strftime("%c",time.localtime()),text)
            color = wxBLUE

	self.AddText(str, color)
        self.parent.queue.put(slskmessages.MessageUser(self.user, self.parent.np.encodestring(text)))
        self.mychatphrase.Clear()
        if self.logctrl.GetValue():
            self.logfile.write(str)

    def OnLogCheckClick(self, event):
        """ This is called when the 'Log' checkbox is clicked """
        if self.logctrl.GetValue() == 1:
            oldumask = os.umask(0077)
            self.logfile = open(os.path.join(self.parent.np.config.sections["transfers"]["downloaddir"], string.replace(self.user, os.sep, "-") + ".log"), 'a', 0)
            os.umask(oldumask)
        else:
            self.logfile.close()
