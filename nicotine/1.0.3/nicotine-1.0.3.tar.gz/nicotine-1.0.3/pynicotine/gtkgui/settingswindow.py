# Copyright (c) 2003 Hyriand. All rights reserved.
#
import gtk
import gobject
import settings_glade
import locale

from dirchooser import ChooseDir
from utils import InputDialog, InitialiseColumns, recode, recode2

class ServerFrame(settings_glade.ServerFrame):
	def __init__(self, encodings):
		settings_glade.ServerFrame.__init__(self, gtk.FALSE)
		self.Server.set_popdown_strings(["mail.slsk.org:2240", "mail.slsk.org:2241"])
		self.Encoding.set_popdown_strings(encodings)

	def SetSettings(self, config):
		server = config["server"]
		if server["server"] is not None:
			self.Server.entry.set_text("%s:%i" % (server["server"][0], server["server"][1]))
		else:
			self.Server.entry.set_text("mail.slsk.org:2240")
		if server["login"] is not None:
			self.Login.set_text(server["login"])
		if server["passw"] is not None:
			self.Password.set_text(server["passw"])
		if server["enc"] is not None:
			self.Encoding.entry.set_text(server["enc"])
		if server["portrange"] is not None:
			self.FirstPort.set_text(str(server["portrange"][0]))
			self.LastPort.set_text(str(server["portrange"][1]))
		if server["firewalled"] is not None:
			self.DirectConnection.set_active(not server["firewalled"])
			
	def GetSettings(self):
		try:
			server = self.Server.entry.get_text().split(":")
			server[1] = int(server[1])
		except:
			server = None

		try:
			firstport = int(self.FirstPort.get_text())
			lastport = int(self.LastPort.get_text())
			portrange = (firstport, lastport)
		except:
			portrange = None
		
		return {
			"server": {
				"server": tuple(server),
				"login": self.Login.get_text(),
				"passw": self.Password.get_text(),
				"enc": self.Encoding.entry.get_text(),
				"portrange": portrange,
				"firewalled": not self.DirectConnection.get_active(),
			}
		}

class SharesFrame(settings_glade.SharesFrame):
	def __init__(self):
		settings_glade.SharesFrame.__init__(self, gtk.FALSE)
		self.needrescan = 0
		self.shareslist = gtk.ListStore(gobject.TYPE_STRING, gobject.TYPE_STRING)
		self.shareddirs = []
		column = gtk.TreeViewColumn("Shared dirs", gtk.CellRendererText(), text = 0)
		self.Shares.append_column(column)
		self.Shares.set_model(self.shareslist)
		self.Shares.get_selection().set_mode(gtk.SELECTION_MULTIPLE)

	def SetSettings(self, config):
		transfers = config["transfers"]
		if transfers["incompletedir"] is not None:
			self.IncompleteDir.set_text(recode(transfers["incompletedir"]))
		if transfers["downloaddir"] is not None:
			self.DownloadDir.set_text(recode(transfers["downloaddir"]))
		if transfers["sharedownloaddir"] is not None:
			self.ShareDownloadDir.set_active(transfers["sharedownloaddir"])
		self.shareslist.clear()
		if transfers["shared"] is not None:
			for share in transfers["shared"]:
				self.shareslist.append([recode(share), share])
			self.shareddirs = transfers["shared"][:]
		if transfers["rescanonstartup"] is not None:
			self.RescanOnStartup.set_active(transfers["rescanonstartup"])
		self.needrescan = 0

	def GetSettings(self):
		return {
			"transfers": {
				"incompletedir": recode2(self.IncompleteDir.get_text()),
				"downloaddir": recode2(self.DownloadDir.get_text()),
				"sharedownloaddir": self.ShareDownloadDir.get_active(),
				"shared": self.shareddirs[:],
				"rescanonstartup": self.RescanOnStartup.get_active(),
			}
		}
	
	def GetNeedRescan(self):
		return self.needrescan
	
	def OnChooseIncompleteDir(self, widget):
		dir = ChooseDir(self.Main.get_toplevel(), self.IncompleteDir.get_text())
		if dir is not None:
			self.incompletedir = dir
			self.IncompleteDir.set_text(recode(dir))

	def OnChooseDownloadDir(self, widget):
		dir = ChooseDir(self.Main.get_toplevel(), self.DownloadDir.get_text())
		if dir is not None:
			self.DownloadDir.set_text(recode(dir))
			if self.ShareDownloadDir.get_active():
				self.needrescan = 1

	def OnAddSharedDir(self, widget):
		dir = ChooseDir(self.Main.get_toplevel())
		if dir is not None:
			if dir not in self.shareddirs:
				self.shareslist.append([recode(dir), dir])
				self.shareddirs.append(dir)
				self.needrescan = 1

	def _RemoveSharedDir(self, model, path, iter, list):
		list.append(iter)

	def OnRemoveSharedDir(self, widget):
		iters = []
		self.Shares.get_selection().selected_foreach(self._RemoveSharedDir, iters)
		for iter in iters:
			dir = self.shareslist.get_value(iter, 1)
			self.shareddirs.remove(dir)
			self.shareslist.remove(iter)
		if iters:
			self.needrescan =1

	def OnShareDownloadDirToggled(self, widget):
		self.needrescan = 1

class TransfersFrame(settings_glade.TransfersFrame):
	def __init__(self):
		settings_glade.TransfersFrame.__init__(self, gtk.FALSE)

	def SetSettings(self, config):
		transfers = config["transfers"]
		server = config["server"]
		if transfers["uploadbandwidth"] is not None:
			self.QueueBandwidth.set_text(str(transfers["uploadbandwidth"]))
		if transfers["useupslots"] is not None:
			self.QueueUseSlots.set_active(transfers["useupslots"])
		if transfers["uploadslots"] is not None:
			self.QueueSlots.set_text(str(transfers["uploadslots"]))
		if transfers["uselimit"] is not None:
			self.Limit.set_active(transfers["uselimit"])
		if transfers["uploadlimit"] is not None:
			self.LimitSpeed.set_text(str(transfers["uploadlimit"]))
		if transfers["limitby"] is not None:
			if transfers["limitby"] == 0:
				self.LimitPerTransfer.set_active(1)
			else:
				self.LimitTotalTransfers.set_active(1)
		if transfers["queuelimit"] is not None:
			self.MaxUserQueue.set_text(str(transfers["queuelimit"]))
		if transfers["totalqueue"] is not None:
			self.MaxUseTotalQueue.set_active(transfers["totalqueue"])
		if transfers["totalqueuelimit"] is not None:
			self.MaxTotalQueue.set_text(str(transfers["totalqueuelimit"]))
		if transfers["friendsnolimits"] is not None:
			self.FriendsNoLimits.set_active(transfers["friendsnolimits"])
		if transfers["friendsonly"] is not None:
			self.FriendsOnly.set_active(transfers["friendsonly"])
		if transfers["preferfriends"] is not None:
			self.PreferFriends.set_active(transfers["preferfriends"])
		
		self.OnQueueUseSlotsToggled(self.QueueUseSlots)
		self.OnLimitToggled(self.Limit)
		self.OnMaxUseTotalQueueToggled(self.MaxUseTotalQueue)
		self.OnFriendsOnlyToggled(self.FriendsOnly)
	
	def GetSettings(self):
		try:
			uploadbandwidth = int(self.QueueBandwidth.get_text())
		except:
			uploadbandwidth = None
		
		try:
			uploadslots = int(self.QueueSlots.get_text())
		except:
			uploadslots = None
		
		try:
			uploadlimit = int(self.LimitSpeed.get_text())
		except:
			uploadlimit = None
			self.Limit.set_active(0)
		try:
			queuelimit = int(self.MaxUserQueue.get_text())
		except:
			queuelimit = None
		
		try:
			totalqueuelimit = int(self.MaxTotalQueue.get_text())
		except:
			totalqueuelimit = None
			self.MaxUseTotalQueue.set_active(0)
		
		return {
			"transfers": {
				"uploadbandwidth": uploadbandwidth,
				"useupslots": self.QueueUseSlots.get_active(),
				"uploadslots": uploadslots,
				"uselimit": self.Limit.get_active(),
				"uploadlimit": uploadlimit,
				"limitby": self.LimitTotalTransfers.get_active(),
				"queuelimit": queuelimit,
				"totalqueue": self.MaxUseTotalQueue.get_active(),
				"totalqueuelimit": totalqueuelimit,
				"friendsnolimits": self.FriendsNoLimits.get_active(),
				"friendsonly": self.FriendsOnly.get_active(),
				"preferfriends": self.PreferFriends.get_active(),
			},
		}

	def OnQueueUseSlotsToggled(self, widget):
		sensitive = widget.get_active()
		self.QueueSlots.set_sensitive(sensitive)
	
	def OnLimitToggled(self, widget):
		sensitive = widget.get_active()
		for w in self.LimitSpeed, self.LimitPerTransfer, self.LimitTotalTransfers:
			w.set_sensitive(sensitive)
	
	def OnMaxUseTotalQueueToggled(self, widget):
		sensitive = widget.get_active()
		self.MaxTotalQueue.set_sensitive(sensitive)

	def OnFriendsOnlyToggled(self, widget):
		sensitive = not widget.get_active()
		self.PreferFriends.set_sensitive(sensitive)

class GeoBlockFrame(settings_glade.GeoBlockFrame):
	def __init__(self):
		settings_glade.GeoBlockFrame.__init__(self, gtk.FALSE)
	
	def SetSettings(self, config):
		transfers = config["transfers"]
		if transfers["geoblock"] is not None:
			self.GeoBlock.set_active(transfers["geoblock"])
		if transfers["geopanic"] is not None:
			self.GeoPanic.set_active(transfers["geopanic"])
		if transfers["geoblockcc"] is not None:
			self.GeoBlockCC.set_text(transfers["geoblockcc"][0])
		self.OnGeoBlockToggled(self.GeoBlock)
	
	def GetSettings(self):
		return {
			"transfers": {
				"geoblock": self.GeoBlock.get_active(),
				"geopanic": self.GeoPanic.get_active(),
				"geoblockcc": [self.GeoBlockCC.get_text().upper()],
			}
		}

	def OnGeoBlockToggled(self, widget):
		sensitive = widget.get_active()
		self.GeoPanic.set_sensitive(sensitive)
		self.GeoBlockCC.set_sensitive(sensitive)

class UserinfoFrame(settings_glade.UserinfoFrame):
	def __init__(self):
		settings_glade.UserinfoFrame.__init__(self, gtk.FALSE)

	def SetSettings(self, config):
		userinfo = config["userinfo"]
		if userinfo["descr"] is not None:
			descr = recode(eval(userinfo["descr"], {}))
			self.Description.get_buffer().set_text(descr)
		if userinfo["pic"] is not None:
			self.Image.set_text(userinfo["pic"])

	def GetSettings(self):
		buffer = self.Description.get_buffer()
		start = buffer.get_start_iter()
		end = buffer.get_end_iter()
		descr = recode2(buffer.get_text(start, end)).__repr__()
		return {
			"userinfo": {
				"descr": descr,
				"pic": recode2(self.Image.get_text()),
			}
		}
		
	def OnChooseImage(self, widget):
		dlg = gtk.FileSelection()
		dlg.set_filename(self.Image.get_text())
		result = dlg.run()
		if result == gtk.RESPONSE_OK:
			self.Image.set_text(dlg.get_filename())
		dlg.destroy()

class BanFrame(settings_glade.BanFrame):
	def __init__(self):
		settings_glade.BanFrame.__init__(self, gtk.FALSE)
		self.banned = []
		self.banlist = gtk.ListStore(gobject.TYPE_STRING)
		column = gtk.TreeViewColumn("Users", gtk.CellRendererText(), text = 0)
		self.Banned.append_column(column)
		self.Banned.set_model(self.banlist)
		self.Banned.get_selection().set_mode(gtk.SELECTION_MULTIPLE)

		self.ignored = []
		self.ignorelist = gtk.ListStore(gobject.TYPE_STRING)
		column = gtk.TreeViewColumn("Users", gtk.CellRendererText(), text = 0)
		self.Ignored.append_column(column)
		self.Ignored.set_model(self.ignorelist)
		self.Ignored.get_selection().set_mode(gtk.SELECTION_MULTIPLE)
		
	def SetSettings(self, config):
		server = config["server"]
		transfers = config["transfers"]
		self.banlist.clear()
		self.ignorelist.clear()
		if server["banlist"] is not None:
			self.banned = server["banlist"][:]
			for banned in server["banlist"]:
				self.banlist.append([banned])
		if server["ignorelist"] is not None:
			self.ignored = server["ignorelist"][:]
			for ignored in server["ignorelist"]:
				self.ignorelist.append([ignored])
		if transfers["usecustomban"] is not None:
			self.UseCustomBan.set_active(transfers["usecustomban"])
		if transfers["customban"] is not None:
			self.CustomBan.set_text(transfers["customban"])
			
		self.OnUseCustomBanToggled(self.UseCustomBan)
	
	def GetSettings(self):
		return {
			"server": {
				"banlist": self.banned[:],
				"ignorelist": self.ignored[:],
			},
			"transfers": {
				"usecustomban": self.UseCustomBan.get_active(),
				"customban": self.CustomBan.get_text(),
			}
		}
	
	def OnAddBanned(self, widget):
		user = InputDialog(self.Main.get_toplevel(), "Ban user...", "User:")
		if user and user not in self.banned:
			self.banned.append(user)
			self.banlist.append([user])
	
	def _RemoveBanned(self, model, path, iter, l):
		l.append(iter)
	
	def OnRemoveBanned(self, widget):
		iters = []
		self.Banned.get_selection().selected_foreach(self._RemoveBanned, iters)
		for iter in iters:
			user = self.banlist.get_value(iter, 0)
			self.banned.remove(user)
			self.banlist.remove(iter)

	def OnClearBanned(self, widget):
		self.banned = []
		self.banlist.clear()

	def OnAddIgnored(self, widget):
		user = InputDialog(self.Main.get_toplevel(), "Ignore user...", "User:")
		if user and user not in self.ignored:
			self.ignored.append(user)
			self.ignorelist.append([user])
	
	def OnRemoveIgnored(self, widget):
		iters = []
		self.Ignored.get_selection().selected_foreach(self._RemoveBanned, iters)
		for iter in iters:
			user = self.ignorelist.get_value(iter, 0)
			self.ignored.remove(user)
			self.ignorelist.remove(iter)

	def OnClearIgnored(self, widget):
		self.ignored = []
		self.ignorelist.clear()

	def OnUseCustomBanToggled(self, widget):
		self.CustomBan.set_sensitive(widget.get_active())

class BloatFrame(settings_glade.BloatFrame):
	def __init__(self):
		settings_glade.BloatFrame.__init__(self, gtk.FALSE)
		self.DecimalSep.set_popdown_strings(["<None>", ",", ".", "<space>"])

		self.PickRemote.connect("clicked", self.PickColour, self.Remote)
		self.PickLocal.connect("clicked", self.PickColour, self.Local)
		self.PickMe.connect("clicked", self.PickColour, self.Me)
		self.PickHighlight.connect("clicked", self.PickColour, self.Highlight)
		self.PickImmediate.connect("clicked", self.PickColour, self.Immediate)
		self.PickQueue.connect("clicked", self.PickColour, self.Queue)

		self.DefaultRemote.connect("clicked", self.DefaultColour, self.Remote)
		self.DefaultLocal.connect("clicked", self.DefaultColour, self.Local)
		self.DefaultMe.connect("clicked", self.DefaultColour, self.Me)
		self.DefaultHighlight.connect("clicked", self.DefaultColour, self.Highlight)
		self.DefaultImmediate.connect("clicked", self.DefaultColour, self.Immediate)
		self.DefaultQueue.connect("clicked", self.DefaultColour, self.Queue)
		
	def SetSettings(self, config):
		ui = config["ui"]
		transfers = config["transfers"]
		if ui["chatlocal"] is not None:
			self.Local.set_text(ui["chatlocal"])
		if ui["chatremote"] is not None:
			self.Remote.set_text(ui["chatremote"])
		if ui["chatme"] is not None:
			self.Me.set_text(ui["chatme"])
		if ui["chathilite"] is not None:
			self.Highlight.set_text(ui["chathilite"])
		if ui["search"] is not None:
			self.Immediate.set_text(ui["search"])
		if ui["searchq"] is not None:
			self.Queue.set_text(ui["searchq"])
		if ui["decimalsep"] is not None:
			self.DecimalSep.entry.set_text(ui["decimalsep"])

	def GetSettings(self):
		return {
			"ui": {
				"chatlocal": self.Local.get_text(),
				"chatremote": self.Remote.get_text(),
				"chatme": self.Me.get_text(),
				"chathilite": self.Highlight.get_text(),
				"search": self.Immediate.get_text(),
				"searchq": self.Queue.get_text(),
				"decimalsep": self.DecimalSep.entry.get_text(),
			},
		}
	
	def PickColour(self, widget, entry):
		dlg = gtk.ColorSelectionDialog("Pick a colour, any colour")
		colour = gtk.gdk.color_parse(entry.get_text())
		dlg.colorsel.set_current_color(colour)
		if dlg.run() == gtk.RESPONSE_OK:
			colour = dlg.colorsel.get_current_color()
			colour = "#%02X%02X%02X" % (colour.red / 256, colour.green / 256, colour.blue / 256)
			entry.set_text(colour)
		dlg.destroy()

	def DefaultColour(self, widget, entry):
		entry.set_text("")
			
class LogFrame(settings_glade.LogFrame):
	def __init__(self):
		settings_glade.LogFrame.__init__(self, gtk.FALSE)

	def SetSettings(self, config):
		logging = config["logging"]
		if logging["privatechat"] is not None:
			self.LogPrivate.set_active(logging["privatechat"])
		if logging["chatrooms"] is not None:
			self.LogRooms.set_active(logging["chatrooms"])
		if logging["logsdir"] is not None:
			self.LogDir.set_text(recode(logging["logsdir"]))

	def GetSettings(self):
		return {
			"logging": {
				"privatechat": self.LogPrivate.get_active(),
				"chatrooms": self.LogRooms.get_active(),
				"logsdir": recode2(self.LogDir.get_text()),
			}
		}

	def OnChooseLogDir(self, widget):
		dir = ChooseDir(self.Main.get_toplevel(), self.LogDir.get_text())
		if dir is not None:
			self.LogDir.set_text(recode(dir))

class SearchFrame(settings_glade.SearchFrame):
	def __init__(self):
		settings_glade.SearchFrame.__init__(self, gtk.FALSE)

	def SetSettings(self, config):
		try:
			searches = config["searches"]
		except:
			searches = None
		
		if searches["maxresults"] is not None:
			self.MaxResults.set_text(str(searches["maxresults"]))
		if searches["enablefilters"] is not None:
			self.EnableFilters.set_active(searches["enablefilters"])
		if searches["re_filter"] is not None:
			self.RegexpFilters.set_active(searches["re_filter"])
		if searches["defilter"] is not None:
			self.FilterIn.set_text(searches["defilter"][0])
			self.FilterOut.set_text(searches["defilter"][1])
			self.FilterSize.set_text(searches["defilter"][2])
			self.FilterBR.set_text(searches["defilter"][3])
			self.FilterFree.set_active(searches["defilter"][4])

	def GetSettings(self):
		maxresults = int(self.MaxResults.get_text())
		return {
			"searches": {
				"maxresults": maxresults,
				"enablefilters": self.EnableFilters.get_active(),
				"re_filter": self.RegexpFilters.get_active(),
				"defilter": [
					self.FilterIn.get_text(),
					self.FilterOut.get_text(),
					self.FilterSize.get_text(),
					self.FilterBR.get_text(),
					self.FilterFree.get_active(),
				],
			}
		}

	def OnEnableFiltersToggled(self, widget):
		active = widget.get_active()
		for w in self.FilterIn, self.FilterOut, self.FilterSize, self.FilterBR, self.FilterFree:
			w.set_sensitive(active)

class AwayFrame(settings_glade.AwayFrame):
	def __init__(self):
		settings_glade.AwayFrame.__init__(self, gtk.FALSE)
	
	def SetSettings(self, config):		
		server = config["server"]
		if server["autoreply"] is not None:
			self.AutoReply.set_text(server["autoreply"])
		if server["autoaway"] is not None:
			self.AutoAway.set_text(str(server["autoaway"]))

	def GetSettings(self):
		try:
			autoaway = int(self.AutoAway.get_text())
		except:
			autoaway = None
		return {
			"server": {
				"autoaway": autoaway,
				"autoreply": self.AutoReply.get_text(),
			}
		}

class EventsFrame(settings_glade.EventsFrame):
	def __init__(self):
		settings_glade.EventsFrame.__init__(self, gtk.FALSE)
	
	def SetSettings(self, config):
		transfers = config["transfers"]
		if transfers["afterfinish"] is not None:
			self.AfterDownload.set_text(transfers["afterfinish"])
		if transfers["afterfolder"] is not None:
			self.AfterFolder.set_text(transfers["afterfolder"])

	def GetSettings(self):
		return {
			"transfers": {
				"afterfinish": self.AfterDownload.get_text(),
				"afterfolder": self.AfterFolder.get_text(),
			}
		}

class UrlCatchFrame(settings_glade.UrlCatchFrame):
	def __init__(self):
		settings_glade.UrlCatchFrame.__init__(self, gtk.FALSE)
		self.protocolmodel = gtk.ListStore(gobject.TYPE_STRING, gobject.TYPE_STRING)
		self.protocols = {}
		cols = InitialiseColumns(self.ProtocolHandlers,
			["Protocol", -1, "text"],
			["Handler", -1, "text"],
		)
		self.ProtocolHandlers.set_model(self.protocolmodel)
		self.ProtocolHandlers.get_selection().connect("changed", self.OnSelect)

	def SetSettings(self, config):
		self.protocolmodel.clear()
		self.protocols = {}
		urls = config["urls"]
		if urls["urlcatching"] is not None:
			self.URLCatching.set_active(urls["urlcatching"])
		if urls["humanizeurls"] is not None:
			self.HumanizeURLs.set_active(urls["humanizeurls"])
		if urls["protocols"] is not None:
			for key in urls["protocols"].keys():
				iter = self.protocolmodel.append([key, urls["protocols"][key]])
				self.protocols[key] = [iter, urls["protocols"][key]]

		self.OnURLCatchingToggled(self.URLCatching)

	def GetSettings(self):
		protocols = {}
		for key in self.protocols.keys():
			protocols[key] = self.protocols[key][1]
		return {
			"urls": {
				"urlcatching": self.URLCatching.get_active(),
				"humanizeurls": self.HumanizeURLs.get_active(),
				"protocols": protocols,
			}
		}

	def OnURLCatchingToggled(self, widget):
		self.HumanizeURLs.set_active(widget.get_active())

	def OnSelect(self, selection):
		model, iter = selection.get_selected()
		if iter == None:
			self.Protocol.set_text("")
		else:
			protocol = model.get_value(iter, 0)
			handler = model.get_value(iter, 1)
			self.Protocol.set_text(protocol)
			self.Handler.set_text(handler)

	def OnUpdate(self, widget):
		key = self.Protocol.get_text()
		value = self.Handler.get_text()
		if self.protocols.has_key(key):
			self.protocols[key][1] = value
			self.protocolmodel.set(self.protocols[key][0], 1, value)
		else:
			iter = self.protocolmodel.append([key, value])
			self.protocols[key] = [iter, value]

	def OnRemove(self, widget):
		key = self.Protocol.get_text()
		if not self.protocols.has_key(key):
			return
		self.protocolmodel.remove(self.protocols[key][0])
		del self.protocols[key]

class SettingsWindow(settings_glade.SettingsWindow):
	def __init__(self, frame):
		settings_glade.SettingsWindow.__init__(self)

		gobject.signal_new("settings-closed", gtk.Window, gobject.SIGNAL_RUN_LAST, gobject.TYPE_NONE, (gobject.TYPE_STRING,))
		
		self.SettingsWindow.set_transient_for(frame.MainWindow)

		self.SettingsWindow.connect("delete-event", self.OnDelete)
		
		self.empty_label = gtk.Label("")
		self.empty_label.show()
		self.viewport1.add(self.empty_label)
		
		self.pages = p = {}
		model = gtk.TreeStore(gobject.TYPE_STRING)

		row = model.append(None, ["Connection"])
		model.append(row, ["Server"])
		model.append(row, ["Shares"])
		model.append(row, ["Transfers"])
		try:
			import GeoIP
			model.append(row, ["Geo Block"])
		except ImportError:
			try:
				import _GeoIP
				model.append(row, ["Geo Block"])
			except ImportError:
				pass

		row = model.append(None, ["UI"])
		model.append(row, ["Interface"])
		model.append(row, ["URL Catching"])
		
		row = model.append(None, ["Misc"])
		model.append(row, ["Away mode"])
		model.append(row, ["User info"])
		model.append(row, ["Ban / ignore"])
		model.append(row, ["Logging"])
		model.append(row, ["Searches"])
		model.append(row, ["Events"])
		
		p["Server"] = ServerFrame(frame.np.getencodings())
		p["Shares"] = SharesFrame()
		p["Transfers"] = TransfersFrame()
		p["Geo Block"] = GeoBlockFrame()
		p["User info"] = UserinfoFrame()
		p["Ban / ignore"] = BanFrame()
		p["Interface"] = BloatFrame()
		p["URL Catching"] = UrlCatchFrame()
		p["Logging"] = LogFrame()
		p["Searches"] = SearchFrame()
		p["Away mode"] = AwayFrame()
		p["Events"] = EventsFrame()
		
		column = gtk.TreeViewColumn("Categories", gtk.CellRendererText(), text = 0)

		self.SettingsTreeview.set_model(model)
		self.SettingsTreeview.append_column(column)

		self.SettingsTreeview.expand_row((0,), gtk.TRUE)
		self.SettingsTreeview.expand_row((1,), gtk.TRUE)
		self.SettingsTreeview.expand_row((2,), gtk.TRUE)

		self.SettingsTreeview.get_selection().connect("changed", self.switch_page)
	
	def switch_page(self, widget):
		child = self.viewport1.get_child()
		if child:
			self.viewport1.remove(child)
		model, iter = widget.get_selected()
		if iter is None:
			self.viewport1.add(self.empty_label)
			return
		page = model.get_value(iter, 0)
		if self.pages.has_key(page):
			self.viewport1.add(self.pages[page].Main)
		else:
			self.viewport1.add(self.empty_label)

	def OnApply(self, widget):
		self.SettingsWindow.emit("settings-closed", "apply")

	def OnOk(self, widget):
		self.SettingsWindow.hide()
		self.SettingsWindow.emit("settings-closed", "ok")

	def OnCancel(self, widget):
		self.SettingsWindow.hide()
		self.SettingsWindow.emit("settings-closed", "cancel")
		
	def OnDelete(self, widget, event):
		self.OnCancel(widget)
		widget.emit_stop_by_name("delete-event")
		return gtk.TRUE

	def SetSettings(self, config):
		for page in self.pages.values():
			page.SetSettings(config)

	def GetSettings(self):
		config = {
			"server": {},
			"transfers": {},
			"userinfo": {},
			"logging": {},
			"searches": {},
			"ui": {},
			"urls": {},
		}
		
		for page in self.pages.values():
			sub = page.GetSettings()
			for (key,data) in sub.items():
				config[key].update(data)
		return self.pages["Shares"].GetNeedRescan(), config
