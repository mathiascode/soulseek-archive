# Copyright (c) 2001-2002 Alexander Kanavin. All rights reserved.

"""
This module contains utility fuctions.
"""

import string
import os.path
import os,stat
import mp3

def getServerList(url):
        """ Parse server text file from http://www.slsk.org and 
        return a list of servers """
        import urllib,string
        try:
            f = urllib.urlopen(url)
            list = [string.strip(i) for i in f.readlines()]
        except:
            return []
        try:
            list = list[list.index("--servers")+1:]
        except:
            return []
        list = [string.split(i,":",2) for i in list]
        try:
            return [[i[0],i[2]]  for i in list]
        except:
            return []

def getFilesList(dirs):
    """ Get a list of files in dirs and subdirs with their filelength and 
    (if mp3) bitrate and track length in seconds """
    list = {}
    for i in dirs:
        dircontents = getDirContents(i)
        for j in dircontents.keys():
             list[j] = dircontents[j]
    return list

def getDirContents(dir):
    """ Same as getFilesList, but only for one dir """
    dir = dir.replace("//","/")
    list = {dir:[]}
    for f in os.listdir(dir):
        pathname = os.path.join(dir, f)
        mode = os.stat(pathname)[stat.ST_MODE]
        if stat.S_ISDIR(mode):
            # It's a directory, recurse into it
            dircontents = getDirContents(pathname)
            for j in dircontents.keys():
                list[j] = dircontents[j]
        elif stat.S_ISREG(mode):
            # It's a file, check if it is mp3
            size = os.stat(pathname)[stat.ST_SIZE]
            mp3info=mp3.detect_mp3(pathname)
            if mp3info:
                fileinfo = [f,size,mp3info["bitrate"],mp3info["time"]]
            else:
                fileinfo = [f,size,None,None]
            fileinfo.append(getByteStream(fileinfo))
            list[dir].append(fileinfo)
    return list

def getByteStream(fileinfo):
    from slskmessages import SlskMessage
    self = SlskMessage()
    stream = chr(1) + self.packObject(fileinfo[0]) + self.packObject(fileinfo[1]) + self.packObject(0)
    if fileinfo[2] is not None:
        stream = stream + self.packObject('mp3') + self.packObject(3)
        stream = stream + self.packObject(0)+ self.packObject(fileinfo[2])+self.packObject(1)+ self.packObject(fileinfo[3])+self.packObject(2)+self.packObject(0)
    else:
        stream = stream + self.packObject('') + self.packObject(0)
    return stream

