# Copyright (c) 2001-2002 Alexander Kanavin. All rights reserved.

"""
This is the client code for the notebook with bird icons.
"""

from wxPython.wx import *
import images

class IconNotebook(wxNotebook):
    def __init__(self, parent, id, style = None): 
        wxNotebook.__init__(self,parent,id, style = style)
        
	EVT_NOTEBOOK_PAGE_CHANGED(self,self.GetId(),self.OnPageChanged)

        self.imglist = wxImageList(18,18)
        self.offline = self.imglist.Add(images.getOnlineBitmap())
        self.AssignImageList(self.imglist)
	self.pages = []
	self.page = 0

    def OnPageChanged(self, event):
	self.page = event.GetSelection()
	self.SetPageImage(self.page,-1)

    def AddPage(self, page, title):
	wxNotebook.AddPage(self, page, title)
	self.pages.append(page)

    def DeleteAllPages(self):
	wxNotebook.DeleteAllPages(self)
	self.pages = []
	self.page = 0

    def DeletePage(self, index):
	wxNotebook.DeletePage(self, index)
	del self.pages[index]
	self.page = self.GetSelection()
	if index <= self.GetSelection():
	    self.page = self.page - 1
	
    def OnPageUpdated(self, pageobj):
	if self.pages[self.page] != pageobj:
	    self.SetPageImage(self.pages.index(pageobj),0)

