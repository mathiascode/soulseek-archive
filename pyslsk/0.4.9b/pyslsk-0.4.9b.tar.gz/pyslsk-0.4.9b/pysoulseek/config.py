# Copyright (c) 2001-2002 Alexander Kanavin. All rights reserved.

"""
This module contains configuration classes for pyslsk.
"""

import ConfigParser
import string
import os.path

class Config:
    """ 
    This class holds configuration information and provides the 
    following methods:

    needConfig() - returns true if configuration information is incomplete
    readConfig() - reads configuration information from ~/.pyslsk
    setConfig(config_info_dict) - sets configuration information
    writeConfig - writes configuration information to ~/.pyslsk

    The actual configuration information is stored as a two-level dictionary.
    First-level keys are config sections, second-level keys are config 
    parameters.
    """
    def __init__(self, filename = os.path.join(os.path.expanduser("~"),'.pyslsk')):
        self.filename = filename
	self.parser = ConfigParser.ConfigParser()
	self.parser.read([self.filename])
	self.sections = {"server":{"server":None,"login":None,"passw":None,"enc":"ascii","userlist":[],"autojoin":["pyslsk"]},"transfers":{"downloaddir":None,"sharedownloaddir":1,"shared":None,"uploadbandwidth":100,"downloads":[],"sharedfiles":{}},"userinfo":{"descr":"''","pic":""}}

    def needConfig(self):
	for i in self.sections.keys():
	    for j in self.sections[i].keys():
		if self.sections[i][j] is None or self.sections[i][j] == '' and i != "userinfo":
		    return 1
	return 0

    def readConfig(self):
	for i in self.parser.sections():
	    for j in self.parser.options(i):
		val = self.parser.get(i,j, raw = 1)
		if j == 'server' or j == 'shared' or j == 'uploadbandwidth' or j == 'downloads' or j == 'sharedfiles' or j == 'sharedownloaddir' or j == 'userlist' or j == 'autojoin':
		    try:
		        self.sections[i][j] = eval(val)
		    except:
			self.sections[i][j] = None
			raise
		else:
		    self.sections[i][j] = val
 
    def setConfig(self, sections):
	for i in sections.keys():
	    if not self.parser.has_section(i):
	 	self.parser.add_section(i)
	    if not self.sections.has_key(i):
		self.sections[i] = sections[i]
	    for j in sections[i].keys():
		self.parser.set(i,j,sections[i][j])
		self.sections[i][j] = sections[i][j]

    def writeConfig(self):
	f = open(self.filename,"w")
	self.parser.write(f)
	f.close()


