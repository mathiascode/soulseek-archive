# Copyright (c) 2001-2002 Alexander Kanavin. All rights reserved.

"""
This is the actual client code. Actual GUI classes are in the separate modules
"""

import time
import slskproto
import slskmessages
from slskmessages import newId
import transfers
import Queue
import threading
from config import *
import threading

class PeerConnection:
    """
    Holds information about a peer connection. Not every field may be set
    to something. addr is (ip,port) address, conn is a socket object, msgs is
    a list of outgoing pending messages, token is a reverse-handshake 
    number (protocol feature), init is a PeerInit protocol message. (read
    slskmessages docstrings for explanation of these)
    """
    def __init__(self, addr = None, username = None, conn = None, msgs = None, token = None, init = None, conntimer = None):
	self.addr = addr
	self.username = username
	self.conn = conn
	self.msgs = msgs
	self.token = token
	self.init = init
	self.conntimer = conntimer

class ConnectToPeerTimeout:
    def __init__(self, conn, callback):
	self.conn = conn
	self.callback = callback

    def timeout(self):
	self.callback([self])

class NetworkEventProcessor:
    """ This class contains handlers for various messages from the networking
    thread"""
    def __init__(self,frame,callback, writelog, setstatus, configfile):
	self.frame=frame
	self.callback = callback
	self.logMessage = writelog
	self.setStatus = setstatus

        self.config = Config(configfile)
        self.config.readConfig()

        self.queue = Queue.Queue(0)
        self.protothread = slskproto.SlskProtoThread(callback,self.queue)
        self.serverconn = None
        self.waitport = None
        self.peerconns = []
        self.users = {}
        self.chatrooms = None
        self.privatechat = None
        self.globallist = None
        self.userinfo = None
        self.userbrowse = None
        self.search = None
        self.transfers = None

	self.servertimer = None
	self.servertimeout = -1

        self.events = {slskmessages.ConnectError:self.ConnectError,
		       slskmessages.IncPort:self.IncPort,
		       slskmessages.ServerConn:self.ServerConn,
		       slskmessages.ConnClose:self.ConnClose,
		       slskmessages.Login:self.Login,
		       slskmessages.MessageUser:self.MessageUser,
		       slskmessages.FileSearch:self.FileSearch,
			slskmessages.ExactFileSearch:self.ExactFileSearch,
		       slskmessages.UserJoinedRoom:self.UserJoinedRoom,
		       slskmessages.SayChatroom:self.SayChatRoom,
		       slskmessages.JoinRoom:self.JoinRoom,
		       slskmessages.UserLeftRoom:self.UserLeftRoom,
		       slskmessages.QueuedDownloads:self.QueuedDownloads,
		       slskmessages.GetPeerAddress:self.GetPeerAddress,
		       slskmessages.OutConn:self.OutConn,
		       slskmessages.UserInfoReply:self.UserInfoReply,
			slskmessages.UserInfoRequest:self.UserInfoRequest,
		       slskmessages.PierceFireWall:self.PierceFireWall,
		       slskmessages.CantConnectToPeer:self.CantConnectToPeer,
		       slskmessages.PeerTransfer:self.PeerTransfer,
		       slskmessages.SharedFileList:self.SharedFileList,
			slskmessages.GetSharedFileList:self.GetSharedFileList,
		       slskmessages.FileSearchResult:self.FileSearchResult,
		       slskmessages.ConnectToPeer:self.ConnectToPeer,
		       slskmessages.GetUserStatus:self.GetUserStatus,
		       slskmessages.GetUserStats:self.GetUserStats,
		       slskmessages.PeerInit:self.PeerInit,
		       slskmessages.DownloadFile:self.FileDownload,
			slskmessages.UploadFile:self.FileUpload,
			slskmessages.FileRequest:self.FileRequest,
			slskmessages.TransferRequest:self.TransferRequest,
			slskmessages.TransferResponse:self.TransferResponse,
			slskmessages.QueueUpload:self.QueueUpload,
			slskmessages.UploadFailed:self.UploadFailed,
			slskmessages.PlaceInQueue:self.PlaceInQueue,
		        slskmessages.FileError:self.FileError,
			slskmessages.FolderContentsResponse:self.FolderContentsResponse,
			slskmessages.RoomList:self.RoomList,
			slskmessages.LeaveRoom:self.LeaveRoom,
			slskmessages.GlobalUserList:self.GlobalUserList,
			slskmessages.AddUser:self.AddUser,
			slskmessages.PrivilegedUsers:self.PrivilegedUsers,
			slskmessages.AddToPrivileged:self.AddToPrivileged,
			slskmessages.CheckPrivileges:self.CheckPrivileges,
			slskmessages.TunneledMessage:self.TunneledMessage,
			slskmessages.IncConn:self.IncConn,
			slskmessages.PlaceholdUpload:self.PlaceholdUpload,
			ConnectToPeerTimeout:self.ConnectToPeerTimeout,
			}


    def ProcessRequestToPeer(self, user, message, window = None):
        """ 
        Sends message to a peer and possibly sets up a window to display 
        the result.
        """

        conn = None
        for i in self.peerconns:
            if i.username == user and i.init.type == 'P' and message.__class__ is not slskmessages.FileRequest:
                conn = i
                break
        if conn is not None:
            if conn.conn is not None:
                message.conn = conn.conn
                self.queue.put(message)
                if window is not None:
                    window.InitWindow(conn.username,conn.conn)
            else:
                conn.msgs.append(message)
        else:
            if message.__class__ is slskmessages.FileRequest:
                type = 'F'
            else:
                type = 'P'
            init = slskmessages.PeerInit(None,self.config.sections["server"]["login"],type,300)
            if self.users.has_key(user):
                addr = self.users[user].addr
                behindfw = self.users[user].behindfw
            else:
                addr = None
                behindfw = None
            token = None
            if addr is None:
                self.queue.put(slskmessages.GetPeerAddress(user))
            elif behindfw is None:
                self.queue.put(slskmessages.OutConn(None,addr))
            else:
                token = newId()
                self.queue.put(slskmessages.ConnectToPeer(token,user,type))

            self.peerconns.append(PeerConnection(addr = addr, username = user, msgs = [message], token = token, init = init))
	    if token is not None:
		conntimeout = ConnectToPeerTimeout(self.peerconns[-1],self.frame.callback)
		timer = threading.Timer(300.0, conntimeout.timeout)
		self.peerconns[-1].conntimer = timer
		timer.start()

    def setServerTimer(self):
	if self.serverconn is not None:
            if self.servertimeout == -1:
                self.servertimeout = 15
        elif 0 < self.servertimeout < 3600:
            self.servertimeout = self.servertimeout * 2
        if self.servertimeout > 0:
            self.servertimer = threading.Timer(self.servertimeout, self.ServerTimeout)
	    self.servertimer.start()
            self.logMessage("Retrying connection in %i seconds" %(self.servertimeout))

    def ServerTimeout(self):
        if not self.config.needConfig():
            self.frame.OnConnect(None)

    def encodestring(self,str):
	import locale
	try:
	    localenc = locale.nl_langinfo(locale.CODESET)
	    return str.decode(localenc,'replace').encode(self.config.sections["server"]["enc"],'replace')
	except:
	    return str

    def decodestring(self,str):
	import locale
	try:
	    localenc = locale.nl_langinfo(locale.CODESET)
	    return str.decode(self.config.sections["server"]["enc"],'replace').encode(localenc,'replace')
	except:
            return str

    def getencodings(self):
	return ['ascii', 'cp037', 'cp1006', 'cp1026', 'cp1140', 'cp1250', 'cp1251', 'cp1252', 'cp1253', 'cp1254', 'cp1255', 'cp1256', 'cp1257', 'cp1258', 'cp424', 'cp437', 'cp500', 'cp737', 'cp775', 'cp850', 'cp852', 'cp855', 'cp856', 'cp857', 'cp860', 'cp861', 'cp862', 'cp863', 'cp864', 'cp865', 'cp866', 'cp869', 'cp874', 'cp875', 'iso8859-1', 'iso8859-10', 'iso8859-13', 'iso8859-14', 'iso8859-15', 'iso8859-2', 'iso8859-3', 'iso8859-4', 'iso8859-5', 'iso8859-6', 'iso8859-7', 'iso8859-8', 'iso8859-9', 'koi8-r', 'latin-1', 'mac-cyrillic', 'mac-greek', 'mac-iceland', 'mac-latin2', 'mac-roman', 'mac-turkish', 'utf-16', 'utf-7', 'utf-8']

    def sendNumSharedFoldersFiles(self):
	conf = self.config.sections
        sharedfolders = len(conf["transfers"]["sharedfiles"].keys())
        sharedfiles = 0
        for i in conf["transfers"]["sharedfiles"].keys():
            sharedfiles = sharedfiles + len(conf["transfers"]["sharedfiles"][i])
        self.queue.put(slskmessages.SharedFoldersFiles(sharedfolders,sharedfiles))


    def ConnectError(self,msg):
	if msg.connobj.__class__ is slskmessages.ServerConn:
	    self.setStatus("Can't connect to server %s:%s: %s" % (msg.connobj.addr[0],msg.connobj.addr[1],msg.err))
	    self.setServerTimer()
	    if self.serverconn is not None:
	        self.serverconn = None
	    self.frame.ConnectError(msg)
	elif msg.connobj.__class__ is slskmessages.OutConn:
            for i in self.peerconns[:]:
                if i.addr == msg.connobj.addr and i.conn is None: 
		    if i.token is None:
		        i.token  = newId()
		        self.queue.put(slskmessages.ConnectToPeer(i.token,i.username,i.init.type))
		        self.users[i.username].behindfw = "yes"
	                for j in i.msgs: 
	                    if j.__class__ is slskmessages.TransferRequest:
			       self.transfers.gotConnectError(j.req)
                	conntimeout = ConnectToPeerTimeout(i,self.frame.callback)
                	timer = threading.Timer(300.0, conntimeout.timeout)
			timer.start()
                	i.conntimer = timer
		    elif len(i.msgs)==0:
			self.logMessage("Can't connect to %s, sending notification via the server" %(i.username))
			self.queue.put(slskmessages.CantConnectToPeer(i.token,i.username))
			self.peerconns.remove(i)
			
	else:
	    self.logMessage("%s %s %s" %(msg.err, msg.__class__, vars(msg)),1)

    def IncPort(self, msg):
        self.waitport = msg.port
	self.setStatus("Listening on port %i" %(msg.port))

    def ServerConn(self, msg):
	self.setStatus("Connected to server %s:%s, logging in..." %(msg.addr[0],msg.addr[1]))
	self.serverconn = msg.conn
	self.servertimeout = -1
        self.queue.put(slskmessages.Login(self.config.sections["server"]["login"],self.config.sections["server"]["passw"],200))
        if self.waitport is not None:	
	    self.queue.put(slskmessages.SetWaitPort(self.waitport))

    def PeerInit(self, msg):
	list = [i for i in self.peerconns if i.conn == msg.conn.conn]
	if list == []:
	    self.peerconns.append(PeerConnection(addr = msg.conn.addr, username = msg.user, conn = msg.conn.conn, init = msg, msgs = []))
	else:
	    for i in list:
		i.init = msg
		i.username = msg.user

    def ConnClose(self, msg):
	if msg.conn == self.serverconn:
	    self.setStatus("Disconnected from server %s:%s" %(msg.addr[0],msg.addr[1]))
	    if not self.frame.manualdisconnect:
		self.setServerTimer()
	    else:
		self.frame.manualdisconnect = 0
	    self.serverconn = None
	    self.frame.ConnClose(msg)
	    if self.transfers is not None:
		self.transfers.AbortTransfers()
	        self.config.sections["transfers"]["downloads"] = self.transfers.GetDownloads()
	    self.config.sections["server"]["userlist"] = [i[0] for i in self.frame.userlist]
	    self.privatechat = self.chatrooms = self.userinfo = self.userbrowse = self.search = self.transfers = None
        else:
	    for i in self.peerconns[:]:
	        if i.conn == msg.conn:
		    self.logMessage("Connection closed by peer: %s" %(vars(i)),1)
		    self.peerconns.remove(i)
		    if self.transfers is not None:
			self.transfers.ConnClose(msg)
	
    def Login(self,msg):
	conf = self.config.sections
	if msg.success:
	    self.setStatus("Logged in, getting the list of rooms...")
	    self.transfers = transfers.Transfers(conf["transfers"]["shared"],conf["transfers"]["downloaddir"],conf["transfers"]["uploadbandwidth"],conf["transfers"]["downloads"],self.peerconns,self.queue, self, self.users)

	    self.privatechat, self.chatrooms, self.userinfo, self.userbrowse, self.search, downloads, uploads = self.frame.InitInterface(msg)
	    self.frame.InitUserList(conf["server"]["userlist"])

	    self.transfers.setTransferPanels(downloads, uploads)
	    self.sendNumSharedFoldersFiles()
	    self.queue.put(slskmessages.SetStatus((not self.frame.away)+1))
	else:
	    self.frame.manualdisconnect = 1
	    self.setStatus("Can not log in, reason: %s" %(msg.reason))
	    self.logMessage("Can not log in, reason: %s" %(msg.reason))


    def MessageUser(self, msg):
	if self.privatechat is not None:
	    self.privatechat.ShowMessage(msg,self.decodestring(msg.msg))
	    self.queue.put(slskmessages.MessageAcked(msg.msgid))
       	else:
            self.logMessage("%s %s" %(msg.__class__, vars(msg)))

    def UserJoinedRoom(self,msg):
	if self.chatrooms is not None:
	    self.chatrooms.roomsctrl.UserJoinedRoom(msg)
	else:
            self.logMessage("%s %s" %(msg.__class__, vars(msg)))


    def JoinRoom(self,msg):
	if self.chatrooms is not None:
            self.chatrooms.roomsctrl.JoinRoom(msg)
        else:
            self.logMessage("%s %s" %(msg.__class__, vars(msg)))

    def LeaveRoom(self,msg):
        if self.chatrooms is not None:
            self.chatrooms.roomsctrl.LeaveRoom(msg)
        else:
            self.logMessage("%s %s" %(msg.__class__, vars(msg)))


    def SayChatRoom(self,msg):
        if self.chatrooms is not None:
            self.chatrooms.roomsctrl.SayChatRoom(msg,self.decodestring(msg.msg))
        else:
            self.logMessage("%s %s" %(msg.__class__, vars(msg)))

    def AddUser(self,msg):
        if self.transfers is not None:
            self.transfers.getAddUser(msg)
        else:
            self.logMessage("%s %s" %(msg.__class__, vars(msg)))

    def PrivilegedUsers(self,msg):
        if self.transfers is not None:
            self.transfers.setPrivilegedUsers(msg.users)
	    self.logMessage("%i privileged users" %(len(msg.users)))
	    self.logMessage("If you like pyslsk, please consider sending a postcard to the author, here's the address:\nAlexander Kanavin\nRuskonlahdenkatu 13-15 C7\n53850 Lappeenranta Finland")
        else:
            self.logMessage("%s %s" %(msg.__class__, vars(msg)))

    def AddToPrivileged(self, msg):
	if self.transfers is not None:
            self.transfers.addToPrivileged(msg.user)
	    self.logMessage("User %s added to privileged list" %(msg.user),1)
        else:
            self.logMessage("%s %s" %(msg.__class__, vars(msg)))

    def CheckPrivileges(self, msg):
	self.logMessage("%i seconds of download privileges left" %(msg.days))

    def GetUserStatus(self,msg):
	self.queue.put(slskmessages.AddUser(msg.user))
	if msg.user in self.users.keys():
	    if msg.status == 0:
	        self.users[msg.user] = UserAddr(status = msg.status)
	    else:
	        self.users[msg.user].status = msg.status
	else:
	    self.users[msg.user] = UserAddr(status = msg.status)
	self.frame.GetUserStatus(msg)
	if self.transfers is not None:
	    self.transfers.GetUserStatus(msg)
	if self.privatechat is not None:
	    self.privatechat.GetUserStatus(msg)
	if self.chatrooms is not None:
            self.chatrooms.roomsctrl.GetUserStatus(msg)
        else:
            self.logMessage("%s %s" %(msg.__class__, vars(msg)))


    def GetUserStats(self,msg):
        if self.chatrooms is not None:
            self.chatrooms.roomsctrl.GetUserStats(msg)
        else:
            self.logMessage("%s %s" %(msg.__class__, vars(msg)))

    def UserLeftRoom(self,msg):
        if self.chatrooms is not None:
            self.chatrooms.roomsctrl.UserLeftRoom(msg)
        else:
            self.logMessage("%s %s" %(msg.__class__, vars(msg)))


    def QueuedDownloads(self,msg): 
	if self.chatrooms is not None:
	    self.chatrooms.roomsctrl.QueuedDownloads(msg) 
	else: 
	    self.logMessage("%s %s" %(msg.__class__, vars(msg)))

    def GetPeerAddress(self,msg):
	for i in self.peerconns:
	    if i.username == msg.user and i.addr is None:
		i.addr = (msg.ip, msg.port)
		self.queue.put(slskmessages.OutConn(None, i.addr))
		for j in i.msgs:
		    if j.__class__ is slskmessages.TransferRequest:
                        self.transfers.gotAddress(j.req)
		break
	self.logMessage("IP address of %s is %s, port %i" %(msg.user,msg.ip,msg.port))
	if msg.user not in self.users.keys():
	    self.users[msg.user] = UserAddr((msg.ip,msg.port))
	else:
	    self.users[msg.user].addr = (msg.ip,msg.port)

    def OutConn(self, msg):
	for i in self.peerconns:
	    if i.addr == msg.addr and i.conn is None:
		if i.token is None:
		    i.init.conn = msg.conn
		    self.queue.put(i.init)
		else:
		    self.queue.put(slskmessages.PierceFireWall(msg.conn, i.token))
		i.conn = msg.conn
		for j in i.msgs:
		    if j.__class__ is slskmessages.UserInfoRequest:
			self.userinfo.InitWindow(i.username,msg.conn)
		    if j.__class__ is slskmessages.GetSharedFileList:
			self.userbrowse.InitWindow(i.username,msg.conn)
		    if j.__class__ is slskmessages.TransferRequest:
			self.transfers.gotConnect(j.req,msg.conn)
		    j.conn = msg.conn
		    self.queue.put(j)
		i.msgs = []
		break
		
	self.logMessage("%s %s" %(msg.__class__, vars(msg)),1)

    def IncConn(self,msg):
	self.logMessage("%s %s" %(msg.__class__, vars(msg)),1)

    def ConnectToPeer(self, msg):
	init = slskmessages.PeerInit(None,msg.user,msg.type,300)
        self.queue.put(slskmessages.OutConn(None,(msg.ip,msg.port),init))
        self.peerconns.append(PeerConnection(addr = (msg.ip,msg.port), username = msg.user, msgs = [], token = msg.token, init = init))

        self.logMessage("%s %s" %(msg.__class__, vars(msg)),1)

    def GetSharedFileList(self,msg):
	self.queue.put(slskmessages.SharedFileList(msg.conn.conn,self.config.sections["transfers"]["sharedfilesstreams"]))
        self.logMessage("%s %s" %(msg.__class__, vars(msg)),1)


    def UserInfoReply(self,msg):
	for i in self.peerconns:
	    if i.conn is msg.conn.conn:
		self.userinfo.ShowInfo(i.username, msg)

    def UserInfoRequest(self, msg):
	try:
	    f=open(self.config.sections["userinfo"]["pic"],'r')
	    pic = f.read()
	    f.close()
	except:
	    pic = None
	descr = eval(self.config.sections["userinfo"]["descr"])
	totalupl = 1 #there's no such thing in pyslsk
	queuesize = self.transfers.getUploadQueueSize()
 	slotsavail = not self.transfers.bandwidthLimitReached()
	self.queue.put(slskmessages.UserInfoReply(msg.conn.conn,descr,pic,totalupl, queuesize,slotsavail))

	self.logMessage("%s %s" %(msg.__class__, vars(msg)),1)


    def SharedFileList(self, msg):
	for i in self.peerconns:
	    if i.conn is msg.conn.conn:
		self.userbrowse.ShowInfo(i.username, msg)

    def FileSearchResult(self, msg):
	for i in self.peerconns:
	    if i.conn is msg.conn.conn:
		self.search.ShowResult(msg, i.username)

    def PierceFireWall(self, msg):
	for i in self.peerconns:
	    if i.token == msg.token and i.conn is None:
		i.conntimer.cancel()
		i.init.conn = msg.conn.conn
                self.queue.put(i.init)
                i.conn = msg.conn.conn
                for j in i.msgs:
                    if j.__class__ is slskmessages.UserInfoRequest:
                        self.userinfo.InitWindow(i.username,msg.conn.conn)
                    if j.__class__ is slskmessages.GetSharedFileList:
                        self.userbrowse.InitWindow(i.username,msg.conn.conn)
		    if j.__class__ is slskmessages.FileRequest:
			self.transfers.gotConnect(j.req,msg.conn.conn)
                    j.conn = msg.conn.conn
                    self.queue.put(j)
                i.msgs = []
		break

        self.logMessage("%s %s" %(msg.__class__, vars(msg)),1)

    def CantConnectToPeer(self, msg):
	for i in self.peerconns[:]:
	    if i.token == msg.token:
		self.peerconns.remove(i)
	        self.logMessage("Can't connect to %s (either way), giving up" % (i.username))
                for j in i.msgs: 
                    if j.__class__ is slskmessages.TransferRequest:
                        self.transfers.gotCantConnect(j.req)

    def ConnectToPeerTimeout(self,msg):
	for i in self.peerconns[:]:
            if i == msg.conn:
                self.peerconns.remove(i)
                self.logMessage("User %s does not respond to connect request, giving up" % (i.username))
                for j in i.msgs:
                    if j.__class__ is slskmessages.TransferRequest:
                        self.transfers.gotCantConnect(j.req)

    def FileDownload(self,msg):
        if self.transfers is not None:
            self.transfers.FileDownload(msg)
        else:
            self.logMessage("%s %s" %(msg.__class__, vars(msg)))

    def FileUpload(self,msg):
        if self.transfers is not None:
            self.transfers.FileUpload(msg)
        else:
            self.logMessage("%s %s" %(msg.__class__, vars(msg)))


    def FileRequest(self,msg):
        if self.transfers is not None:
            self.transfers.FileRequest(msg)
        else:
            self.logMessage("%s %s" %(msg.__class__, vars(msg)))

    def FileError(self,msg):
        if self.transfers is not None:
            self.transfers.FileError(msg)
        else:
            self.logMessage("%s %s" %(msg.__class__, vars(msg)))

    def TransferRequest(self,msg):
        if self.transfers is not None:
            self.transfers.TransferRequest(msg)
        else:
            self.logMessage("%s %s" %(msg.__class__, vars(msg)))

    def TransferResponse(self,msg):
        if self.transfers is not None:
            self.transfers.TransferResponse(msg)
        else:
            self.logMessage("%s %s" %(msg.__class__, vars(msg)))


    def QueueUpload(self,msg):
        if self.transfers is not None:
            self.transfers.QueueUpload(msg)
        else:
            self.logMessage("%s %s" %(msg.__class__, vars(msg)))

    def PlaceholdUpload(self,msg):
	self.logMessage("%s %s" %(msg.__class__, vars(msg)),1)

    def UploadFailed(self,msg):
        if self.transfers is not None:
            self.transfers.UploadFailed(msg)
        else:
            self.logMessage("%s %s" %(msg.__class__, vars(msg)))


    def PlaceInQueue(self,msg):
        if self.transfers is not None:
            self.transfers.PlaceInQueue(msg)
        else:
            self.logMessage("%s %s" %(msg.__class__, vars(msg)))

    def FolderContentsResponse(self,msg):
        if self.transfers is not None:
            self.transfers.FolderContentsResponse(msg)
        else:
            self.logMessage("%s %s" %(msg.__class__, vars(msg)))

    def RoomList(self,msg):
	if self.chatrooms is not None:
	     self.chatrooms.roomsctrl.SetRoomList(msg)
	     self.setStatus("")
	else:
            self.logMessage("%s %s" %(msg.__class__, vars(msg)))

    def GlobalUserList(self,msg):
        if self.globallist is not None:
             self.globallist.setGlobalUsersList(msg)
        else:
            self.logMessage("%s %s" %(msg.__class__, vars(msg)))

    def PeerTransfer(self,msg):
	if self.userinfo is not None:
	    self.userinfo.UpdateGauge(msg)
	if self.userbrowse is not None:
	    self.userbrowse.UpdateGauge(msg)

    def TunneledMessage(self, msg):
	if msg.code in self.protothread.peerclasses.keys():
	    peermsg = self.protothread.peerclasses[msg.code](None)

  	    peermsg.parseNetworkMessage(msg.msg)
	    peermsg.tunneleduser = msg.user
	    peermsg.tunneledreq = msg.req
	    peermsg.tunneledaddr = msg.addr
	    self.callback([peermsg])
	else:
	    self.logMessage("Unknown tunneled message: %s" %(vars(msg)))

    def ExactFileSearch(self,msg):
	pass
	
    def FileSearch(self, msg):
	pass #alright, alright, they take too much space in log window and i kinda don't know where to stick them, and server-side p2p is not yet done anyway

class UserAddr:
    def __init__(self, addr = None, behindfw = None, status = None):
	self.addr = addr
	self.behindfw = behindfw
	self.status = status



