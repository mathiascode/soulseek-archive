# Copyright (c) 2001-2003 Alexander Kanavin. All rights reserved.

"""
This module provides an About dialog box
"""

from wxPython.wx import *
import images
from pysoulseek.utils import version


class About(wxDialog):
    def __init__(self, parent, id, title):

        wxDialog.__init__(self,parent,id,title)

	sizer = wxStaticBoxSizer(wxStaticBox(self,-1,""),wxHORIZONTAL)

	mainsizer = wxBoxSizer(wxVERTICAL)

	img = images.getBirdBitmap()
        ok = wxButton(self, wxID_OK, "OK")
        ok.SetDefault()

	sizer.Add(wxStaticBitmap(self,-1,img,size=wxSize(img.GetWidth(), img.GetHeight())), flag=wxALL, border = 5)
	sizer.Add(wxStaticText(self,-1,"PySoulSeek "+version+"\nCopyright (c) 2001-2003 by Alexander Kanavin\nhttp://www.sensi.org/~ak/\nak@sensi.org\n\nModified by Hyriand\nhttp://thegraveyard.org/pyslsk/\nhyriand@thegraveyard.org\n\nReleased under the GNU general public license\n\nSee MAINTAINERS file for the list of contributors",style=wxALIGN_CENTRE), flag = wxALL, border = 5)

	mainsizer.Add(sizer, flag=wxALL,border = 5)
	mainsizer.Add(ok, flag = wxALL|wxALIGN_CENTER,border = 10)
        self.SetSizer(mainsizer)
        self.SetAutoLayout(True)
        mainsizer.Fit(self)

class AboutCommands(wxDialog):
    def __init__(self, parent, id, title, private = False):

        wxDialog.__init__(self,parent,id,title)

	sizer = wxStaticBoxSizer(wxStaticBox(self,-1,""),wxVERTICAL)

	mainsizer = wxBoxSizer(wxVERTICAL)

        ok = wxButton(self, wxID_OK, "OK")
        ok.SetDefault()

	if private:
	    pvs = "private chat sessions"
	else:
	    pvs = "chat rooms"
	sizer.Add(wxStaticText(self, -1, "Commands available in %s:"%pvs), flag=wxALL|wxALIGN_CENTER, border=5)
	if not private:
	    help = [ \
	        "/join /j channel", "Join channel 'channel'",
	        "/leave /l [channel]", "Leave channel 'channel'",
	        "/part /p [channel]", "Leave channel 'channel'",
		"/clear /c", "Clear the chat window",
	        "", "",
	        "/add /ad user", "Add user 'user' to your user list",
	        "/browse /b user", "Browse files of user 'user'",
	        "/whois /w user", "Request user info for user 'user'",
	        "/ip user", "Show IP for user 'user'",
	        "", "",
	        "/alias /al [command [definition]]", "Add a new alias",
	        "/unalias /un command", "Remove an alias",
	        "", "",
	        "/ban user", "Add user 'user' to your ban list",
	        "/unban user", "Remove user 'user' from your ban list",
	        "/ignore user", "Add user 'user' to your ignore list",
	        "/unignore user", "Remove user 'user' from your ignore list",
	        "", "",
	        "/msg user message", "Send 'message' to 'user'",
	        "/pm user", "Open private to user 'user'",
	        "", "",
	        "/search /s query", "Start a new search for 'query'",
	        "/rsearch /rs query", "Search the joined roms for 'query'",
	        "/bsearch /bs query", "Search the buddy list for 'query'",
	        "/usearch /us user query", "Search a user's shares for 'query'",
	        "", "",
	        "/away /a", "Toggles your away status",
	        "/quit /q", "Quit PySoulSeek",
	    ]
	else:
	    help = [ \
	        "/close","/c", "Close the current private chat",
		"/clear /cl", "Clear the chat window",
	        "", "",
	        "/add /ad [user]", "Add user 'user' to your user list",
	        "/browse /b [user]", "Browse files of user 'user'",
	        "/whois /w [user]", "Request user info for user 'user'",
	        "/ip [user]", "Show IP for user 'user'",
	        "", "",
	        "/alias /al [command [definition]]", "Add a new alias",
	        "/unalias /un command", "Remove an alias",
	        "", "",
	        "/ban [user]", "Add user 'user' to your ban list",
	        "/unban [user]", "Remove user 'user' from your ban list",
	        "/ignore [user]", "Add user 'user' to your ignore list",
	        "/unignore [user]", "Remove user 'user' from your ignore list",
	        "", "",
	        "/search /s query", "Start a new search for 'query'",
		"/rsearch /rs query", "Search the joined roms for 'query'",
	        "/bsearch /bs query", "Search the buddy list for 'query'",
	        "/usearch /us query", "Search a user's shares for 'query'",
	        "", "",
	        "/away /a", "Toggles your away status",
	        "/quit /q", "Quit PySoulSeek",
	    ]
	grid = wxFlexGridSizer(cols=2)
	for index in range(len(help)):
	    item = help[index]
	    grid.Add(wxStaticText(self, -1, item), flag=wxLEFT, border=(index%2)*5)
	sizer.Add(grid, flag=wxALL|wxALIGN_CENTER, border = 5)
	if private:
	    sizer.Add(wxStaticText(self, -1, """In private chats, the user argument is optional. If it is
omitted, PySoulSeek will use the user that you're talking to.""",style=wxALIGN_CENTER), flag=wxALIGN_CENTER|wxTOP, border=5)
	else:
	    sizer.Add(wxStaticText(self, -1, """Pressing tab key does nickname autocompletion.""", style=wxALIGN_CENTER), flag=wxALIGN_CENTER|wxTOP, border=5)

	mainsizer.Add(sizer, flag=wxALL,border = 5)
	mainsizer.Add(ok, flag = wxALL|wxALIGN_CENTER,border = 10)
        self.SetSizer(mainsizer)
        self.SetAutoLayout(True)
        mainsizer.Fit(self)

class AboutFilters(wxDialog):
    def __init__(self, parent, id, title):

        wxDialog.__init__(self,parent,id,title)

	sizer = wxStaticBoxSizer(wxStaticBox(self,-1,""),wxHORIZONTAL)

	mainsizer = wxBoxSizer(wxVERTICAL)

        ok = wxButton(self, wxID_OK, "OK")
        ok.SetDefault()

	sizer.Add(wxStaticText(self,-1,"""Search filtering

You can use this to refine which results are displayed. The full results
from the server are always available if you clear all the search terms.

You can filter by:

Included text: Files are shown if they contain this text. Case is insensitive,
but word order is important. "Spears Brittany" will not show any "Brittany Spears"

Excluded text: As above, but files will not be displayed if the text matches

Size: Shows results based on size. use > and < to find files larger or smaller.
Files exactly the same as this term will always match. Use = to specify an exact
match. Use k or m to specify kilo or megabytes. >10M will find files larger than
10 megabytes. <4000k will find files smaller than 4000k.

Bitrate: Find files based on bitrate. Use < and > to find lower or higher. >192
finds 192 and higher, <192 finds 192 or lower. =192 only finds 192. for VBR, the
average bitrate is used.

Free slot: Show only those results from users which have at least one upload slot
free.

To set the filter, press Enter. This will apply to any existing results, and any
more that are returned. To filter in a different way, just set the relevant terms.
You do not need to do another search to apply a different filter.""",style=wxALIGN_CENTRE), flag = wxALL, border = 5)

	mainsizer.Add(sizer, flag=wxALL,border = 5)
	mainsizer.Add(ok, flag = wxALL|wxALIGN_CENTER,border = 10)
        self.SetSizer(mainsizer)
        self.SetAutoLayout(True)
        mainsizer.Fit(self)
