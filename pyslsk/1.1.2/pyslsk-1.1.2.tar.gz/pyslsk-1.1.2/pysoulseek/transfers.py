# Copyright (c) 2001-2003 Alexander Kanavin. All rights reserved.

""" This module contains classes that deal with file transfers: the 
transfer manager.
"""

import slskmessages
import threading
from slskmessages import newId
import os,stat
import os.path
import pysoulseek
import string
import time
import mp3
import locale
import utils
import md5

class Transfer:
    """ This class holds information about a single transfer. """
    def __init__(self, conn = None, user = None, filename = None, path = None, status = None, req=None, size = None, file = None, starttime = None, offset = None, currentbytes = None, speed = None,timeelapsed = None, timeleft = None, timequeued = None, transfertimer = None, requestconn = None):
	self.user = user
	self.filename = filename
	self.conn = conn
	self.path = path
	self.status = status
	self.req = req
	self.size = size
	self.file = file
	self.starttime = starttime
	self.offset = offset
	self.currentbytes = currentbytes
	self.speed = speed
	self.timeelapsed = timeelapsed
	self.timeleft = timeleft
	self.timequeued = timequeued
	self.transfertimer = transfertimer
	self.requestconn = None

class TransferTimeout:
    def __init__(self, req, callback):
        self.req = req
        self.callback = callback

    def timeout(self):
        self.callback([self])


class Transfers:
    """ This is the transfers manager"""
    def __init__(self, downloads, peerconns, queue, eventprocessor, users):
	self.peerconns = peerconns
	self.queue = queue
	self.eventprocessor = eventprocessor
	self.downloads = []
	self.uploads = []
	self.privilegedusers = []
	getstatus = {}
	for i in downloads:
	    self.downloads.append(Transfer(user = i[0], filename=i[1], path=i[2], status = 'Getting status'))
	    getstatus[i[0]] = ""
	for i in getstatus.keys():
	    self.queue.put(slskmessages.GetUserStatus(i))
	self.SaveDownloads()
	self.users = users
	self.downloadspanel = None
	self.uploadspanel = None
 
    def setTransferPanels(self, downloads, uploads):
	self.downloadspanel = downloads
	self.uploadspanel = uploads

    def setPrivilegedUsers(self, list):
	self.privilegedusers = list

    def addToPrivileged(self, user):
	self.privilegedusers.append(user)

    def getAddUser(self,msg):
	""" Server tells us it'll notify us about a change in user's status """
	if not msg.userexists:
	    self.eventprocessor.logMessage("User %s does not exist" % (msg.user))

    def GetUserStatus(self,msg):
	""" We get a status of a user and if he's online, we request a file from 	him """
	for i in self.downloads:
	    if msg.user == i.user and i.status in ['Queued', 'Getting status', 'User logged off', 'Connection closed by peer', 'Aborted', 'Cannot connect']:
		if msg.status != 0:
		    if i.status not in ['Queued', 'Aborted', 'Cannot connect']:
                        self.getFile(i.user, i.filename, i.path, i)
	        else:
                    i.status = "User logged off"
		    self.downloadspanel.update(i)    

        for i in self.uploads[:]:
            if msg.user == i.user and i.status != 'Finished':
                if msg.status != 0:
		    if i.status == 'Getting status':
                        self.pushFile(i.user, i.filename, i.path, i)
                else:
		    if i.transfertimer is not None:
			i.transfertimer.cancel()
                    self.uploads.remove(i)
		    self.uploadspanel.update()
	if msg.status == 0:
	    self.checkUploadQueue()


    def getFile(self, user, filename, path="", transfer = None):
	self.transferFile(0,user,filename,path,transfer)

    def pushFile(self, user, filename, path="", transfer = None):
        self.transferFile(1,user,filename,path,transfer)

    def transferFile(self, direction, user, filename, path="", transfer = None):
	""" Get a single file. path is a local path. if transfer object is 
	not None, update it, otherwise create a new one."""
        if transfer is None:
	    transfer = Transfer(user = user, filename= filename, path=path, status = 'Getting status')
            if direction == 0:
                self.downloads.append(transfer)
                self.SaveDownloads()
            else:
                self.uploads.append(transfer)
        else:
            transfer.status = 'Getting status'
        if user in self.users.keys():
	    status = self.users[user].status
	else:
	    status = None
	if status is None:
	    self.queue.put(slskmessages.GetUserStatus(user))
	else:
	    transfer.req = newId()
	    self.eventprocessor.ProcessRequestToPeer(user,slskmessages.TransferRequest(None,direction,transfer.req,filename, self.getFileSize(filename)))
	if direction == 0:
   	    self.downloadspanel.update(transfer)
	else:
            self.uploadspanel.update(transfer)


    def UploadFailed(self,msg):
        for i in self.peerconns:
            if i.conn is msg.conn.conn:
                user = i.username
		break
	else:
	    return
	for i in self.downloads:
	    if i.user == user and i.filename == msg.file and (i.conn is not None or i.status in ["Connection closed by peer", "Establishing connection"]):
		self.AbortTransfer(i)
		self.getFile(i.user, i.filename, i.path, i)
		self.eventprocessor.logMessage("Retrying failed download: user %s, file %s" %(i.user,i.filename))
		break
	else:
	    self.eventprocessor.logMessage("Failed download: user %s, file %s" %(user,msg.file))

    def gettingAddress(self, req):
	for i in self.downloads:
	    if i.req == req:
		i.status = "Getting address"
                self.downloadspanel.update(i)
        for i in self.uploads:
            if i.req == req:
                i.status = "Getting address"
                self.uploadspanel.update(i)

    def gotAddress(self, req):
	""" A connection is in progress, we got the address for a user we need
	to connect to."""
	for i in self.downloads:
	    if i.req == req:
		i.status = "Connecting"
                self.downloadspanel.update(i)
        for i in self.uploads:
            if i.req == req:
                i.status = "Connecting"
                self.uploadspanel.update(i)


    def gotConnectError(self,req):
	""" We couldn't connect to the user, now we are waitng for him to 
	connect to us. Note that all this logic is handled by the network
	event processor, we just provide a visual feedback to the user."""
	for i in self.downloads:
	    if i.req == req:
		i.status = "Waiting for peer to connect"
                self.downloadspanel.update(i)
        for i in self.uploads:
            if i.req == req:
                i.status = "Waiting for peer to connect"
                self.uploadspanel.update(i)

    def gotCantConnect(self,req):
	""" We can't connect to the user, either way. """
	for i in self.downloads:
	    if i.req == req:
		i.status = "Cannot connect"
		i.req = None
                self.downloadspanel.update(i)
		self.queue.put(slskmessages.GetUserStatus(i.user))
        for i in self.uploads:
            if i.req == req:
                i.status = "Cannot connect"
		i.req = None
		curtime = time.time()
                for j in self.uploads:
                    if j.user == i.user:
                        j.timequeued = curtime
                self.uploadspanel.update(i)
		self.queue.put(slskmessages.GetUserStatus(i.user))
		self.checkUploadQueue()


    def gotFileConnect(self, req, conn):
	""" A transfer connection has been established, 
	now exchange initialisation messages."""
	for i in self.downloads:
	    if i.req == req:
		i.status = "Initializing transfer"
		self.downloadspanel.update(i)
	for i in self.uploads:
            if i.req == req:
                i.status = "Initializing transfer"
                self.uploadspanel.update(i)

    def gotConnect(self, req, conn):
	""" A connection has been established, now exchange initialisation
	messages."""
	for i in self.downloads:
	    if i.req == req:
		i.status = "Requesting file"
		i.requestconn = conn
		self.downloadspanel.update(i)
	for i in self.uploads:
            if i.req == req:
                i.status = "Requesting file"
		i.requestconn = conn
                self.uploadspanel.update(i)


    def TransferRequest(self,msg):
	if msg.conn is not None:
            for i in self.peerconns:
                if i.conn is msg.conn.conn:
	    	    user = i.username
		    conn = msg.conn.conn
	elif msg.tunneleduser is not None:
	    user = msg.tunneleduser
	    conn = None
	if user is None:
	    self.eventprocessor.logMessage("Got transfer request:", vars(msg),"but cannot determine requestor",1)
	    return
	
	if msg.direction == 1:
	    for i in self.downloads:
		if i.filename == msg.file and user == i.user and i.status == "Queued":
		    i.size = msg.filesize
		    i.req = msg.req
		    i.status = "Waiting for download"
		    transfertimeout = TransferTimeout(i.req, self.eventprocessor.frame.callback)
		    if i.transfertimer is not None:
			i.transfertimer.cancel()
		    i.transfertimer = threading.Timer(30.0, transfertimeout.timeout)
		    i.transfertimer.start()
		    response = slskmessages.TransferResponse(conn,1,req = i.req)
                    self.downloadspanel.update(i)
		    break
	    else:
		response = slskmessages.TransferResponse(conn,0,reason = "Cancelled", req = msg.req)
		self.eventprocessor.logMessage("Denied file request: "+str(vars(msg)),1)
	else:
	    if user in self.eventprocessor.config.sections["server"]["banlist"]:
	        if self.eventprocessor.config.sections["transfers"]["usecustomban"]:
	            banmsg = "Banned (%s)" % self.eventprocessor.config.sections["transfers"]["customban"]
	        else:
	            banmsg = "Banned"
	        response = slskmessages.TransferResponse(conn,0,reason = banmsg,req=msg.req)
	    elif not self.fileIsShared(msg.file):
		response = slskmessages.TransferResponse(conn,0,reason = "File not shared", req = msg.req)
	    elif self.userTransfers(user) or self.bandwidthLimitReached() or self.transferNegotiating():
		response = slskmessages.TransferResponse(conn,0,reason = "Queued", req = msg.req)
	        for i in self.uploads:
	            if i.user == user and i.filename == msg.file and i.status == 'Queued':
	                break
	        else:
		    self.uploads.append(Transfer(user = user, filename = msg.file, path = os.path.dirname(msg.file.replace('\\','/')), status = "Queued", timequeued = time.time(), size = self.getFileSize(msg.file)))
		    self.uploadspanel.update(self.uploads[-1])
	    else:
		size = self.getFileSize(msg.file)
		response = slskmessages.TransferResponse(conn,1,req = msg.req, filesize = size)
                transfertimeout = TransferTimeout(msg.req, self.eventprocessor.frame.callback) 
		self.uploads.append(Transfer(user = user, filename = msg.file, path = os.path.dirname(msg.file.replace('\\','/')), status = "Waiting for upload", req = msg.req, size = size))
                self.uploads[-1].transfertimer = threading.Timer(30.0, transfertimeout.timeout)
		self.uploads[-1].transfertimer.start()
		self.uploadspanel.update(self.uploads[-1])
	    self.eventprocessor.logMessage("Upload request: " +str(vars(msg)),1)

        if msg.conn is not None:
            self.queue.put(response)
        else:
            self.eventprocessor.ProcessRequestToPeer(user,response)

    def QueueUpload(self, msg):
        for i in self.peerconns:
            if i.conn is msg.conn.conn:
                user = i.username
	for i in self.uploads:
	    if i.user == user and i.filename == msg.file and i.status == 'Queued':
		break
	else:
            if user in self.eventprocessor.config.sections["server"]["banlist"]:
                if self.eventprocessor.config.sections["transfers"]["usecustomban"]:
                    banmsg = "Banned (%s)" % self.eventprocessor.config.sections["transfers"]["customban"]
                else:
                    banmsg = "Banned"
		self.queue.put(slskmessages.QueueFailed(conn = msg.conn.conn, file = msg.file, reason = banmsg))
 	    elif self.fileIsShared(msg.file):
	        self.uploads.append(Transfer(user = user, filename = msg.file, path = os.path.dirname(msg.file.replace('\\','/')), status = "Queued", timequeued = time.time(), size = self.getFileSize(msg.file)))
		self.uploadspanel.update(self.uploads[-1])
	    else:
		self.queue.put(slskmessages.QueueFailed(conn = msg.conn.conn, file = msg.file, reason = "File not shared."))
        self.eventprocessor.logMessage("Queued upload request: " +str(vars(msg)),1)
	self.checkUploadQueue()


    def QueueFailed(self, msg):
        for i in self.peerconns:
            if i.conn is msg.conn.conn:
                user = i.username
        for i in self.downloads:
            if i.user == user and i.filename == msg.file and i.status == 'Queued':
		i.status = msg.reason
		self.downloadspanel.update(i)
                break


    def fileIsShared(self, filename):
	filename = filename.replace("\\","/")
	if not os.access(filename, os.R_OK): return 0
	dir = os.path.dirname(filename)
	file = os.path.basename(filename)
	shared = self.eventprocessor.config.sections["transfers"]["sharedfiles"]
	for i in shared.get(dir, ''):
	    if file == i[0]: return 1
	return 0

    def userTransfers(self, user):
	for i in self.uploads:
	    if i.user == user and (i.req is not None or i.conn is not None or i.status == 'Getting status'): #some file is being transfered
		return 1
	return 0

    def transferNegotiating(self):
	for i in self.uploads:
	    if i.req is not None or (i.conn is not None and i.speed is None) or i.status == 'Getting status': #some file is being negotiated
                return 1
        return 0

    def bandwidthLimitReached(self):
	maxbandwidth = self.eventprocessor.config.sections["transfers"]["uploadbandwidth"]
	bandwidth = 0
	curtime = time.time()
	for i in self.uploads:
	    if i.conn is not None and i.speed is not None:
		bandwidth = bandwidth + i.speed
#	self.eventprocessor.logMessage("%i %i " %(bandwidth, maxbandwidth),1)
	if bandwidth > maxbandwidth:
	    return 1
	return 0

    def getFileSize(self,filename):
	try:
	    size = os.path.getsize(filename.replace("\\","/"))
	except:
	    size = 0
	return size

    def TransferResponse(self,msg):
	""" Got a response to the file request from the peer."""
	if msg.reason != None:
	    for i in (self.downloads+self.uploads)[:]:
		if i.req == msg.req:
		    i.status = msg.reason
		    i.req = None
		    self.downloadspanel.update(i)
		    self.uploadspanel.update(i)
		    if msg.reason == "Queued":
			if i.user not in self.users or self.users[i.user].status is None:
		            self.queue.put(slskmessages.GetUserStatus(i.user))
		        if i in self.uploads:
			    if i.transfertimer is not None:
				i.transfertimer.cancel()
			    self.uploads.remove(i)
			    self.uploadspanel.update()
		    self.checkUploadQueue()
	elif msg.filesize != None:
	    for i in self.downloads:
		if i.req == msg.req:
                    i.size = msg.filesize
                    i.status = "Establishing connection"
                    #Have to establish 'F' connection here
                    self.eventprocessor.ProcessRequestToPeer(i.user,slskmessages.FileRequest(None,msg.req))
		    self.downloadspanel.update(i)
		    break
	else:
	    for i in self.uploads:
		if i.req == msg.req:
		    i.status = "Establishing connection"
 		    self.eventprocessor.ProcessRequestToPeer(i.user,slskmessages.FileRequest(None,msg.req))
		    self.uploadspanel.update(i)
		    break
	    else:
		self.eventprocessor.logMessage("Got unknown transfer response: " + str(vars(msg)),1)

    def TransferTimeout(self, msg):
        for i in (self.downloads+self.uploads)[:]:
            if i.req == msg.req:
                i.status = "Cannot connect"
                i.req = None
		self.queue.put(slskmessages.GetUserStatus(i.user))
                self.downloadspanel.update(i)
                self.uploadspanel.update(i)
	self.checkUploadQueue()

    def FileRequest(self, msg):
	""" Got an incoming file request. Could be an upload request or a 
	request to get the file that was previously queued"""

	downloaddir = self.eventprocessor.config.sections["transfers"]["downloaddir"]
	for i in self.downloads:
	    if msg.req == i.req and i.conn is None and i.size is not None:
		i.conn = msg.conn
		i.req = None
		if i.transfertimer is not None:
                    i.transfertimer.cancel()
		try:
		    folder = os.path.join(downloaddir,i.path)
		    if not os.access(folder,os.F_OK):
		        os.makedirs(folder)
		except OSError, (errno, strerror):
		    self.eventprocessor.logMessage("OS error(%s): %s" % (errno, strerror))
		    i.status = "Download directory error"
		    i.conn = None
		    self.queue.put(slskmessages.ConnClose(msg.conn))
		else: 
		  try:
                    # also check for a windows-style incomplete transfer
		    basename = string.split(i.filename,'\\')[-1]
                    winfname = os.path.join(downloaddir,i.path,"INCOMPLETE~"+basename)
                    pyfname  = os.path.join(downloaddir,i.path,"INCOMPLETE"+basename)
		    pynewfname = os.path.join(downloaddir,i.path,"INCOMPLETE"+md5.new(i.filename+i.user).hexdigest()+basename)
                    if os.access(winfname,os.F_OK):
                        fname = winfname
                    elif os.access(pyfname,os.F_OK):
                        fname = pyfname
		    else:
			fname = pynewfname
                    f = open(fname,'ab+')
		    import fcntl
		    fcntl.lockf(f, fcntl.LOCK_EX|fcntl.LOCK_NB)
                    f.seek(0,2)
		    size = f.tell()
		    self.queue.put(slskmessages.DownloadFile(i.conn,size,f,i.size))
		    i.currentbytes = size
                    i.status = "%s" %(str(i.currentbytes))
                    i.file = f
		    i.offset = size
		    i.starttime = time.time()
		    self.eventprocessor.logMessage("Download started: %s" %(f.name))
                  except IOError, (errno, strerror):
		    self.eventprocessor.logMessage("I/O error(%s): %s" % (errno, strerror))
                    i.status = "Local file error"
                    try:
                        f.close()
                    except:
                        pass
                    i.conn = None
                    self.queue.put(slskmessages.ConnClose(msg.conn))

                self.downloadspanel.update(i)
		return
         
	for i in self.uploads:
            if msg.req == i.req and i.conn is None:
                i.conn = msg.conn
		i.req = None
                if i.transfertimer is not None:
                    i.transfertimer.cancel()
                try:
		    f = open(i.filename.replace("\\","/"),"rb")
		    self.queue.put(slskmessages.UploadFile(i.conn,file = f,size =i.size))
		    i.status = "Initializing transfer"
		    i.file = f
                except IOError, (errno, strerror):
		    self.eventprocessor.logMessage("I/O error(%s): %s" % (errno, strerror))
                    i.status = "Local file error"
                    try:
                        f.close()
                    except:
                        pass
                    i.conn = None
                    self.queue.put(slskmessages.ConnClose(msg.conn))
                self.uploadspanel.update(i)
                break
	else:
	    self.eventprocessor.logMessage("Unknown file request: " +str(vars(msg)),1)
	    self.queue.put(slskmessages.ConnClose(msg.conn))

    def FileDownload(self, msg):
	""" A file download is in progress"""
	needupdate = 1

	for i in self.downloads:
	    if i.conn == msg.conn:
		    try:
			curtime = time.time()
                        i.currentbytes = msg.file.tell()
                        i.status = "%s" %(str(i.currentbytes))
			oldelapsed = i.timeelapsed
	                i.timeelapsed = self.getTime(curtime - i.starttime)
			if curtime > i.starttime and i.currentbytes > i.offset:
			    i.speed = (i.currentbytes - i.offset)/(curtime - i.starttime)/1024
	                    i.timeleft = self.getTime((i.size - i.currentbytes)/i.speed/1024)
		        if i.size > i.currentbytes:
			    if oldelapsed == i.timeelapsed:
				needupdate = 0
			    i.status = locale.format("%s",i.currentbytes,1)
			else:
		            msg.file.close()
			    basename = string.split(i.filename,'\\')[-1]
			    newname = self.getRenamed(os.path.join(os.path.dirname(msg.file.name),basename))
		            os.rename(msg.file.name,newname)
		            i.status = "Finished"
			    self.eventprocessor.logMessage("Download finished: %s" %(newname))
			    self.queue.put(slskmessages.ConnClose(msg.conn))
			    if i.speed is not None:
			        self.queue.put(slskmessages.SendSpeed(i.user, int(i.speed*1024)))
			    i.conn = None
			    self.addToShared(newname)
			    self.eventprocessor.sendNumSharedFoldersFiles()
			    self.SaveDownloads()
			    self.downloadspanel.update(i)
		    except IOError, (errno, strerror):
			self.eventprocessor.logMessage("I/O error(%s): %s" % (errno, strerror))
                        i.status = "Local file error"
	                try:
	                    msg.file.close()
	                except:
	                    pass
	                i.conn = None
	                self.queue.put(slskmessages.ConnClose(msg.conn))
		    if needupdate:
		        self.downloadspanel.update(i)
    
    def addToShared(self, name):
	if self.eventprocessor.config.sections["transfers"]["sharedownloaddir"]:
	    shared = self.eventprocessor.config.sections["transfers"]["sharedfiles"]
	    sharedstreams = self.eventprocessor.config.sections["transfers"]["sharedfilesstreams"]
	    sharedindex = self.eventprocessor.config.sections["transfers"]["sharedindex"]
	    shareddirs = self.eventprocessor.config.sections["transfers"]["shared"] + [self.eventprocessor.config.sections["transfers"]["downloaddir"]]
	    sharedmtimes = self.eventprocessor.config.sections["transfers"]["sharedmtimes"]
            dir = os.path.dirname(name)
            file = os.path.basename(name)
	    size = os.path.getsize(name)

	    shared.setdefault(dir, [])
	    if file not in [i[0] for i in shared[dir]]:
		fileinfo = utils.getFileInfo(file,name)
		shared[dir].append(fileinfo)
		sharedstreams[dir] = utils.getDirStream(shared[dir])
		words = utils.getIndexWords(dir,file, shareddirs)
		self.addToIndex(sharedindex, words, dir, fileinfo)
		sharedmtimes[dir] = os.path.getmtime(dir) 
	        self.eventprocessor.config.writeShares()
		

    def addToIndex(self, index, words, dir, fileinfo):
	for i in words:
	    if i not in index.keys():
		index[i] = [(os.path.join(dir,fileinfo[0]),)+fileinfo[1:]]
	    else:
		index[i].append((os.path.join(dir,fileinfo[0]),)+fileinfo[1:])


    def FileUpload(self,msg):
        """ A file upload is in progress"""
	needupdate = 1

        for i in self.uploads:
            if i.conn == msg.conn:
		curtime = time.time()
		if i.starttime is None:
		    i.starttime = curtime
		    i.offset = msg.offset
		i.currentbytes = msg.offset + msg.sentbytes
		oldelapsed = i.timeelapsed
		i.timeelapsed = self.getTime(curtime - i.starttime)
		if curtime > i.starttime and i.currentbytes > i.offset:
		    i.speed = (i.currentbytes - i.offset)/(curtime - i.starttime)/1024
		    i.timeleft = self.getTime((i.size - i.currentbytes)/i.speed/1024)
		    self.checkUploadQueue()
		if i.size > i.currentbytes:
		    if oldelapsed == i.timeelapsed:
			needupdate = 0
                    i.status = locale.format("%s",i.currentbytes,1)
                    if i.user in self.privilegedusers:
                        i.status = i.status + " (privileged)"
		else:
                    msg.file.close()
                    i.status = "Finished"
#                    i.conn = None
#		    self.queue.put(slskmessages.ConnClose(msg.conn))
		    for j in self.uploads:
			if j.user == i.user:
			    j.timequeued = curtime
		    self.checkUploadQueue()
		    self.uploadspanel.update(i)
		if needupdate:
                    self.uploadspanel.update(i)

    def BanUser(self, user):
        if self.eventprocessor.config.sections["transfers"]["usecustomban"]:
            banmsg = "Banned (%s)" % self.eventprocessor.config.sections["transfers"]["customban"]
        else:
            banmsg = "Banned"

    	list = [i for i in self.uploads if i.user == user]
        for upload in list:
	    if upload.status == "Queued":
		self.eventprocessor.ProcessRequestToPeer(user,slskmessages.QueueFailed(None,file = upload.filename, reason = banmsg))
	    else:
                self.AbortTransfer(upload)
        if self.uploadspanel is not None:
	    self.uploadspanel.ClearByUser(user)
        if user not in self.eventprocessor.config.sections["server"]["banlist"]:
            self.eventprocessor.config.sections["server"]["banlist"].append(user)
            self.eventprocessor.config.writeConfig()


    def checkUploadQueue(self):
	if self.bandwidthLimitReached() or self.transferNegotiating():
	    return
	transfercandidate = None
	list = [i for i in self.uploads if not self.userTransfers(i.user) and i.status == "Queued"]
	listogg = [i for i in list if i.filename[-4:].lower() == ".ogg"]
	listprivileged = [i for i in list if i.user in self.privilegedusers]
	if len(listogg) > 0:
	    list = listogg
	if len(listprivileged) > 0:
	    list = listprivileged
	if len(list) == 0:
	    return
	mintimequeued = time.time() + 1
	for i in list:
	    if i.timequeued < mintimequeued:
		transfercandidate = i
		mintimequeued = i.timequeued
	if transfercandidate is not None:
	    self.pushFile(user = transfercandidate.user, filename = transfercandidate.filename, transfer = transfercandidate)

    def PlaceInQueueRequest(self, msg):
        for i in self.peerconns:
            if i.conn is msg.conn.conn:
                user = i.username
		
	list = {user:time.time()}
	listogg = {user:time.time()}
	listpriv = {user:time.time()}
	countogg = 0
	countpriv = 0
        for i in self.uploads:
	    if i.status == "Queued":
		if i.user in self.privilegedusers:
		    listpriv[i.user] = i.timequeued
		    countpriv += 1
		elif i.filename[-4:].lower() == ".ogg":
		    listogg[i.user] = i.timequeued
		    countogg += 1
		else:
		    list[i.user] = i.timequeued

	place = 0
	if user in self.privilegedusers:
	    list = listpriv
	elif msg.file[-4:].lower() == ".ogg":
	    list = listogg
	    place = place + countpriv
	else:
	    place = place + countpriv + countogg
	for i in list.keys():
	    if list[i] < list[user]:
		place = place + 1
	self.queue.put(slskmessages.PlaceInQueue(msg.conn.conn, msg.file, place))

    def getTime(self,seconds):
	sec = int(seconds % 60)
	minutes = int(seconds / 60 % 60)
	hours = int(seconds / 3600 % 24)
	days = int(seconds/86400)
	
	time = "%02d:%02d:%02d" %(hours, minutes, sec)
	if days > 0:
	    time = str(days) + "." + time
	return time

    def getUploadQueueSizes(self, username = None):
	list = {}
	listpriv = {}
	listogg = {}
	countpriv = 0
	countogg = 0
	for i in self.uploads:
	    if i.status == "Queued":
		if i.user in self.privilegedusers:
		    listpriv[i.user] = 1
		    countpriv += 1
		elif i.filename[-4:].lower() == ".ogg":
		    listogg[i.user] = 1
		    countogg += 1
		else:
		    list[i.user] = 1
	if username in self.privilegedusers:
	    return len(listpriv), len(listpriv)
	else:
	    return len(list)+countpriv+countogg, len(listogg)+countpriv

    def getTotalUploadsAllowed(self):
	list = [i for i in self.uploads if i.conn is not None]
	if self.bandwidthLimitReached():
	    return len(list)
	else:
	    return len(list)+1
	    

    def ConnClose(self, msg):
	""" The remote user has closed the connection either because
	he logged off, or because there's a network problem."""
	for i in self.downloads + self.uploads:
	    if i.requestconn == msg.conn and i.status == 'Requesting file':
		i.requestconn = None
		i.status = "Connection closed by peer"
		i.req = None
                self.downloadspanel.update(i)
                self.uploadspanel.update(i)
                self.checkUploadQueue()
	    if i.conn == msg.conn:
		if i.file is not None:
		    i.file.close()
		if i.status != "Finished":
		    if i.user in self.users.keys() and self.users[i.user].status == 0:
		        i.status = "User logged off"
		    else:
		        i.status = "Connection closed by peer"
		i.conn = None
       	        self.downloadspanel.update(i)
	        self.uploadspanel.update(i)
	 	self.checkUploadQueue()

    def getRenamed(self,name):
	""" When a transfer is finished, we remove INCOMPLETE~ or INCOMPLETE 
	prefix from the file's name. """
	if not os.path.exists(name):
	    return name
	else:
	    n = 1
	    while n < 1000:
		newname = name+"."+str(n)
		if not os.path.exists(newname):
		    break
		n+=1
	return newname

    def PlaceInQueue(self,msg):
	""" The server tells us our place in queue for a particular transfer."""
	self.eventprocessor.logMessage("File: %s, place in queue: %s" % (string.split(msg.filename,'\\')[-1], msg.place))

    def FileError(self, msg):
	""" Networking thread encountered a local file error"""
	for i in self.downloads+self.uploads:
	    if i.conn == msg.conn.conn:
		i.status = "Local file error"
		try:
		    msg.file.close()
		except:
		    pass
		i.conn = None
		self.queue.put(slskmessages.ConnClose(msg.conn.conn))
		self.eventprocessor.logMessage("I/O error(%s): %s" % (msg.errno, msg.strerror))
                self.downloadspanel.update(i)
                self.uploadspanel.update(i)
		self.checkUploadQueue()


    def FolderContentsResponse(self,msg):
	""" When we got a contents of a folder, get all the files in it, but
	skip the files in subfolders"""
        for i in self.peerconns:
            if i.conn is msg.conn.conn:
                username = i.username

        for i in msg.list.keys():
            for j in msg.list[i].keys():
                if os.path.commonprefix([i,j]) == j:
                    for k in msg.list[i][j]:
			if j[-1] == '\\':
                            self.getFile(username, j + k[1], j.split('\\')[-2])
			else:
			    self.getFile(username, j + '\\' + k[1], j.split('\\')[-1])

    def AbortTransfers(self):
	""" Stop all transfers """
	for i in self.downloads+self.uploads:
	    if i.status != "Finished":
		self.AbortTransfer(i)
		i.status = "Old"
#                self.downloadspanel.update()
#                self.uploadspanel.update()


    def AbortTransfer(self,transfer, remove = False):
	if transfer.conn is not None:
            self.queue.put(slskmessages.ConnClose(transfer.conn))
	    transfer.conn = None
	if transfer.transfertimer is not None:
	    transfer.transfertimer.cancel()
	if transfer.file is not None:
	    try:
		transfer.file.close()
	        if remove:
	    	    os.remove(transfer.file.name)
	    except:
		pass


    def GetDownloads(self):
	""" Get a list of incomplete and not aborted downloads """
	return [ [i.user, i.filename, i.path] for i in self.downloads if i.status != 'Finished']

    def SaveDownloads(self):
	self.eventprocessor.config.sections["transfers"]["downloads"] = self.GetDownloads()
	self.eventprocessor.config.writeConfig()
