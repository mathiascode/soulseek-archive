# Copyright (c) 2001-2003 Alexander Kanavin. All rights reserved.

"""
This module provides an About dialog box
"""

from wxPython.wx import *
import images
from pysoulseek.utils import version


class About(wxDialog):
    def __init__(self, parent, id, title):

        wxDialog.__init__(self,parent,id,title)

	sizer = wxStaticBoxSizer(wxStaticBox(self,-1,""),wxHORIZONTAL)

	mainsizer = wxBoxSizer(wxVERTICAL)

	img = images.getBirdBitmap()
        ok = wxButton(self, wxID_OK, "OK")
        ok.SetDefault()

	sizer.Add(wxStaticBitmap(self,-1,img,size=wxSize(img.GetWidth(), img.GetHeight())), flag=wxALL, border = 5)
	sizer.Add(wxStaticText(self,-1,"PySoulSeek "+version+"\nCopyright (c) 2001-2003 by Alexander Kanavin\nhttp://www.sensi.org/~ak/\nak@sensi.org\n\nReleased under the GNU general public license\n\nSee MAINTAINERS file for the list of contributors",style=wxALIGN_CENTRE), flag = wxALL, border = 5)

	mainsizer.Add(sizer, flag=wxALL,border = 5)
	mainsizer.Add(ok, flag = wxALL|wxALIGN_CENTER,border = 10)
        self.SetSizer(mainsizer)
        self.SetAutoLayout(True)
        mainsizer.Fit(self)

class AboutCommands(wxDialog):
    def __init__(self, parent, id, title, private = False):

        wxDialog.__init__(self,parent,id,title)

	sizer = wxStaticBoxSizer(wxStaticBox(self,-1,""),wxVERTICAL)

	mainsizer = wxBoxSizer(wxVERTICAL)

        ok = wxButton(self, wxID_OK, "OK")
        ok.SetDefault()

	if private:
	    pvs = "private chat sessions"
	else:
	    pvs = "chat rooms"
	sizer.Add(wxStaticText(self, -1, "Commands available in %s:"%pvs), flag=wxALL|wxALIGN_CENTER, border=5)
	if not private:
	    help = [ \
	        "/join /j channel", "Join channel 'channel'",
	        "/leave /l [channel]", "Leave channel 'channel'",
	        "/part /p [channel]", "Leave channel 'channel'",
	        "", "",
	        "/add /ad user", "Add user 'user' to your user list",
	        "/browse /b user", "Browse files of user 'user'",
	        "/whois /w user", "Request user info for user 'user'",
	        "/ip user", "Show IP for user 'user'",
	        "", "",
	        "/ban user", "Add user 'user' to your ban list",
	        "/unban user", "Remove user 'user' from your ban list",
	        "/ignore user", "Add user 'user' to your ignore list",
	        "/unignore user", "Remove user 'user' from your ignore list",
	        "", "",
	        "/msg user message", "Send 'message' to 'user'",
	        "/pm user", "Open private to user 'user'",
	        "", "",
	        "/search /s query", "Start a new search for 'query'",
	        "/rsearch /rs query", "Search the joined roms for 'query'",
	        "/bsearch /bs query", "Search the buddy list for 'query'",
	        "/usearch /us user query", "Search a user's shares for 'query'",
	        "", "",
	        "/away /a", "Toggles your away status",
	        "/quit /q", "Quit PySoulSeek",
	    ]
	else:
	    help = [ \
	        "/close", "Close the current private chat",
	        "", "",
	        "/add /ad [user]", "Add user 'user' to your user list",
	        "/browse /b [user]", "Browse files of user 'user'",
	        "/whois /w [user]", "Request user info for user 'user'",
	        "/ip [user]", "Show IP for user 'user'",
	        "", "",
	        "/ban [user]", "Add user 'user' to your ban list",
	        "/unban [user]", "Remove user 'user' from your ban list",
	        "/ignore [user]", "Add user 'user' to your ignore list",
	        "/unignore [user]", "Remove user 'user' from your ignore list",
	        "", "",
	        "/search /s query", "Start a new search for 'query'",
		"/rsearch /rs query", "Search the joined roms for 'query'",
	        "/bsearch /bs query", "Search the buddy list for 'query'",
	        "/usearch /us query", "Search a user's shares for 'query'",
	        "", "",
	        "/away /a", "Toggles your away status",
	        "/quit /q", "Quit PySoulSeek",
	    ]
	grid = wxFlexGridSizer(cols=2)
	for index in range(len(help)):
	    item = help[index]
	    grid.Add(wxStaticText(self, -1, item), flag=wxLEFT, border=(index%2)*5)
	sizer.Add(grid, flag=wxALL|wxALIGN_CENTER, border = 5)
	if private:
	    sizer.Add(wxStaticText(self, -1, """In private chats, the user argument is optional. If it is
omitted, PySoulSeek will use the user that you're talking to.""",style=wxALIGN_CENTER), flag=wxALIGN_CENTER|wxTOP, border=5)
	else:
	    sizer.Add(wxStaticText(self, -1, """Pressing tab key does nickname autocompletion.""", style=wxALIGN_CENTER), flag=wxALIGN_CENTER|wxTOP, border=5)

	mainsizer.Add(sizer, flag=wxALL,border = 5)
	mainsizer.Add(ok, flag = wxALL|wxALIGN_CENTER,border = 10)
        self.SetSizer(mainsizer)
        self.SetAutoLayout(True)
        mainsizer.Fit(self)
