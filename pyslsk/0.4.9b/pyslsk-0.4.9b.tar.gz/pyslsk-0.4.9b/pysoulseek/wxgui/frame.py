# Copyright (c) 2001-2002 Alexander Kanavin. All rights reserved.

"""
This is the actual client code. Actual GUI classes are in the separate modules
"""

import time
from pysoulseek import slskproto
from pysoulseek import slskmessages
from pysoulseek.pysoulseek import *
import Queue
import threading
import images
import about
import userinfobrowse
import search
import chat
import transfers
import userlist
from wxPython.wx import *
from configwindow import *

class NetworkEvent(wxPyEvent):
    """
    Special event that occurs when networking thread sends us some messages.
    msgs is a list of them.
    """
    def __init__(self,id,msgs):
	wxPyEvent.__init__(self)
	self.SetEventType(id)
	self.msgs = msgs


class MainFrame(wxFrame):
    """ This is the very main window, with menu, status bar and notebook 
    that contains all other subwindows. Everything else is set up 
    from here""" 
    def __init__(self, parent, id, title): 
        wxFrame.__init__(self,parent,id,title, size = (800,600), style = wxDEFAULT_FRAME_STYLE|wxMAXIMIZE|wxNO_FULL_REPAINT_ON_RESIZE)
	self.EVT_NETWORK_ID = wxNewId()     
	self.EVT_NETWORK(self, self.EVT_NETWORK_ID, self.OnNetworkEvent)

	self.transfermsgs = {}
	self.transfermsgspostedtime = time.time()

        self.np = NetworkEventProcessor(self,self.callback,self.logMessage,self.SetStatusText)
	self.userlist = []
	self.userlistpanel = None
	self.away = 0

	# set icon here, see demo to know how
	self.SetIcon(images.getBirdIcon())

	# set task bar icon here, see demo to know how

        EVT_CLOSE(self, self.OnCloseWindow)
        self.Centre(wxBOTH)
        self.CreateStatusBar(1, wxST_SIZEGRIP)

	self.configwindow = ConfigWindow(self, -1, "Settings")

        self.mainmenu = wxMenuBar()

        menu = wxMenu()
	if not self.np.config.needConfig():
	    self.serverstring =  '%s:%s'%(self.np.config.sections["server"]["server"][0],self.np.config.sections["server"]["server"][1])
	else:
	    self.serverstring = ''
	self.connectID = wxNewId()
	menu.Append(self.connectID, '&Connect\tAlt-C', 'Connect to ' + self.serverstring)
	menu.Enable(self.connectID, not self.np.config.needConfig())
        EVT_MENU(self, self.connectID, self.OnConnect)
	self.disconnectID = wxNewId()
	menu.Append(self.disconnectID, '&Disconnect\tAlt-D', 'Disconnect from ' + self.serverstring)
	menu.Enable(self.disconnectID, false)
        EVT_MENU(self, self.disconnectID, self.OnDisconnect)
	self.awayID = wxNewId()
	menu.Append(self.awayID, '&Away/Return\tAlt-A', 'Toggle Away/Online status')
	menu.Enable(self.awayID,false)
	EVT_MENU(self, self.awayID, self.OnAway)

	self.checkprivID = wxNewId()
	menu.Append(self.checkprivID, 'Check &privileges', 'Check download privileges')
	menu.Enable(self.checkprivID,false)
	EVT_MENU(self,self.checkprivID, self.OnCheckPrivileges)
	menu.AppendSeparator()
	self.debugID = wxNewId()
	menu.Append(self.debugID, 'Show de&bug info', 'Toggle the display of debug information in the log window',wxITEM_CHECK)
	
	self.settingsID = wxNewId()
	menu.Append(self.settingsID, '&Settings...', 'Set up server name, login, password')
	EVT_MENU(self, self.settingsID, self.OnSettings)
	menu.AppendSeparator()
        self.exitID = wxNewId()
        menu.Append(self.exitID, 'E&xit\tAlt-X', 'Get the heck outta here!')
        EVT_MENU(self, self.exitID, self.OnFileExit)

	
	helpmenu = wxMenu()
        aboutID = wxNewId()
        helpmenu.Append(aboutID, '&About', 'About PySoulSeek')
        EVT_MENU(self, aboutID, self.OnAbout)

        self.mainmenu.Append(menu, '&File')
	self.mainmenu.Append(helpmenu, '&Help')
        self.SetMenuBar(self.mainmenu)

        self.splitter = wxSplitterWindow(self, -1,style=wxSP_3DSASH)
	self.splitter2 = wxSplitterWindow(self.splitter, -1)

	self.panel = wxPanel(self.splitter2, -1)
        self.nb = wxNotebook(self.panel, -1, style=wxCLIP_CHILDREN)
	self.expbutton = wxButton(self.panel,-1,"<",size=(10,100))
	sizer = wxBoxSizer(wxHORIZONTAL)
	sizer.Add(self.nb,1,wxEXPAND)
	sizer.Add(self.expbutton,0,wxALIGN_CENTER)
	self.panel.SetSizer(sizer)
	self.panel.SetAutoLayout(true)
	self.splitterpos = 650
	self.splitter2.Initialize(self.panel)
	self.sx = self.s2x = self.sy = self.s2y = None
	
	self.log = chat.OutputWindow(self.splitter,-1,style = wxTE_MULTILINE|wxTE_READONLY|wxTE_RICH)
	
	EVT_BUTTON(self, self.expbutton.GetId(),self.OnExpButton)
	EVT_RIGHT_UP(self.log, self.OnRightClickInLog)

        wxLog_SetActiveTarget(wxLogTextCtrl(self.log))
    
	self.splitter.SplitHorizontally(self.splitter2,self.log,400)	

	EVT_NOTEBOOK_PAGE_CHANGED(self,self.nb.GetId(),self.OnPageChanged)
	EVT_SIZE(self.splitter, self.OnSizeSplitter)
	EVT_SIZE(self.splitter2, self.OnSizeSplitter2)

	if not self.np.config.needConfig():
	    self.OnConnect(None)

    def OnExpButton(self,event):
	if self.expbutton.GetLabel() == "<":
	    self.expbutton.SetLabel(">")
	    self.userlistpanel = userlist.UserListPanel(self.splitter2,-1,self) 
	    self.splitter2.SplitVertically(self.panel,self.userlistpanel,self.splitterpos)
	else:
	    self.expbutton.SetLabel("<")
	    self.splitterpos = self.splitter2.GetSashPosition()
	    self.splitter2.Unsplit()
	    self.userlistpanel = None

    def OnSizeSplitter(self,event):
	x,y = self.splitter.GetSize()
	if self.sx is None:
		self.sx = x
		self.sy = y
	self.splitter.SetSashPosition(self.splitter.GetSashPosition()+(y-self.sy))
	self.sx = x
	self.sy = y
	event.Skip()

    def OnSizeSplitter2(self,event):
	event.Skip()
	x,y = self.splitter2.GetSize()
	if self.s2x is None:
	     self.s2x = x
	     self.s2y = y
	self.splitter2.SetSashPosition(self.splitter2.GetSashPosition()+(x-self.s2x))
	self.splitterpos = self.splitterpos+(x-self.s2x)
	self.s2x = x
	self.s2y = y


    def OnRightClickInLog(self,event):
	""" Log window is not self-cleaning yet, unlike chat windows. Will change that when the client stabilizes."""
	menu = wxMenu()
	clearID=wxNewId()
	menu.Append(clearID, 'Clear')
	EVT_MENU(self,clearID, self.OnClearLog)
	self.log.PopupMenu(menu, wxPoint(event.GetX(),event.GetY()))
	event.Skip()

    def OnClearLog(self,event):
	self.log.Clear()

    def OnCloseWindow(self, event):
 	""" Close the window, but finish all filetransfers and stop the 
	networking thread first."""
	if self.np.transfers is not None:
            self.np.transfers.AbortTransfers()
            self.np.config.setConfig({"transfers":{"downloads":self.np.transfers.GetDownloads(),"sharedfiles":self.np.config.sections["transfers"]["sharedfiles"]},"server":{"userlist":[i[0] for i in self.userlist],"autojoin":self.np.config.sections["server"]["autojoin"]}})
	    self.np.config.writeConfig()
        self.np.queue.put(slskmessages.ConnClose(self.np.serverconn)) 
	self.np.protothread.abort()
	while self.np.protothread.isAlive():
  	    wxYield()
	    time.sleep(0.1)
        self.Destroy()
	wxYield()

    """ Menu items handlers."""
    def OnFileExit(self, event):
        self.Close()

    def OnConnect(self, event):
	self.mainmenu.Enable(self.connectID,0)
	self.mainmenu.Enable(self.disconnectID,1)
	if self.np.serverconn is None:
	    server = self.np.config.sections["server"]["server"]
	    self.np.queue.put(slskmessages.ServerConn(None, server))
	    self.SetStatusText("Connecting to %s:%s" %(server[0],server[1]))

    def OnDisconnect(self, event):
	self.np.queue.put(slskmessages.ConnClose(self.np.serverconn))

    def OnCheckPrivileges(self, event):
	self.np.queue.put(slskmessages.CheckPrivileges())

    def OnAway(self, event):
	self.away = not self.away
	if self.away == 1:
	    self.np.queue.put(slskmessages.SetStatus(1))
	    self.logMessage("Status: Away")
	else:
	    self.np.queue.put(slskmessages.SetStatus(2))
	    self.logMessage("Status: Online")

    def OnSettings(self, event):
	self.configwindow.SetSettings(self.np.config)
	val = self.configwindow.ShowModal()
	if val == wxID_OK:
	    self.np.config.setConfig(self.configwindow.GetSettings())
	    if self.np.transfers is not None:
		self.np.sendNumSharedFoldersFiles()	    
	    self.np.config.writeConfig()
	    if not self.np.config.needConfig():
	        if not self.mainmenu.IsEnabled(self.disconnectID):
		    self.mainmenu.Enable(self.connectID,1)
		server = self.np.config.sections["server"]["server"]
	        self.serverstring = '%s:%s'%(server[0],server[1])
	        self.mainmenu.SetHelpString(self.connectID,'Connect to '+self.serverstring)
	        self.mainmenu.SetHelpString(self.disconnectID,'Disconnect from '+self.serverstring)

    def OnAbout(self, event):
	about.About(self, -1, "About PySoulSeek").ShowModal()

    def ConnectError(self,msg):
        self.mainmenu.Enable(self.connectID,1)
        self.mainmenu.Enable(self.disconnectID,0)
	self.mainmenu.Enable(self.checkprivID,0)
	self.mainmenu.Enable(self.awayID,0)

    def ConnClose(self,msg):
        self.mainmenu.Enable(self.connectID,1)
        self.mainmenu.Enable(self.disconnectID,0)
        self.mainmenu.Enable(self.checkprivID,0)
        self.mainmenu.Enable(self.awayID,0)
        self.nb.DeleteAllPages()

    def logMessage(self, msg, debug = None):
	if (debug is None or self.mainmenu.IsChecked(self.debugID)):
	    wxLogMessage(msg)

    def InitInterface(self, msg):
            privatechat = chat.PrivateChatNotebook(self.nb, -1,self.np.queue,self.np)
            chatrooms = chat.ChatRooms(self.nb, -1,self.np.queue,privatechat,self.np.peerconns, self)
            globallist = chat.GlobalUsersList(self.nb, -1,self.np.queue,privatechat,self.np.peerconns, self)
            userinfo = userinfobrowse.UserNotebook(self.nb, -1, self.np.queue, userinfobrowse.UserInfoWindow, self)
            userbrowse = userinfobrowse.UserNotebook(self.nb, -1, self.np.queue, userinfobrowse.UserBrowseWindow, self)
            searchw = search.SearchWindow(self.nb, -1, self.np.queue, self.np.ProcessRequestToPeer, privatechat, userinfo, userbrowse, self.np.transfers,self.OnPageUpdated,self)
            downloads = transfers.TransfersPanel(self.nb, -1, self.np.transfers.downloads, self.np, self.np.transfers)
	    uploads = transfers.TransfersPanel(self.nb, -1, self.np.transfers.uploads, self.np, self.np.transfers)

            self.nb.AddPage(chatrooms,"Chat Rooms")
            self.nb.AddPage(privatechat,"Private Chat")
#            self.nb.AddPage(globallist,"Global Users List")
            self.nb.AddPage(downloads,"Downloads")
	    self.nb.AddPage(uploads,"Uploads")
            self.nb.AddPage(searchw, "Search Files")
            self.nb.AddPage(userinfo,"User Info")
            self.nb.AddPage(userbrowse,"User Browse")

	    self.page = 0
	    self.pages = {chatrooms:0,privatechat:1,downloads:2,uploads:3,searchw:4,userinfo:5,userbrowse:6}

            self.imglist = wxImageList(18,18)
            self.offline = self.imglist.Add(images.getOnlineBitmap())
            self.nb.AssignImageList(self.imglist)
#	    self.nb.SetPageImage(0,0)
            self.mainmenu.Enable(self.checkprivID,1)
	    self.mainmenu.Enable(self.awayID,1)


            chatrooms.roomsctrl.SetGreeting(msg.banner)
	    return privatechat,chatrooms,userinfo,userbrowse,searchw,downloads,uploads

    def InitUserList(self,list):
	list.sort()
	self.userlist = [[i,0] for i in list]
	for i in list:
	    self.np.queue.put(slskmessages.GetUserStatus(i))

    def AddToList(self,user):
        if user not in [i[0] for i in self.userlist]:
            self.np.queue.put(slskmessages.GetUserStatus(user))
            self.userlist.append([user,0])


    def GetUserStatus(self,msg):
	for i in self.userlist:
	   if i[0] == msg.user:
        	i[1] = msg.status
                if self.userlistpanel is not None:
                   self.userlistpanel.update()
		break
 

    def OnPageChanged(self, event):
	self.page = event.GetSelection()
	self.nb.SetPageImage(self.page,-1)

    def OnPageUpdated(self, pageobj):
	if self.pages[pageobj] != self.page:
	    self.nb.SetPageImage(self.pages[pageobj],0)

    def callback(self,msgs):
	""" Callback function called by networking thread."""
	curtime = time.time()
	for i in msgs[:]:
	    if i.__class__ is slskmessages.DownloadFile or i.__class__ is slskmessages.UploadFile:
		self.transfermsgs[i.conn] = i
		msgs.remove(i)
	    if i.__class__ is slskmessages.ConnClose:
		msgs = self.postTransferMsgs(msgs,curtime)
	if curtime-self.transfermsgspostedtime > 1.0:
		msgs = self.postTransferMsgs(msgs,curtime)
	if len(msgs) > 0:
	    wxPostEvent(self, NetworkEvent(self.EVT_NETWORK_ID,msgs))

    def postTransferMsgs(self,msgs,curtime):
	trmsgs = []
        for i in self.transfermsgs.keys():
            trmsgs.append(self.transfermsgs[i])
	msgs = trmsgs+msgs
        self.transfermsgs = {}
        self.transfermsgspostedtime = curtime
	return msgs


    def OnNetworkEvent(self, event):
	""" Processes messages from networking thread."""
	for i in event.msgs:
	    if self.np.events.has_key(i.__class__):
		self.np.events[i.__class__](i)
	    else:
		self.logMessage("No handler for class %s %s" % (i.__class__, vars(i)))

    def EVT_NETWORK(self, win, id, func):
	""" Network event macro """
	win.Connect(-1, -1, id, func) 

class MainApp(wxApp): 
    """ Application class. """
    def OnInit(self):
	wxInitAllImageHandlers()
        self.frame = MainFrame(None,-1,'PySoulSeek') 
        self.frame.Show(true) 
        self.SetTopWindow(self.frame) 
        return true 


