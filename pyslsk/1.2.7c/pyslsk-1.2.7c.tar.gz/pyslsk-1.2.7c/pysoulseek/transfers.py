# Copyright (c) 2001-2003 Alexander Kanavin. All rights reserved.

""" This module contains classes that deal with file transfers: the 
transfer manager.
"""

import slskmessages
import threading
from slskmessages import newId
import os,stat
import os.path
import pysoulseek
import string
import time
import mp3
import locale
import utils
import md5

class Transfer:
    """ This class holds information about a single transfer. """
    def __init__(self, conn = None, user = None, filename = None, path = None, status = None, req=None, size = None, file = None, starttime = None, offset = None, currentbytes = None, speed = None,timeelapsed = None, timeleft = None, timequeued = None, transfertimer = None, requestconn = None):
	self.user = user
	self.filename = filename
	self.conn = conn
	self.path = path
	self.status = status
	self.req = req
	self.size = size
	self.file = file
	self.starttime = starttime
	self.offset = offset
	self.currentbytes = currentbytes
	self.speed = speed
	self.timeelapsed = timeelapsed
	self.timeleft = timeleft
	self.timequeued = timequeued
	self.transfertimer = transfertimer
	self.requestconn = None

class TransferTimeout:
    def __init__(self, req, callback):
        self.req = req
        self.callback = callback

    def timeout(self):
        self.callback([self])


class Transfers:
    """ This is the transfers manager"""
    def __init__(self, downloads, peerconns, queue, eventprocessor, users):
	self.peerconns = peerconns
	self.queue = queue
	self.eventprocessor = eventprocessor
	self.downloads = []
	self.uploads = []
	self.privilegedusers = []
	getstatus = {}
	for i in downloads:
	    self.downloads.append(Transfer(user = i[0], filename=i[1], path=i[2], status = 'Getting status'))
	    getstatus[i[0]] = ""
	for i in getstatus.keys():
	    self.queue.put(slskmessages.GetUserStatus(i))
	self.SaveDownloads()
	self.users = users
	self.downloadspanel = None
	self.uploadspanel = None

# queue sizes
	self.privcount = 0
	self.oggcount = 0
	self.usersqueued = {}
	self.privusersqueued = {}
	self.oggusersqueued = {}
 
    def setTransferPanels(self, downloads, uploads):
	self.downloadspanel = downloads
	self.uploadspanel = uploads

    def setPrivilegedUsers(self, list):
	for i in list:
	    self.addToPrivileged(i)    

    def addToPrivileged(self, user):
	self.privilegedusers.append(user)
	if self.oggusersqueued.has_key(user):
	    self.privusersqueued.setdefault(user,0)
	    self.privusersqueued[user] += self.oggusersqueued[user]
	    self.privcount += self.oggusersqueued[user]
	    self.oggcount -= self.oggusersqueued[user]
	    del self.oggusersqueued[user]
	if self.usersqueued.has_key(user):
	    self.privusersqueued.setdefault(user,0)
            self.privusersqueued[user] += self.usersqueued[user]
	    self.privcount += self.usersqueued[user]
	    del self.usersqueued[user]

    def getAddUser(self,msg):
	""" Server tells us it'll notify us about a change in user's status """
	if not msg.userexists:
	    self.eventprocessor.logMessage("User %s does not exist" % (msg.user))

    def GetUserStatus(self,msg):
	""" We get a status of a user and if he's online, we request a file from 	him """
	for i in self.downloads:
	    if msg.user == i.user and i.status in ['Queued', 'Getting status', 'User logged off', 'Connection closed by peer', 'Aborted', 'Cannot connect']:
		if msg.status != 0:
		    if i.status not in ['Queued', 'Aborted', 'Cannot connect']:
                        self.getFile(i.user, i.filename, i.path, i)
	        else:
		    if i.status not in ['Aborted']:
                        i.status = "User logged off"
		        self.downloadspanel.update(i)    

        for i in self.uploads[:]:
            if msg.user == i.user and i.status != 'Finished':
                if msg.status != 0:
		    if i.status == 'Getting status':
                        self.pushFile(i.user, i.filename, i.path, i)
                else:
		    if i.transfertimer is not None:
			i.transfertimer.cancel()
                    self.uploads.remove(i)
		    self.uploadspanel.update()
	if msg.status == 0:
	    self.checkUploadQueue()


    def getFile(self, user, filename, path="", transfer = None):
	self.transferFile(0,user,filename,path,transfer)

    def pushFile(self, user, filename, path="", transfer = None):
        self.transferFile(1,user,filename,path,transfer)

    def transferFile(self, direction, user, filename, path="", transfer = None):
	""" Get a single file. path is a local path. if transfer object is 
	not None, update it, otherwise create a new one."""
        if transfer is None:
	    transfer = Transfer(user = user, filename= filename, path=path, status = 'Getting status')
            if direction == 0:
                self.downloads.append(transfer)
                self.SaveDownloads()
            else:
                self.uploads.append(transfer)
        else:
            transfer.status = 'Getting status'
        if self.users.has_key(user):
	    status = self.users[user].status
	else:
	    status = None
	if status is None:
	    self.queue.put(slskmessages.GetUserStatus(user))
	else:
	    transfer.req = newId()
	    self.eventprocessor.ProcessRequestToPeer(user,slskmessages.TransferRequest(None,direction,transfer.req,filename, self.getFileSize(filename)))
	if direction == 0:
   	    self.downloadspanel.update(transfer)
	else:
            self.uploadspanel.update(transfer)


    def UploadFailed(self,msg):
        for i in self.peerconns:
            if i.conn is msg.conn.conn:
                user = i.username
		break
	else:
	    return
	for i in self.downloads:
	    if i.user == user and i.filename == msg.file and (i.conn is not None or i.status in ["Connection closed by peer", "Establishing connection"]):
		self.AbortTransfer(i)
		self.getFile(i.user, i.filename, i.path, i)
		self.eventprocessor.logMessage("Retrying failed download: user %s, file %s" %(i.user,i.filename))
		break
	else:
	    self.eventprocessor.logMessage("Failed download: user %s, file %s" %(user,msg.file))

    def gettingAddress(self, req):
	for i in self.downloads:
	    if i.req == req:
		i.status = "Getting address"
                self.downloadspanel.update(i)
        for i in self.uploads:
            if i.req == req:
                i.status = "Getting address"
                self.uploadspanel.update(i)

    def gotAddress(self, req):
	""" A connection is in progress, we got the address for a user we need
	to connect to."""
	for i in self.downloads:
	    if i.req == req:
		i.status = "Connecting"
                self.downloadspanel.update(i)
        for i in self.uploads:
            if i.req == req:
                i.status = "Connecting"
                self.uploadspanel.update(i)


    def gotConnectError(self,req):
	""" We couldn't connect to the user, now we are waitng for him to 
	connect to us. Note that all this logic is handled by the network
	event processor, we just provide a visual feedback to the user."""
	for i in self.downloads:
	    if i.req == req:
		i.status = "Waiting for peer to connect"
                self.downloadspanel.update(i)
        for i in self.uploads:
            if i.req == req:
                i.status = "Waiting for peer to connect"
                self.uploadspanel.update(i)

    def gotCantConnect(self,req):
	""" We can't connect to the user, either way. """
	for i in self.downloads:
	    if i.req == req:
		i.status = "Cannot connect"
		i.req = None
                self.downloadspanel.update(i)
		self.queue.put(slskmessages.GetUserStatus(i.user))
        for i in self.uploads:
            if i.req == req:
                i.status = "Cannot connect"
		i.req = None
		curtime = time.time()
                for j in self.uploads:
                    if j.user == i.user:
                        j.timequeued = curtime
                self.uploadspanel.update(i)
		self.queue.put(slskmessages.GetUserStatus(i.user))
		self.checkUploadQueue()


    def gotFileConnect(self, req, conn):
	""" A transfer connection has been established, 
	now exchange initialisation messages."""
	for i in self.downloads:
	    if i.req == req:
		i.status = "Initializing transfer"
		self.downloadspanel.update(i)
	for i in self.uploads:
            if i.req == req:
                i.status = "Initializing transfer"
                self.uploadspanel.update(i)

    def gotConnect(self, req, conn):
	""" A connection has been established, now exchange initialisation
	messages."""
	for i in self.downloads:
	    if i.req == req:
		i.status = "Requesting file"
		i.requestconn = conn
		self.downloadspanel.update(i)
	for i in self.uploads:
            if i.req == req:
                i.status = "Requesting file"
		i.requestconn = conn
                self.uploadspanel.update(i)


    def TransferRequest(self,msg):
	if msg.conn is not None:
            for i in self.peerconns:
                if i.conn is msg.conn.conn:
	    	    user = i.username
		    conn = msg.conn.conn
		    break
	elif msg.tunneleduser is not None:
	    user = msg.tunneleduser
	    conn = None
	if user is None:
	    self.eventprocessor.logMessage("Got transfer request:", vars(msg),"but cannot determine requestor",1)
	    return
	
	if msg.direction == 1:
	    for i in self.downloads:
		if i.filename == msg.file and user == i.user and i.status == "Queued":
		    i.size = msg.filesize
		    i.req = msg.req
		    i.status = "Waiting for download"
		    transfertimeout = TransferTimeout(i.req, self.eventprocessor.frame.callback)
		    if i.transfertimer is not None:
			i.transfertimer.cancel()
		    i.transfertimer = threading.Timer(30.0, transfertimeout.timeout)
		    i.transfertimer.start()
		    response = slskmessages.TransferResponse(conn,1,req = i.req)
                    self.downloadspanel.update(i)
		    break
	    else:
		response = slskmessages.TransferResponse(conn,0,reason = "Cancelled", req = msg.req)
		self.eventprocessor.logMessage("Denied file request: "+str(vars(msg)),1)
	else:
	    if user in self.eventprocessor.config.sections["server"]["banlist"]:
	        if self.eventprocessor.config.sections["transfers"]["usecustomban"]:
	            banmsg = "Banned (%s)" % self.eventprocessor.config.sections["transfers"]["customban"]
	        else:
	            banmsg = "Banned"
	        response = slskmessages.TransferResponse(conn,0,reason = banmsg,req=msg.req)
	    elif not self.fileIsShared(msg.file):
		response = slskmessages.TransferResponse(conn,0,reason = "File not shared", req = msg.req)
	    elif self.fileIsQueued(user, msg.file):
		response = slskmessages.TransferResponse(conn,0,reason = "Queued", req = msg.req)
	    elif self.queueLimitReached(user):
	        uploadslimit = self.eventprocessor.config.sections["transfers"]["queuelimit"]
		response = slskmessages.TransferResponse(conn,0,reason = "Limit of %i megabytes exceeded" %(uploadslimit), req = msg.req)
	    elif user in self.getTransferringUsers() or self.bandwidthLimitReached() or self.transferNegotiating():
		response = slskmessages.TransferResponse(conn,0,reason = "Queued", req = msg.req)
		self.uploads.append(Transfer(user = user, filename = msg.file, path = os.path.dirname(msg.file.replace('\\','/')), status = "Queued", timequeued = time.time(), size = self.getFileSize(msg.file)))
		self.uploadspanel.update(self.uploads[-1])
		self.addQueued(user, msg.file)
	    else:
		size = self.getFileSize(msg.file)
		response = slskmessages.TransferResponse(conn,1,req = msg.req, filesize = size)
                transfertimeout = TransferTimeout(msg.req, self.eventprocessor.frame.callback) 
		self.uploads.append(Transfer(user = user, filename = msg.file, path = os.path.dirname(msg.file.replace('\\','/')), status = "Waiting for upload", req = msg.req, size = size))
                self.uploads[-1].transfertimer = threading.Timer(30.0, transfertimeout.timeout)
		self.uploads[-1].transfertimer.start()
		self.uploadspanel.update(self.uploads[-1])
	    self.eventprocessor.logMessage("Upload request: " +str(vars(msg)),1)

        if msg.conn is not None:
            self.queue.put(response)
        else:
            self.eventprocessor.ProcessRequestToPeer(user,response)

    def fileIsQueued(self, user, file):
	for i in self.uploads:
            if i.user == user and i.filename == file and i.status == 'Queued':
		return 1
	return 0

    def queueLimitReached(self, user):
	uploadslimit = self.eventprocessor.config.sections["transfers"]["queuelimit"]*1024*1024
	size = sum([i.size for i in self.uploads \
                    if i.user == user and i.status == 'Queued'])
	return size >= uploadslimit

    def QueueUpload(self, msg):
        for i in self.peerconns:
            if i.conn is msg.conn.conn:
                user = i.username
		break
	if not self.fileIsQueued(user, msg.file):
            if user in self.eventprocessor.config.sections["server"]["banlist"]:
                if self.eventprocessor.config.sections["transfers"]["usecustomban"]:
                    banmsg = "Banned (%s)" % self.eventprocessor.config.sections["transfers"]["customban"]
                else:
                    banmsg = "Banned"
		self.queue.put(slskmessages.QueueFailed(conn = msg.conn.conn, file = msg.file, reason = banmsg))
            elif self.queueLimitReached(user):
                uploadslimit = self.eventprocessor.config.sections["transfers"]["queuelimit"]
		limitmsg = "Limit of %i megabytes exceeded" %(uploadslimit)
                self.queue.put(slskmessages.QueueFailed(conn = msg.conn.conn, file = msg.file, reason = limitmsg)) 
 	    elif self.fileIsShared(msg.file):
	        self.uploads.append(Transfer(user = user, filename = msg.file, path = os.path.dirname(msg.file.replace('\\','/')), status = "Queued", timequeued = time.time(), size = self.getFileSize(msg.file)))
		self.uploadspanel.update(self.uploads[-1])
		self.addQueued(user, msg.file)
	    else:
		self.queue.put(slskmessages.QueueFailed(conn = msg.conn.conn, file = msg.file, reason = "File not shared."))
        self.eventprocessor.logMessage("Queued upload request: " +str(vars(msg)),1)
	self.checkUploadQueue()


    def QueueFailed(self, msg):
        for i in self.peerconns:
            if i.conn is msg.conn.conn:
                user = i.username
		break
        for i in self.downloads:
            if i.user == user and i.filename == msg.file and i.status == 'Queued':
		i.status = msg.reason
		self.downloadspanel.update(i)
                break


    def fileIsShared(self, filename):
	filename = filename.replace("\\","/")
	if not os.access(filename, os.R_OK): return 0
	dir = os.path.dirname(filename)
	file = os.path.basename(filename)
	shared = self.eventprocessor.config.sections["transfers"]["sharedfiles"]
	for i in shared.get(dir, ''):
	    if file == i[0]: return 1
	return 0

    def getTransferringUsers(self):
	return [i.user for i in self.uploads if i.req is not None or i.conn is not None or i.status == 'Getting status'] #some file is being transfered

    def transferNegotiating(self):
        for i in self.uploads:
            if i.req is not None \
               or (i.conn is not None and i.speed is None) \
               or i.status == 'Getting status':
               #some file is being negotiated
               return 1
        return 0

	return len([i for i in self.uploads if i.req is not None or (i.conn is not None and i.speed is None) or i.status == 'Getting status']) > 0 #some file is being negotiated

    def bandwidthLimitReached(self):
	maxbandwidth = self.eventprocessor.config.sections["transfers"]["uploadbandwidth"]
	bandwidthlist = [i.speed for i in self.uploads if i.conn is not None and i.speed is not None]
	return sum(bandwidthlist) > maxbandwidth

    def getFileSize(self,filename):
	try:
	    size = os.path.getsize(filename.replace("\\","/"))
	except:
	    size = 0
	return size

    def TransferResponse(self,msg):
	""" Got a response to the file request from the peer."""
	if msg.reason != None:
	    for i in (self.downloads+self.uploads)[:]:
		if i.req == msg.req:
		    i.status = msg.reason
		    i.req = None
		    self.downloadspanel.update(i)
		    self.uploadspanel.update(i)
		    if msg.reason == "Queued":
			if i.user not in self.users or self.users[i.user].status is None:
		            self.queue.put(slskmessages.GetUserStatus(i.user))
		        if i in self.uploads:
			    if i.transfertimer is not None:
				i.transfertimer.cancel()
			    self.uploads.remove(i)
			    self.uploadspanel.update()
		    self.checkUploadQueue()
	elif msg.filesize != None:
	    for i in self.downloads:
		if i.req == msg.req:
                    i.size = msg.filesize
                    i.status = "Establishing connection"
                    #Have to establish 'F' connection here
                    self.eventprocessor.ProcessRequestToPeer(i.user,slskmessages.FileRequest(None,msg.req))
		    self.downloadspanel.update(i)
		    break
	else:
	    for i in self.uploads:
		if i.req == msg.req:
		    i.status = "Establishing connection"
 		    self.eventprocessor.ProcessRequestToPeer(i.user,slskmessages.FileRequest(None,msg.req))
		    self.uploadspanel.update(i)
		    break
	    else:
		self.eventprocessor.logMessage("Got unknown transfer response: " + str(vars(msg)),1)

    def TransferTimeout(self, msg):
        for i in (self.downloads+self.uploads)[:]:
            if i.req == msg.req:
                i.status = "Cannot connect"
                i.req = None
		self.queue.put(slskmessages.GetUserStatus(i.user))
                self.downloadspanel.update(i)
                self.uploadspanel.update(i)
	self.checkUploadQueue()

    def FileRequest(self, msg):
	""" Got an incoming file request. Could be an upload request or a 
	request to get the file that was previously queued"""

	downloaddir = self.eventprocessor.config.sections["transfers"]["downloaddir"]
	for i in self.downloads:
	    if msg.req == i.req and i.conn is None and i.size is not None:
		i.conn = msg.conn
		i.req = None
		if i.transfertimer is not None:
                    i.transfertimer.cancel()
		try:
		    folder = os.path.join(downloaddir,i.path)
		    if not os.access(folder,os.F_OK):
		        os.makedirs(folder)
			print folder
		except OSError, (errno, strerror):
		    self.eventprocessor.logMessage("OS error(%s): %s" % (errno, strerror))
		    i.status = "Download directory error"
		    i.conn = None
		    self.queue.put(slskmessages.ConnClose(msg.conn))
		else: 
                  # also check for a windows-style incomplete transfer
		  basename = string.split(i.filename,'\\')[-1]
                  winfname = os.path.join(downloaddir,i.path,"INCOMPLETE~"+basename)
                  pyfname  = os.path.join(downloaddir,i.path,"INCOMPLETE"+basename)
		  pynewfname = os.path.join(downloaddir,i.path,"INCOMPLETE"+md5.new(i.filename+i.user).hexdigest()+basename)
		  try:
                    if os.access(winfname,os.F_OK):
                        fname = winfname
                    elif os.access(pyfname,os.F_OK):
                        fname = pyfname
		    else:
			fname = pynewfname
                    f = open(fname,'ab+')
                  except IOError, (errno, strerror):
                    self.eventprocessor.logMessage("I/O error(%s): %s" % (errno, strerror))
                    i.status = "Local file error"
                    try:
                        f.close()
                    except:
                        pass
                    i.conn = None
                    self.queue.put(slskmessages.ConnClose(msg.conn))
		  else:
		    import fcntl
		    try:
		        fcntl.lockf(f, fcntl.LOCK_EX|fcntl.LOCK_NB)
		    except IOError, (errno, strerror):
			self.eventprocessor.logMessage("Can't get an exclusive lock on file - I/O error(%s): %s" % (errno, strerror))
                    f.seek(0,2)
		    size = f.tell()
		    self.queue.put(slskmessages.DownloadFile(i.conn,size,f,i.size))
		    i.currentbytes = size
                    i.status = "%s" %(str(i.currentbytes))
                    i.file = f
		    i.offset = size
		    i.starttime = time.time()
		    self.eventprocessor.logMessage("Download started: %s" %(f.name))

                self.downloadspanel.update(i)
		return
         
	for i in self.uploads:
            if msg.req == i.req and i.conn is None:
                i.conn = msg.conn
		i.req = None
                if i.transfertimer is not None:
                    i.transfertimer.cancel()
                try:
		    f = open(i.filename.replace("\\","/"),"rb")
		    self.queue.put(slskmessages.UploadFile(i.conn,file = f,size =i.size))
		    i.status = "Initializing transfer"
		    i.file = f
                except IOError, (errno, strerror):
		    self.eventprocessor.logMessage("I/O error(%s): %s" % (errno, strerror))
                    i.status = "Local file error"
                    try:
                        f.close()
                    except:
                        pass
                    i.conn = None
                    self.queue.put(slskmessages.ConnClose(msg.conn))
                self.uploadspanel.update(i)
                break
	else:
	    self.eventprocessor.logMessage("Unknown file request: " +str(vars(msg)),1)
	    self.queue.put(slskmessages.ConnClose(msg.conn))

    def FileDownload(self, msg):
	""" A file download is in progress"""
	needupdate = 1

	for i in self.downloads:
	    if i.conn == msg.conn:
		    try:
			curtime = time.time()
                        i.currentbytes = msg.file.tell()
                        i.status = "%s" %(str(i.currentbytes))
			oldelapsed = i.timeelapsed
	                i.timeelapsed = self.getTime(curtime - i.starttime)
			if curtime > i.starttime and i.currentbytes > i.offset:
			    i.speed = (i.currentbytes - i.offset)/(curtime - i.starttime)/1024
	                    i.timeleft = self.getTime((i.size - i.currentbytes)/i.speed/1024)
		        if i.size > i.currentbytes:
			    if oldelapsed == i.timeelapsed:
				needupdate = 0
			    i.status = locale.format("%s",i.currentbytes,1)
			else:
		            msg.file.close()
			    basename = string.split(i.filename,'\\')[-1]
			    newname = self.getRenamed(os.path.join(os.path.dirname(msg.file.name),basename))
		            os.rename(msg.file.name,newname)
		            i.status = "Finished"
			    self.eventprocessor.logMessage("Download finished: %s" %(newname))
			    self.queue.put(slskmessages.ConnClose(msg.conn))
			    if i.speed is not None:
			        self.queue.put(slskmessages.SendSpeed(i.user, int(i.speed*1024)))
			    i.conn = None
			    self.addToShared(newname)
			    self.eventprocessor.sendNumSharedFoldersFiles()
			    self.SaveDownloads()
			    self.downloadspanel.update(i)
		    except IOError, (errno, strerror):
			self.eventprocessor.logMessage("I/O error(%s): %s" % (errno, strerror))
                        i.status = "Local file error"
	                try:
	                    msg.file.close()
	                except:
	                    pass
	                i.conn = None
	                self.queue.put(slskmessages.ConnClose(msg.conn))
		    if needupdate:
		        self.downloadspanel.update(i)
    
    def addToShared(self, name):
	if self.eventprocessor.config.sections["transfers"]["sharedownloaddir"]:
	    shared = self.eventprocessor.config.sections["transfers"]["sharedfiles"]
	    sharedstreams = self.eventprocessor.config.sections["transfers"]["sharedfilesstreams"]
	    wordindex = self.eventprocessor.config.sections["transfers"]["wordindex"]
	    fileindex = self.eventprocessor.config.sections["transfers"]["fileindex"]
	    shareddirs = self.eventprocessor.config.sections["transfers"]["shared"] + [self.eventprocessor.config.sections["transfers"]["downloaddir"]]
	    sharedmtimes = self.eventprocessor.config.sections["transfers"]["sharedmtimes"]
            dir = os.path.dirname(name)
            file = os.path.basename(name)
	    size = os.path.getsize(name)

	    shared[dir] = shared.get(dir, [])
	    if file not in [i[0] for i in shared[dir]]:
		fileinfo = utils.getFileInfo(file,name)
		shared[dir] = shared[dir] + [fileinfo]
		sharedstreams[dir] = utils.getDirStream(shared[dir])
		words = utils.getIndexWords(dir,file, shareddirs)
		self.addToIndex(wordindex, fileindex, words, dir, fileinfo)
		sharedmtimes[dir] = os.path.getmtime(dir) 
	        self.eventprocessor.config.writeShares()
		

    def addToIndex(self, wordindex, fileindex, words, dir, fileinfo):
	index = len(fileindex.keys())
	for i in words:
	    if not wordindex.has_key(i):
		wordindex[i] = [index]
	    else:
		wordindex[i] = wordindex[i] + [index]
	fileindex[str(index)] = (os.path.join(dir,fileinfo[0]),)+fileinfo[1:]

    def FileUpload(self,msg):
        """ A file upload is in progress"""
	needupdate = 1

        for i in self.uploads:
            if i.conn == msg.conn:
		curtime = time.time()
		if i.starttime is None:
		    i.starttime = curtime
		    i.offset = msg.offset
		i.currentbytes = msg.offset + msg.sentbytes
		oldelapsed = i.timeelapsed
		i.timeelapsed = self.getTime(curtime - i.starttime)
		if curtime > i.starttime and i.currentbytes > i.offset:
		    i.speed = (i.currentbytes - i.offset)/(curtime - i.starttime)/1024
		    i.timeleft = self.getTime((i.size - i.currentbytes)/i.speed/1024)
		    self.checkUploadQueue()
		if i.size > i.currentbytes:
		    if oldelapsed == i.timeelapsed:
			needupdate = 0
                    i.status = locale.format("%s",i.currentbytes,1)
                    if i.user in self.privilegedusers:
                        i.status = i.status + " (privileged)"
		    if self.UserListPrivileged(i.user):
			i.status = i.status + " (friend)"
		else:
                    msg.file.close()
                    i.status = "Finished"
#                    i.conn = None
#		    self.queue.put(slskmessages.ConnClose(msg.conn))
		    for j in self.uploads:
			if j.user == i.user:
			    j.timequeued = curtime
		    self.checkUploadQueue()
		    self.uploadspanel.update(i)
		if needupdate:
                    self.uploadspanel.update(i)

    def BanUser(self, user):
        if self.eventprocessor.config.sections["transfers"]["usecustomban"]:
            banmsg = "Banned (%s)" % self.eventprocessor.config.sections["transfers"]["customban"]
        else:
            banmsg = "Banned"

    	list = [i for i in self.uploads if i.user == user]
        for upload in list:
	    if upload.status == "Queued":
		self.eventprocessor.ProcessRequestToPeer(user,slskmessages.QueueFailed(None,file = upload.filename, reason = banmsg))
	    else:
                self.AbortTransfer(upload)
        if self.uploadspanel is not None:
	    self.uploadspanel.ClearByUser(user)
        if user not in self.eventprocessor.config.sections["server"]["banlist"]:
            self.eventprocessor.config.sections["server"]["banlist"].append(user)
            self.eventprocessor.config.writeConfig()


    def checkUploadQueue(self):
	if self.bandwidthLimitReached() or self.transferNegotiating():
	    return
	transfercandidate = None
	trusers = self.getTransferringUsers()
	list = [i for i in self.uploads if i.status == "Queued" and not i.user in trusers]
	if len(list) == 0:
	    return
	listprivileged = [i for i in list if i.user in self.privilegedusers or self.UserListPrivileged(i.user)]
	if len(listprivileged) > 0:
	    list = listprivileged
	else:
	    listogg = [i for i in list if i.filename[-4:].lower() == ".ogg"]
            if len(listogg) > 0:
                list = listogg
	mintimequeued = time.time() + 1
	for i in list:
	    if i.timequeued < mintimequeued:
		transfercandidate = i
		mintimequeued = i.timequeued
	if transfercandidate is not None:
	    self.pushFile(user = transfercandidate.user, filename = transfercandidate.filename, transfer = transfercandidate)
	    self.removeQueued(transfercandidate.user, transfercandidate.filename)

    def PlaceInQueueRequest(self, msg):
        """The place in queue is determined as follows:

        First, we determine certain properties of the upload in
        question: whether it's initiated by a privileged user, whether
        it's a request for an .ogg-file, and the time it has been
        queued.

        Then we go through the list of queued uploads and count all
        those that have a higher priority than the upload in
        question.  Priority is determined as follows: privileged, then
        .ogg, then others, and within each category first come, first
        served."""

        for i in self.peerconns:
            if i.conn is msg.conn.conn:
                user = i.username
		break	
	for i in self.uploads:
	    if i.user == user:
		timequeued = i.timequeued
		break
	else:
	    timequeued = time.time()
	privileged = user in self.privilegedusers or self.UserListPrivileged(user)
	ogg = msg.file[-4:].lower() == ".ogg"
	place = 1

        # The following code should be equivalent to this, but more
        # efficient, as a larger number of decisions is made outside
        # the loop.  Also, the common case will not have to look
        # inside self.privilegedusers:
        # for i in self.uploads:
        #     if i.status == "Queued":
        #        if i.user in self.privilegedusers \
        #               or self.UserListPrivileged(i.user):
        #            place += not privileged or (i.timequeued < timequeued)
        #        elif i.filename[-4:].lower() == ".ogg":
        #            place += not ogg or (i.timequeued < timequeued)
        #        elif i.timequeued < timequeued:
        #            place += 1

        if not privileged and not ogg:
            for i in self.uploads:
                if i.status == "Queued" \
	                and (i.timequeued < timequeued \
			or i.filename[-4:].lower() == ".ogg" \
                        or i.user in self.privilegedusers \
                        or self.UserListPrivileged(i.user)):
                    place += 1
        elif privileged: # ogg or not doesn't make a difference
            for i in self.uploads:
                if i.status == "Queued" \
	                and i.timequeued < timequeued \
	                and (i.user in self.privilegedusers \
        	        or self.UserListPrivileged(i.user)):
                    place += 1
        else: # ogg and not privileged
            for i in self.uploads:
                if i.status == "Queued" \
                   	and ((i.timequeued < timequeued \
                        and i.filename[-4:].lower() == ".ogg") \
                        or i.user in self.privilegedusers \
                        or self.UserListPrivileged(i.user)):
                    place += 1

	self.queue.put(slskmessages.PlaceInQueue(msg.conn.conn, msg.file, place))

    def getTime(self,seconds):
	sec = int(seconds % 60)
	minutes = int(seconds / 60 % 60)
	hours = int(seconds / 3600 % 24)
	days = int(seconds/86400)
	
	time = "%02d:%02d:%02d" %(hours, minutes, sec)
	if days > 0:
	    time = str(days) + "." + time
	return time

    def calcUploadQueueSizes(self):
# queue sizes
        self.privcount = 0
        self.oggcount = 0
        self.usersqueued = {}
        self.privusersqueued = {}
        self.oggusersqueued = {}

	for i in self.uploads:
	    if i.status == "Queued":
		self.addQueued(i.user, i.filename)

    def getUploadQueueSizes(self, username = None):
	if username in self.privilegedusers or self.UserListPrivileged(username):
	    return len(self.privusersqueued), len(self.privusersqueued)
	else:
	    return len(self.usersqueued)+self.privcount+self.oggcount, len(self.oggusersqueued)+self.privcount

    def addQueued(self, user, filename):
# inaccurate - privieged userlist users are counted as ordinary ones
        if user in self.privilegedusers:
            self.privusersqueued.setdefault(user,0)
            self.privusersqueued[user] += 1
            self.privcount += 1
        elif filename[-4:].lower() == ".ogg":
            self.oggusersqueued.setdefault(user,0)
            self.oggusersqueued[user] += 1
            self.oggcount += 1
        else:
            self.usersqueued.setdefault(user,0)
            self.usersqueued[user] += 1

    def removeQueued(self, user, filename):
        if user in self.privilegedusers:
            self.privusersqueued[user] -= 1
            self.privcount -= 1
	    if self.privusersqueued[user] == 0:
		del self.privusersqueued[user]
        elif filename[-4:].lower() == ".ogg":
            self.oggusersqueued[user] -= 1
            self.oggcount -= 1
	    if self.oggusersqueued[user] == 0:
		del self.oggusersqueued[user]
        else:
            self.usersqueued[user] -= 1
	    if self.usersqueued[user] == 0:
                del self.usersqueued[user]

    def getTotalUploadsAllowed(self):
	list = [i for i in self.uploads if i.conn is not None]
	if self.bandwidthLimitReached():
	    return len(list)
	else:
	    return len(list)+1
	    

    def UserListPrivileged(self, user):
	userlist = [i[0] for i in self.eventprocessor.config.sections["server"]["userlist"]]
	if user not in userlist:
	    return 0
	if self.eventprocessor.config.sections["server"]["userlist"][userlist.index(user)][3]:
	   return 1
	else:
	   return 0

    def ConnClose(self, conn, addr):
	""" The remote user has closed the connection either because
	he logged off, or because there's a network problem."""
	for i in self.downloads + self.uploads:
	    if i.requestconn == conn and i.status == 'Requesting file':
		i.requestconn = None
		i.status = "Connection closed by peer"
		i.req = None
                self.downloadspanel.update(i)
                self.uploadspanel.update(i)
                self.checkUploadQueue()
	    if i.conn == conn:
		if i.file is not None:
		    i.file.close()
		if i.status != "Finished":
		    if self.users.has_key(i.user) and self.users[i.user].status == 0:
		        i.status = "User logged off"
		    else:
		        i.status = "Connection closed by peer"
		i.conn = None
       	        self.downloadspanel.update(i)
	        self.uploadspanel.update(i)
	 	self.checkUploadQueue()
		break

    def getRenamed(self,name):
	""" When a transfer is finished, we remove INCOMPLETE~ or INCOMPLETE 
	prefix from the file's name. """
	if not os.path.exists(name):
	    return name
	else:
	    n = 1
	    while n < 1000:
		newname = name+"."+str(n)
		if not os.path.exists(newname):
		    break
		n+=1
	return newname

    def PlaceInQueue(self,msg):
	""" The server tells us our place in queue for a particular transfer."""
	self.eventprocessor.logMessage("File: %s, place in queue: %s" % (string.split(msg.filename,'\\')[-1], msg.place))

    def FileError(self, msg):
	""" Networking thread encountered a local file error"""
	for i in self.downloads+self.uploads:
	    if i.conn == msg.conn.conn:
		i.status = "Local file error"
		try:
		    msg.file.close()
		except:
		    pass
		i.conn = None
		self.queue.put(slskmessages.ConnClose(msg.conn.conn))
		self.eventprocessor.logMessage("I/O error(%s): %s" % (msg.errno, msg.strerror))
                self.downloadspanel.update(i)
                self.uploadspanel.update(i)
		self.checkUploadQueue()


    def FolderContentsResponse(self,msg):
	""" When we got a contents of a folder, get all the files in it, but
	skip the files in subfolders"""
        for i in self.peerconns:
            if i.conn is msg.conn.conn:
                username = i.username
		break
        for i in msg.list.keys():
            for j in msg.list[i].keys():
                if os.path.commonprefix([i,j]) == j:
                    for k in msg.list[i][j]:
			if j[-1] == '\\':
                            self.getFile(username, j + k[1], j.split('\\')[-2])
			else:
			    self.getFile(username, j + '\\' + k[1], j.split('\\')[-1])

    def AbortTransfers(self):
	""" Stop all transfers """
	for i in self.downloads+self.uploads:
	    if i.status != "Finished":
		self.AbortTransfer(i)
		i.status = "User logged off"
#                self.downloadspanel.update()
#                self.uploadspanel.update()


    def AbortTransfer(self,transfer, remove = 0):
	if transfer.conn is not None:
            self.queue.put(slskmessages.ConnClose(transfer.conn))
	    transfer.conn = None
	if transfer.transfertimer is not None:
	    transfer.transfertimer.cancel()
	if transfer.file is not None:
	    try:
		transfer.file.close()
	        if remove:
	    	    os.remove(transfer.file.name)
	    except:
		pass


    def GetDownloads(self):
	""" Get a list of incomplete and not aborted downloads """
	return [ [i.user, i.filename, i.path] for i in self.downloads if i.status not in ('Finished','Aborted')]

    def SaveDownloads(self):
	self.eventprocessor.config.sections["transfers"]["downloads"] = self.GetDownloads()
	self.eventprocessor.config.writeConfig()
