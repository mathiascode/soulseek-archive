# Copyright (c) 2003 Hyriand <hyriand@thegraveyard.org>
pass
