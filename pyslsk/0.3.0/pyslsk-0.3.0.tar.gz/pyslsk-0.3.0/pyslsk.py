#!/usr/bin/env python
# Copyright (c) 2001-2002 Alexander Kanavin. All rights reserved.

"""
Contact info:
ak@sensi.org
"""

from pysoulseek import pysoulseek

if __name__ == '__main__':
    app = pysoulseek.MainApp(0)
    app.MainLoop()

