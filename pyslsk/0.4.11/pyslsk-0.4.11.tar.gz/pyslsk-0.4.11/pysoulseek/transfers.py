# Copyright (c) 2001-2002 Alexander Kanavin. All rights reserved.

""" This module contains classes that deal with file transfers: the 
transfer manager.
"""

import slskmessages
from slskmessages import newId
import os,stat
import pysoulseek
import string
import time
import mp3

class Transfer:
    """ This class holds information about a single transfer. """
    def __init__(self, conn = None, user = None, filename = None, path = None, status = None, req=None, remotereq = None, size = None, file = None, starttime = None, offset = None, currentbytes = None, speed = None,timeelapsed = None, timeleft = None, timequeued = None):
	self.user = user
	self.filename = filename
	self.conn = conn
	self.path = path
	self.status = status
	self.req = req
	self.remotereq = remotereq
	self.size = size
	self.file = file
	self.starttime = starttime
	self.offset = offset
	self.currentbytes = currentbytes
	self.speed = speed
	self.timeelapsed = timeelapsed
	self.timeleft = timeleft
	self.timequeued = timequeued

class Transfers:
    """ This is the transfers manager"""
    def __init__(self, shareddirs, downloaddir, bandwidth, downloads, peerconns, queue, eventprocessor, users):
	self.shareddirs = shareddirs
	self.downloaddir = downloaddir
	self.bandwidth = bandwidth
	self.peerconns = peerconns
	self.queue = queue
	self.eventprocessor = eventprocessor
#	self.sharedfiles = self.buildFileList(self.shareddirs)
	self.downloads = []
	self.uploads = []
	self.privilegedusers = []
	for i in downloads:
	    self.downloads.append(Transfer(user = i[0], filename=i[1], path=i[2], status = 'Getting status'))
	    self.queue.put(slskmessages.GetUserStatus(i[0]))
	self.users = users
	self.downloadspanel = None
	self.uploadspanel = None
 
    def setTransferPanels(self, downloads, uploads):
	self.downloadspanel = downloads
	self.uploadspanel = uploads

    def setPrivilegedUsers(self, list):
	self.privilegedusers = list

    def addToPrivileged(self, user):
	self.privilegedusers.append(user)

    def getAddUser(self,msg):
	""" Server tells us it'll notify us about a change in user's status """
	if not msg.userexists:
	    self.eventprocessor.logMessage("User %s does not exist" % (msg.user))

    def GetUserStatus(self,msg):
	""" We get a status of a user and if he's online, we request a file from 	him """
	for i in self.downloads:
	    if msg.user == i.user and (i.status == 'Queued' or i.status == 'Getting status' or i.status == 'User logged off' or i.status == 'Connection closed by peer' or i.status == 'Aborted'):
		if msg.status != 0:
		    if i.status != 'Queued' and i.status != 'Aborted':
                        self.getFile(i.user, i.filename, i.path, i)
	        else:
                    i.status = "User logged off"
		self.downloadspanel.update()    

        for i in self.uploads[:]:
            if msg.user == i.user and i.status != 'Finished':
                if msg.status != 0:
		    if i.status == 'Getting status':
                        self.pushFile(i.user, i.filename, i.path, i)
                else:
                    self.uploads.remove(i)
		self.uploadspanel.update()
	if msg.status == 0:
	    self.checkUploadQueue()


    def getFile(self, user, filename, path="", transfer = None):
	self.transferFile(0,user,filename,path,transfer)

    def pushFile(self, user, filename, path="", transfer = None):
        self.transferFile(1,user,filename,path,transfer)

    def transferFile(self, direction, user, filename, path="", transfer = None):
	""" Get a single file. path is a local path. if transfer object is 
	not None, update it, otherwise create a new one."""
	if user in self.users.keys():
	    addr = self.users[user].addr
	    behindfw = self.users[user].behindfw
	    status = self.users[user].status
	else:
	    addr = None
	    behindfw = None
	    status = None
	if status is None:
	    if transfer is None:
		if direction == 0:
		    self.downloads.append(Transfer(user = user, filename= filename, path=path, status = 'Getting status'))
		else:
		    self.uploads.append(Transfer(user = user, filename= filename, path=path, status = 'Getting status'))
	    else:
	        transfer.status = 'Getting status'
            self.queue.put(slskmessages.GetUserStatus(user))
	    self.downloadspanel.update()
	    self.uploadspanel.update()
	else:
	    req = newId()
	    if addr is None:
		status = "Getting address"
	    elif behindfw is None:
		status = "Connecting"
            else:
		status = "Waiting for peer to connect"
	    self.eventprocessor.ProcessRequestToPeer(user,slskmessages.TransferRequest(None,direction,req,filename, self.getFileSize(filename)))
	    if transfer is None:
		transfer = Transfer(user = user,filename = filename ,path = path ,status = status ,req = req)
		if direction == 0:
		    self.downloads.append(transfer)
		else:
		    self.uploads.append(transfer)
	    else:
		transfer.status = status
		transfer.req = req
	    self.uploadspanel.update()
	    self.downloadspanel.update()
	    if direction == 0:
		folder = os.path.join(self.downloaddir,path)
		if not os.access(folder,os.F_OK):
		    os.mkdir(folder)

    def UploadFailed(self,msg):
        for i in self.peerconns:
            if i.conn is msg.conn.conn:
                user = i.username
	for i in self.downloads:
	    if i.user == user and i.filename == msg.file and (i.conn is not None or i.status == "Connection closed by peer" or  i.status == "Establishing connection"):
		self.AbortTransfer(i)
		self.getFile(i.user, i.filename, i.path, i)
		self.eventprocessor.logMessage("Retrying failed download: user %s, file %s" %(i.user,i.filename))
		break
	else:
	    self.eventprocessor.logMessage("Failed download: user %s, file %s" %(user,msg.file))

    def gotAddress(self, req):
	""" A connection is in progress, we got the address for a user we need
	to connect to."""
	for i in self.downloads:
	    if i.req == req:
		i.status = "Connecting"
                self.downloadspanel.update()
        for i in self.uploads:
            if i.req == req:
                i.status = "Connecting"
                self.uploadspanel.update()


    def gotConnectError(self,req):
	""" We couldn't connect to the user, now we are waitng for him to 
	connect to us. Note that all this logic is handled by the network
	event processor, we just provide a visual feedback to the user."""
	for i in self.downloads:
	    if i.req == req:
		i.status = "Waiting for peer to connect"
                self.downloadspanel.update()
        for i in self.uploads:
            if i.req == req:
                i.status = "Waiting for peer to connect"
                self.uploadspanel.update()

    def gotCantConnect(self,req):
	""" We can't connect to the user, either way. """
	for i in self.downloads:
	    if i.req == req:
		i.status = "Cannot connect"
		i.req = None
                self.downloadspanel.update()
        for i in self.uploads:
            if i.req == req:
                i.status = "Cannot connect"
		i.req = None
                self.uploadspanel.update()
		self.checkUploadQueue()


    def gotConnect(self, req, conn):
	""" A connection has been established, now exchange initialisation
	messages."""
	for i in self.downloads:
	    if i.req == req:
		i.status = "Initializing"
		self.downloadspanel.update()
	for i in self.downloads:
            if i.req == req:
                i.status = "Initializing"
                self.uploadspanel.update()

    def TransferRequest(self,msg):
	if msg.conn is not None:
            for i in self.peerconns:
                if i.conn is msg.conn.conn:
	    	    user = i.username
		    conn = msg.conn.conn
	elif msg.tunneleduser is not None:
	    user = msg.tunneleduser
	    conn = None
	if user is None:
	    self.eventprocessor.logMessage("Got transfer request:", vars(msg),"but cannot determine requestor",1)
	    return
	
	if msg.direction == 1:
	    for i in self.downloads:
		if i.filename == msg.file and user == i.user and i.status != "Aborted":
		    i.size = msg.filesize
		    i.req = msg.req
		    i.status = "Waiting for transfer"
		    response = slskmessages.TransferResponse(conn,1,req = i.req)
                    self.downloadspanel.update()
		    break
	    else:
		response = slskmessages.TransferResponse(conn,0,reason = "Cancelled", req = msg.req)
		self.eventprocessor.logMessage("Denied file request: "+str(vars(msg)),1)
	else:
	    if not self.fileIsShared(msg.file):
		response = slskmessages.TransferResponse(conn,0,reason = "File not shared", req = msg.req)
	    elif self.userTransfers(user) or self.bandwidthLimitReached() or self.transferNegotiating():
		response = slskmessages.TransferResponse(conn,0,reason = "Queued", req = msg.req)
	        for i in self.uploads:
	            if i.user == user and i.filename == msg.file and i.status == 'Queued':
	                break
	        else:
		    self.uploads.append(Transfer(user = user, filename = msg.file, path = string.join(string.split(msg.file,'\\')[:-1],'/'), status = "Queued", timequeued = time.time(), size = self.getFileSize(msg.file)))
	    else:
		size = self.getFileSize(msg.file)
		response = slskmessages.TransferResponse(conn,1,req = msg.req, filesize = size)
		self.uploads.append(Transfer(user = user, filename = msg.file, path = string.join(string.split(msg.file,'\\')[:-1],'/'), status = "Waiting for connection", req = msg.req, size = size))
	    self.eventprocessor.logMessage("Upload request: " +str(vars(msg)),1)
	    self.uploadspanel.update()

        if msg.conn is not None:
            self.queue.put(response)
        else:
            self.eventprocessor.ProcessRequestToPeer(user,response)

    def QueueUpload(self, msg):
        for i in self.peerconns:
            if i.conn is msg.conn.conn:
                user = i.username
	for i in self.uploads:
	    if i.user == user and i.filename == msg.file and i.status == 'Queued':
		break
	else:
 	    if self.fileIsShared(msg.file):
	        self.uploads.append(Transfer(user = user, filename = msg.file, path = string.join(string.split(msg.file,'\\')[:-1],'/'), status = "Queued", timequeued = time.time(), size = self.getFileSize(msg.file)))
	    else:
		self.queue.put(slskmessages.QueueFailed(conn = msg.conn.conn, file = msg.file, reason = "File not shared."))
        self.eventprocessor.logMessage("Queued upload request: " +str(vars(msg)),1)
	self.checkUploadQueue()
        self.uploadspanel.update()



    def fileIsShared(self, filename):
	filename = filename.replace("\\","/")
	try:
	    f = open(filename,"r")
	    f.close()
	except:
	    return 0
	dir = string.join(string.split(filename,"/")[:-1],"/")
	file = string.split(filename,"/")[-1]
	shared = self.eventprocessor.config.sections["transfers"]["sharedfiles"]
	if dir in shared.keys():
	    list = [i[0] for i in shared[dir]]
	    if file in list:
		return 1
	return 0

    def userTransfers(self, user):
	for i in self.uploads:
	    if i.user == user and (i.req is not None or i.conn is not None or i.status == 'Getting status'): #some file is being transfered
		return 1
	return 0

    def transferNegotiating(self):
	for i in self.uploads:
	    if i.req is not None or (i.conn is not None and i.starttime is None) or i.status == 'Getting status': #some file is being negotiated
                return 1
        return 0

    def bandwidthLimitReached(self):
	maxbandwidth = self.eventprocessor.config.sections["transfers"]["uploadbandwidth"]
	bandwidth = 0
	curtime = time.time()
	for i in self.uploads:
	    if i.conn is not None and i.speed is not None:
		bandwidth = bandwidth + i.speed
#	self.eventprocessor.logMessage("%i %i " %(bandwidth, maxbandwidth),1)
	if bandwidth > maxbandwidth:
	    return 1
	return 0

    def getFileSize(self,filename):
	try:
	    f = open(filename.replace("\\","/"),"r")
	    f.seek(0,2)
	    size = f.tell()
	except:
	    size = 0
	return size

    def TransferResponse(self,msg):
	""" Got a response to the file request from the peer."""
	if msg.reason != None:
	    for i in (self.downloads+self.uploads)[:]:
		if i.req == msg.req:
		    i.status = msg.reason
		    i.req = None
		    if msg.reason == "Queued":
		        self.queue.put(slskmessages.GetUserStatus(i.user))
		        if i in self.uploads:
			    self.uploads.remove(i)
		    self.checkUploadQueue()
	elif msg.filesize != None:
	    for i in self.downloads:
		if i.req == msg.req:
                    i.size = msg.filesize
                    i.status = "Establishing connection"
                    #Have to establish 'F' connection here
                    self.eventprocessor.ProcessRequestToPeer(i.user,slskmessages.FileRequest(None,msg.req))
		    break
	else:
	    for i in self.uploads:
		if i.req == msg.req:
		    i.status = "Establishing connection"
 		    self.eventprocessor.ProcessRequestToPeer(i.user,slskmessages.FileRequest(None,msg.req))
		    break
	    else:
		self.eventprocessor.logMessage("Got unknown transfer response: " + str(vars(msg)),1)
	self.downloadspanel.update()
	self.uploadspanel.update()


    def FileRequest(self, msg):
	""" Got an incoming file request. Could be an upload request or a 
	request to get the file that was previously queued"""

	for i in self.downloads:
	    if msg.req == i.req and i.conn is None and i.size is not None:
		i.conn = msg.conn
		i.req = None
		try:
                    f = open(os.path.join(self.downloaddir,i.path,"INCOMPLETE"+string.split(i.filename,'\\')[-1]),'ab+')
		    import fcntl
		    fcntl.lockf(f, fcntl.LOCK_EX)
                    f.seek(0,2)
		    size = f.tell()
		    self.queue.put(slskmessages.DownloadFile(i.conn,size,f,i.size))
		    i.currentbytes = size
                    i.status = "%s" %(str(i.currentbytes))
                    i.file = f
		    i.offset = size
		    i.starttime = time.time()
		    self.eventprocessor.logMessage("Download started: %s" %(f.name))
                except IOError, (errno, strerror):
		    print "I/O error(%s): %s" % (errno, strerror)
                    i.status = "Local file error"
                    try:
                        f.close()
                    except:
                        pass
                    i.conn = None
                    self.queue.put(slskmessages.ConnClose(msg.conn))

                self.downloadspanel.update()
		return
         
	for i in self.uploads:
            if msg.req == i.req and i.conn is None:
                i.conn = msg.conn
		i.req = None
                try:
		    f = open(i.filename.replace("\\","/"),"rb")
		    self.queue.put(slskmessages.UploadFile(i.conn,file = f,size =i.size))
		    i.status = "Initializing"
		    i.file = f
                except IOError, (errno, strerror):
		    print "I/O error(%s): %s" % (errno, strerror)
                    i.status = "Local file error"
                    try:
                        f.close()
                    except:
                        pass
                    i.conn = None
                    self.queue.put(slskmessages.ConnClose(msg.conn))
                self.uploadspanel.update()
                break
	else:
	    self.eventprocessor.logMessage("Unknown file request: " +str(vars(msg)),1)

    def FileDownload(self, msg):
	""" A file download is in progress"""
	needupdate = 1

	for i in self.downloads:
	    if i.conn == msg.conn:
		    try:
			curtime = time.time()
                        i.currentbytes = msg.file.tell()
                        i.status = "%s" %(str(i.currentbytes))
			oldelapsed = i.timeelapsed
	                i.timeelapsed = self.getTime(curtime - i.starttime)
			if curtime > i.starttime and i.currentbytes > i.offset:
			    i.speed = (i.currentbytes - i.offset)/(curtime - i.starttime)/1024
	                    i.timeleft = self.getTime((i.size - i.currentbytes)/i.speed/1024)
		        if i.size > i.currentbytes:
			    if oldelapsed == i.timeelapsed:
				needupdate = 0
			    i.status = "%s" %(str(i.currentbytes))
			else:
		            msg.file.close()
			    newname = self.getRenamed(msg.file.name)
		            os.rename(msg.file.name,newname)
		            i.status = "Finished"
			    self.eventprocessor.logMessage("Download finished: %s" %(newname))
			    self.queue.put(slskmessages.ConnClose(msg.conn))
			    i.conn = None
			    self.addToShared(newname)
			    self.eventprocessor.sendNumSharedFoldersFiles()
			    self.downloadspanel.update()
		    except IOError, (errno, strerror):
			print "I/O error(%s): %s" % (errno, strerror)
                        i.status = "Local file error"
	                try:
	                    msg.file.close()
	                except:
	                    pass
	                i.conn = None
	                self.queue.put(slskmessages.ConnClose(msg.conn))
		    if needupdate:
		        self.downloadspanel.update()
    
    def addToShared(self, name):
	if self.eventprocessor.config.sections["transfers"]["sharedownloaddir"]:
	    shared = self.eventprocessor.config.sections["transfers"]["sharedfiles"]
	    sharedstreams = self.eventprocessor.config.sections["transfers"]["sharedfilesstreams"]
            dir = string.join(string.split(name,"/")[:-1],"/")
            file = string.split(name,"/")[-1]
	    size = os.stat(name)[stat.ST_SIZE]

	    if dir not in shared.keys():
		shared[dir] = []
	    if file not in [i[0] for i in shared[dir]]:
		import utils
		shared[dir].append(utils.getFileInfo(file,name))
		sharedstreams[dir] = utils.getDirStream(shared[dir])

    def FileUpload(self,msg):
        """ A file upload is in progress"""
	needupdate = 1

        for i in self.uploads:
            if i.conn == msg.conn:
		curtime = time.time()
		if i.starttime is None:
		    i.starttime = curtime
		    i.offset = msg.offset
		i.currentbytes = msg.offset + msg.sentbytes
		oldelapsed = i.timeelapsed
		i.timeelapsed = self.getTime(curtime - i.starttime)
		if curtime > i.starttime and i.currentbytes > i.offset:
		    i.speed = (i.currentbytes - i.offset)/(curtime - i.starttime)/1024
		    i.timeleft = self.getTime((i.size - i.currentbytes)/i.speed/1024)
		    self.checkUploadQueue()
		if i.size > i.currentbytes:
		    if oldelapsed == i.timeelapsed:
			needupdate = 0
                    i.status = "%s" %(str(i.currentbytes))
                    if i.user in self.privilegedusers:
                        i.status = i.status + " (privileged)"
		else:
                    msg.file.close()
                    i.status = "Finished"
#                    i.conn = None
#		    self.queue.put(slskmessages.ConnClose(msg.conn))
		    for j in self.uploads:
			if j.user == i.user:
			    j.timequeued = curtime
		    self.checkUploadQueue()
		    self.uploadspanel.update()
		if needupdate:
                    self.uploadspanel.update()

    def checkUploadQueue(self):
	if self.bandwidthLimitReached() or self.transferNegotiating():
	    return
	transfercandidate = None
	list = [i for i in self.uploads if not self.userTransfers(i.user) and i.status == "Queued"]
	listogg = [i for i in list if i.filename[-4:].lower() == ".ogg"]
	listprivileged = [i for i in list if i.user in self.privilegedusers]
	if len(listogg) > 0:
	    list = listogg
	if len(listprivileged) > 0:
	    list = listprivileged
	if len(list) == 0:
	    return
	mintimequeued = time.time() + 1
	for i in list:
	    if i.timequeued < mintimequeued:
		transfercandidate = i
		mintimequeued = i.timequeued
	if transfercandidate is not None:
	    self.pushFile(user = transfercandidate.user, filename = transfercandidate.filename, transfer = transfercandidate)

    def getTime(self,sec):
	days = int(sec/86400)
	sec = sec - days*86400
	hours = int(sec/3600)
	sec = sec - hours*3600
	minutes = int(sec/60)
	sec = sec - minutes*60
	sec = int(sec)
	
	days = str(days)
	hours = str(hours)
	minutes = str(minutes)
	sec = str(sec)
	if len(hours) == 1:
	    hours = "0" + hours
	if len(minutes) == 1:
	    minutes = "0" + minutes
	if len(sec) == 1:
	    sec = "0" + sec

	if days == "0":
	    time = "%s:%s:%s" %(hours, minutes, sec)
	else:
	    time = "%s.%s:%s:%s" %(days,hours, minutes,sec)
	return time

    def getUploadQueueSize(self):
	list = []
	for i in self.uploads:
	    if i.status == "Queued" and i.user not in list:
		list.append(i.user)
	return len(list)

    def ConnClose(self, msg):
	""" The remote user has closed the connection either because
	he logged off, or because there's a network problem."""
	for i in self.downloads + self.uploads:
	    if i.conn == msg.conn:
		if i.file is not None:
		    i.file.close()
		if i.status != "Finished":
		    if i.user in self.users.keys() and self.users[i.user].status == 0:
		        i.status = "User logged off"
		    else:
		        i.status = "Connection closed by peer"
		i.conn = None
       	        self.downloadspanel.update()
	        self.uploadspanel.update()
	 	self.checkUploadQueue()

    def getRenamed(self,name):
	""" When a transfer is finished, we remove INCOMPLETE prefix from the
	file's name. """
	path,filename = os.path.split(name)
	if filename[0:10] == "INCOMPLETE":
	    filename = filename[10:]
	return os.path.join(path,filename)

    def PlaceInQueue(self,msg):
	""" The server tells us our place in queue for a particular transfer."""
	self.eventprocessor.logMessage("File: %s, place in queue: %s" % (string.split(msg.filename,'\\')[-1], msg.place))

    def FileError(self, msg):
	""" Networking thread encountered a local file error"""
	for i in self.downloads+self.uploads:
	    if i.conn == msg.conn.conn:
		i.status = "Local file error"
		try:
		    msg.file.close()
		except:
		    pass
		i.conn = None
		self.queue.put(slskmessages.ConnClose(msg.conn.conn))
                self.downloadspanel.update()
                self.uploadspanel.update()
		self.checkUploadQueue()


    def FolderContentsResponse(self,msg):
	""" When we got a contents of a folder, get all the files in it, but
	skip the files in subfolders"""
        for i in self.peerconns:
            if i.conn is msg.conn.conn:
                username = i.username

        for i in msg.list.keys():
            for j in msg.list[i].keys():
                if os.path.commonprefix([i,j]) == j:
                    dir = string.split(j,'\\')[-1]
                    for k in msg.list[i][j]:
                        self.getFile(username, j+ '\\' + k[1], dir)

    def AbortTransfers(self):
	""" Stop all transfers """
	for i in self.downloads+self.uploads:
	    if i.status != "Finished":
		self.AbortTransfer(i)
		i.status = "Old"
#                self.downloadspanel.update()
#                self.uploadspanel.update()


    def AbortTransfer(self,transfer):
	if transfer.conn is not None:
            self.queue.put(slskmessages.ConnClose(transfer.conn))
	    transfer.conn = None
	if transfer.file is not None:
	    try:
		transfer.file.close()
	    except:
		pass


    def GetDownloads(self):
	""" Get a list of incomplete and not aborted downloads """
	list = []
	for i in self.downloads:
	    if i.status != 'Finished' and i.status != 'Aborted':
		list.append([i.user, i.filename, i.path])
	return list
