# Copyright (c) 2001-2002 Alexander Kanavin. All rights reserved.

"""
This module implements SoulSeek networking protocol.
"""

from slskmessages import *
import SocketServer
import socket
import select
import threading
import struct
import random
import time

class Connection:
    """
    Holds data about a connection. conn is a socket object, 
    addr is (ip,port) pair, ibuf and obuf are input and output buffer,
    init is a PeerInit object (see slskmessages docstrings).
    """
    def __init__(self, conn = None, addr = None, ibuf = "", obuf = ""):
	self.conn = conn
	self.addr = addr
	self.ibuf = ibuf
	self.obuf = obuf
	self.init = None

class ServerConnection(Connection):
    pass

class PeerConnection(Connection):
    def __init__(self, conn = None, addr = None, ibuf = "", obuf = ""):
	Connection.__init__(self,conn,addr,ibuf,obuf)
	self.filereq = None
	self.fileresp = None
	self.filedown = None
	self.filereadbytes = 0
	self.bytestoread = 0

class PeerConnectionInProgress:
    """ As all p2p connect()s are non-blocking, this class is used to
    hold data about a connection that is not yet established. msgObj is 
    a message to be sent after the connection has been established.
    """
    def __init__(self, conn = None, msgObj = None):
        self.conn = conn
        self.msgObj = msgObj

class SlskProtoThread(threading.Thread):
    """ This is a netwroking thread that actually does all the communication.
    It sends data to the UI thread via a callback function and receives data
    via a Queue object.
    """

    """ Server and peers send each other small binary messages, that start
    with length and message code followed by the actual messsage data. 
    These are the codes."""
    servercodes = {Login:1,SetWaitPort:2,
                   GetPeerAddress:3,GetUserStatus:7,SayChatroom:13,
                   JoinRoom:14,UserJoinedRoom:16,UserLeftRoom:17,
                   ConnectToPeer:18,MessageUser:22,MessageAcked:23,
		   FileSearchRoom:25,FileSearch:26,SendConnectToken:33,
		   GetUserStats:36,QueuedDownloads:40,PlaceInQueue:60,
		   CantConnectToPeer:1001}
    peercodes = {GetSharedFileList:4, SharedFileList:5, FileSearchResult:9,
		UserInfoRequest:15,UserInfoReply:16, FolderContentsRequest:36,
		FolderContentsResponse:37}

    def __init__(self, ui_callback, queue):
	""" ui_callback is a UI callback function to be called with messages 
	list as a parameter. queue is Queue object that holds messages from UI
	thread.
	"""
        threading.Thread.__init__(self) 
        self._ui_callback = ui_callback
        self._queue = queue
        self._want_abort = 0
	self._stopped = 0

        self.serverclasses = {}
        for i in self.servercodes.keys():
            self.serverclasses[self.servercodes[i]]=i
        self.peerclasses = {}
        for i in self.peercodes.keys():
            self.peerclasses[self.peercodes[i]]=i
	self._p = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	self._conns = {}
	self._connsinprogress={}

	for listenport in range(2234,2240):
#		listenport = random.randint(2000,60000)
		try:
		    self._p.bind(('',listenport))
		except socket.error:
		    listenport = None
		else:
		    self._p.listen(1)
		    self._ui_callback([IncPort(listenport)])
		    break
	if listenport is not None:
	    self.start()
    
    def run(self):
	""" Actual networking loop is here."""
	p = self._p
	s = None
	conns = self._conns
	connsinprogress = self._connsinprogress
	queue = self._queue

        while not self._want_abort:
            if not queue.empty():
		conns, connsinprogress, s = self.process_queue(queue, conns, connsinprogress,s)
		for i in conns.keys():
		    try:
			bytes_send = i.send(conns[i].obuf)
			conns[i].obuf = conns[i].obuf[bytes_send:]
		    except socket.error, err:
			self._ui_callback([ConnectError(conns[i],err)])
	    try:
            	input,output,exc = select.select(conns.keys()+[p],connsinprogress.keys(),[],0.5)
#            	input,output,exc = select.select(conns.keys(),connsinprogress.keys(),[],0.5)
	    except select.error:
		self._want_abort = 1
	    if p in input:
		incconn, incaddr = p.accept()
		conns[incconn] = PeerConnection(incconn,incaddr,"","")
		self._ui_callback([IncConn(incconn, incaddr)])
	    for i in connsinprogress.keys():
		if i in output:
		    try:
			msgObj = connsinprogress[i].msgObj
		        i.connect(msgObj.addr)
		    except socket.error,err:
                        self._ui_callback([ConnectError(msgObj,err)])
                    else:
		        conns[i]=PeerConnection(i,msgObj.addr,"","")
		        self._ui_callback([OutConn(i,msgObj.addr)])
		    del connsinprogress[i]
	    for i in conns.keys():
		if i in input:
		    try:
		        data = i.recv(1024*1024)
		    except socket.error, err:
			self._ui_callback([ConnectError(conns[i],err)])
		    else:
			if data:
			    if i is s:
			        msgs,conns[s].ibuf = self.process_server_input(conns[s].ibuf + data)
				self._ui_callback(msgs)
			    else:
				conns[i].ibuf = conns[i].ibuf + data
				if conns[i].init is None or conns[i].init.type != 'F':
				    msgs, conns[i] = self.process_peer_input(conns[i],conns[i].ibuf)
				    self._ui_callback(msgs)
				if conns[i].init is not None and conns[i].init.type == 'F':
			            msgs, conns[i] = self.process_file_input(conns[i],conns[i].ibuf)
				    self._ui_callback(msgs)
		        else:
			    self._ui_callback([ConnClose(i,conns[i].addr)])
			    i.close()
			    del conns[i]
	if s is not None:
            s.close()
	self._stopped = 1

    def process_server_input(self,buffer):
 	""" Server has sent us something, this function retrieves messages 
	from the buffer, creates message objects and returns them and the rest 
	of the buffer.
	"""
        msgs=[]
        while len(buffer) >=8:
            msgsize, msgtype = struct.unpack("<ii",buffer[:8])
            if msgsize + 4 > len(buffer):
                break
            elif self.serverclasses.has_key(msgtype):
                msg = self.serverclasses[msgtype]()
                msg.parseNetworkMessage(buffer[8:msgsize+4])
                msgs.append(msg)
            else:
                print "Server message type", msgtype, "size",msgsize-4,"not handled"
	    buffer = buffer[msgsize+4:]
        return msgs,buffer

    def parseFileReq(self,conn,buffer):
	""" I'm sorry Nir, but file transfer protocol is a real mess. 
	The proof follows.
	"""
	msg = None
	if len(buffer) >= 16:
	    dir, reqnum, remotereqnum, relpathlen = struct.unpack("<iiii",buffer[:16])
	    relpath = buffer[16:16+relpathlen]
	    if len(buffer) >= 16 + relpathlen + 4:
	        filenamelen, = struct.unpack("<i",buffer[16+relpathlen:16+relpathlen+4])
		filename = buffer[16+relpathlen+4:16+relpathlen+4+filenamelen]
		if len(buffer) >= 16 +relpathlen+4+filenamelen+4:
		    filesize, = struct.unpack("<i",buffer[16+relpathlen+4+filenamelen:16+relpathlen+4+filenamelen+4])
		    msg = FileRequest(conn,dir,reqnum,remotereqnum,filename,filesize)
		    buffer = buffer[16+relpathlen+4+filenamelen+4:]
	return msg,buffer

    def parseFileResp(self,conn,buffer):
	msg=None
	if len(buffer) >= 1:
	    if buffer[0] == chr(0) and len(buffer)>=5:
		reasonlen, = struct.unpack("<i",buffer[1:5])
		reason = buffer[5:5+reasonlen]
		if len(buffer) >= 5+reasonlen:
		    msg = FileResponse(conn, 0, reason)
		    buffer = buffer[5+reasonlen:]
	    elif buffer[0] == chr(1) and len(buffer)>=9:
		remotereqnum,size = struct.unpack("<ii",buffer[1:9])
		msg = FileResponse(conn, 1, None, remotereqnum, size)
		buffer = buffer[9:]
	return msg,buffer

    def process_file_input(self,conn,buffer):
            """ We have a "F" connection (filetransfer) , peer has sent us 
	    something, this function retrieves messages 
            from the buffer, creates message objects and returns them 
	    and the rest of the buffer.
            """
	    msgs=[]
	    if conn.filereq is None:
		filereq,buffer = self.parseFileReq(conn,buffer)
		if filereq is not None:
		    msgs.append(filereq)
		    conn.filereq = filereq
	    elif conn.fileresp is None:
		fileresp,buffer = self.parseFileResp(conn,buffer)
		if fileresp is not None:
		    msgs.append(fileresp)
		    conn.fileresp = fileresp
	    elif conn.filedown is not None:
		leftbytes = conn.bytestoread - conn.filereadbytes
		if leftbytes > 0:
		    try:
		        conn.filedown.file.write(buffer[:leftbytes])
		    except:
			self._ui_callback([FileError(conn,conn.filedown.file)])
		    self._ui_callback([DownloadFile(conn,len(buffer[:leftbytes]),conn.filedown.file)])
		conn.filereadbytes = conn.filereadbytes + len(buffer[:leftbytes])
		buffer = buffer[leftbytes:]
		if buffer[4:13] == "$reusing$":
		    conn.filereq = None
		    conn.fileresp = None
		    conn.filedown = None
		    conn.filereadbytes = 0
		    conn.bytestoread = 0
                    filereq,buffer = self.parseFileReq(conn,buffer[13:])
                    if filereq is not None:
                        msgs.append(filereq)
                        conn.filereq = filereq

	    conn.ibuf = buffer
	    return msgs, conn

    def process_peer_input(self,conn,buffer):
        """ We have a "P" connection (p2p exchange) , peer has sent us 
        something, this function retrieves messages 
        from the buffer, creates message objects and returns them 
        and the rest of the buffer.
        """
        msgs=[]
	while (conn.init is None or conn.init.type != 'F') and len(buffer) >= 8:
	    msgsize = struct.unpack("<i",buffer[:4])[0]
            self._ui_callback([PeerTransfer(conn,msgsize,len(buffer)-4)])
	    if msgsize + 4 > len(buffer):
		break
	    elif conn.init is None:
		if buffer[4] == chr(0):
		    msg = PierceFireWall(conn)
		    msg.parseNetworkMessage(buffer[5:msgsize+4])
		elif buffer[4] == chr(1):
		    msg = PeerInit(conn)
		    msg.parseNetworkMessage(buffer[5:msgsize+4])
		    conn.init = msg
		msgs.append(msg)
		buffer = buffer[msgsize+4:]
            elif conn.init.type == 'P':
		msgtype = struct.unpack("<i",buffer[4:8])[0]
		if self.peerclasses.has_key(msgtype):
                    msg = self.peerclasses[msgtype](conn)
                    msg.parseNetworkMessage(buffer[8:msgsize+4])
                    msgs.append(msg)
            	else:
                    print "Peer message type", msgtype, "size",msgsize-4,"not handled"
	        buffer = buffer[msgsize+4:]
	    else:
		print "Can't handle connection type", conn.init.type
		buffer = buffer[msgsize+4:]
	conn.ibuf = buffer
	return msgs,conn

    def process_queue(self,queue, conns, connsinprogress, s):
	""" Processes messages sent by UI thread. s is a server connection 
	socket object, queue holds the messages, conns ans connsinprogess 
	are dictionaries holding Connection and PeerConnectionInProgress 
	messages."""
        while not queue.empty():
            msgObj=queue.get()
	    if issubclass(msgObj.__class__,ServerMessage):
            	msg = msgObj.makeNetworkMessage()
            	conns[s].obuf = conns[s].obuf + struct.pack("<ii",len(msg)+4,self.servercodes[msgObj.__class__]) + msg
	    elif issubclass(msgObj.__class__,PeerMessage):
		if msgObj.__class__ is PierceFireWall:
		    msg = msgObj.makeNetworkMessage()
		    conns[msgObj.conn].obuf = conns[msgObj.conn].obuf + struct.pack("<i", len(msg) + 1) + chr(0) + msg
		elif msgObj.__class__ is PeerInit:
		    conns[msgObj.conn].init = msgObj
		    msg = msgObj.makeNetworkMessage()
		    conns[msgObj.conn].obuf = conns[msgObj.conn].obuf + struct.pack("<i", len(msg) + 1) + chr(1) + msg
		elif msgObj.__class__ is FileRequest:
		    conns[msgObj.conn].filereq = msgObj
		    msg = msgObj.makeNetworkMessage()
		    conns[msgObj.conn].obuf = conns[msgObj.conn].obuf + msg
                elif msgObj.__class__ is FileResponse:
                    conns[msgObj.conn].fileresp = msgObj
                    msg = msgObj.makeNetworkMessage()
                    conns[msgObj.conn].obuf = conns[msgObj.conn].obuf + msg
		else:
		    msg = msgObj.makeNetworkMessage()
		    conns[msgObj.conn].obuf = conns[msgObj.conn].obuf + struct.pack("<ii", len(msg) + 4, self.peercodes[msgObj.__class__]) + msg
	    elif issubclass(msgObj.__class__,InternalMessage):
		if msgObj.__class__ is ServerConn:
		    try:
			s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
			s.connect(msgObj.addr)
		    except socket.error,err:
			self._ui_callback([ConnectError(msgObj,err)])
		    else:
		        conns[s]=ServerConnection(s,msgObj.addr,"","")
		        self._ui_callback([ServerConn(s,msgObj.addr)])
		elif msgObj.__class__ is ConnClose and msgObj.conn is not None:
		    msgObj.conn.close()
		    self._ui_callback([ConnClose(msgObj.conn,conns[msgObj.conn].addr)])
		    del conns[msgObj.conn]
		elif msgObj.__class__ is OutConn:
		    conn = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		    conn.setblocking(0)
		    conn.connect_ex(msgObj.addr)
		    conn.setblocking(1)
		    connsinprogress[conn]=PeerConnectionInProgress(conn,msgObj)
		elif msgObj.__class__ is DownloadFile:
		    conns[msgObj.conn].filedown = msgObj
		    if conns[msgObj.conn].filereq.direction == 0:
			conns[msgObj.conn].obuf = conns[msgObj.conn].obuf + struct.pack("<i", msgObj.offset)
			conns[msgObj.conn].bytestoread = conns[msgObj.conn].fileresp.offset - msgObj.offset
		    else:
			conns[msgObj.conn].bytestoread = conns[msgObj.conn].filereq.filesize - conns[msgObj.conn].fileresp.offset
	    
        return conns,connsinprogress,s

    def abort(self):
	""" Call this to abort the thread"""
        self._want_abort = 1 

    def stopped(self):
	""" returns true if thread has stopped """
	return self._stopped
