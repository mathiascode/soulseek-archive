# Copyright (c) 2001-2003 Alexander Kanavin. All rights reserved. 

import time
from pysoulseek import slskproto
from pysoulseek import slskmessages
import Queue
import threading
import images
import about
import userinfobrowse
import search
import notebook
import buttonsplitter
import os
import os.path
import string
from sortablelist import sortableListCtrl
from wxPython.wx import *
import locale
from pysoulseek.utils import version


def GetCompletion(part, list):
    matches = [i for i in list if i[:len(part)] == part and len(i) > len(part)]
    if len(matches) == 0:
        return ""
    else:
        prefix = matches[0]
        for item in matches:
            for i in range(len(prefix)):
                if prefix[:i+1] != item[:i+1]:
                    prefix = prefix[:i]
                    break
    return prefix[len(part):]


class OutputWindow(wxTextCtrl):
    """
    Multiple-lines text control with a twist - cleans oldest 100 lines from 
    itself when 200 lines maximum is reached
    """
    def __init__(self, parent, id, style):
        wxTextCtrl.__init__(self,parent,id,style = style)
        self.lines = 0
        self.chars = 0
	
	self.linesinfo = []

    def AppendText(self, text):
        wxTextCtrl.AppendText(self,text)
        self.lines = self.lines + 1
        if self.lines == 100:
             self.chars = wxTextCtrl.GetLastPosition(self)
        if self.lines == 200:
             wxTextCtrl.Remove(self,0,self.chars)
             wxTextCtrl.SetInsertionPointEnd(self)
	     self.lines = 100
	     self.linesinfo = self.linesinfo[self.lines:]
	     for i in self.linesinfo:
		i[0] = i[0] - self.chars
	     self.chars = wxTextCtrl.GetLastPosition(self)
	

    def AppendUserText(self, text, user, colour):
	self.AppendText(text)
	self.linesinfo.append([self.GetLastPosition(),user,colour])

    def UserLeft(self, user):
	for i in range(len(self.linesinfo)):
	    if self.linesinfo[i][1] == user:
		if i == 0:
		    start = 0
		else:
		    start = self.linesinfo[i-1][0]
		end = self.linesinfo[i][0]
		colour = "GREY"
		self.SetStyle(start, end, wxTextAttr(colour))

    def UserJoined(self, user):
        for i in range(len(self.linesinfo)):
            if self.linesinfo[i][1] == user:
                if i == 0:
                    start = 0
                else:
                    start = self.linesinfo[i-1][0]
                end = self.linesinfo[i][0]
		colour = self.linesinfo[i][2]
		if colour is None:
		    colour = "BLACK"
         	self.SetStyle(start,end,wxTextAttr(colour))


class ChatRooms(buttonsplitter.ButtonSplitterWindow):
    """ This window contains a rooms list and a rooms notebook """
    def __init__(self, parent, id, queue, privatechat, peerconns, frame,  style = wxNO_3D|wxSP_3D):
	self.queue = queue
	self.privatechat = privatechat
	self.peerconns = peerconns
	self.frame = frame

        buttonsplitter.ButtonSplitterWindow.__init__(self,parent,id,self.getLeft,self.getRight,style = style)
        self.roomsnotebook = notebook.IconNotebook(self.panel, -1, style=wxCLIP_CHILDREN, frame = frame)
        self.roomsctrl = None
	self.InitLeft()
	self.splitterpos = -180
        self.OnExpButton(None)


    def getLeft(self):
	return self.roomsnotebook

    def getRight(self):
	self.roomsctrl = RoomsCtrl(self,-1, self.queue, self.privatechat, self.peerconns, self.frame, self.roomsnotebook, self.roomsctrl)
	return self.roomsctrl	

class RoomsCtrl(wxPanel):
    """ This panel contains a rooms list and an input box to create a room """
    def __init__(self, parent, id, queue, privatechat, peerconns, frame, roomsnotebook, oldroomsctrl = None):
        wxPanel.__init__(self, parent, id)
	if oldroomsctrl is None:
            self.joinedrooms = {}
            self.joinedroomslist = []
            self.rooms = []
	else:
	    self.joinedrooms = oldroomsctrl.joinedrooms
	    self.joinedroomslist = oldroomsctrl.joinedroomslist
	    self.rooms = oldroomsctrl.rooms
        self.roomlist = RoomListCtrl(self,-1)
        self.addroom = wxTextCtrl(self,-1, style = wxTE_PROCESS_ENTER)
        self.create = wxStaticText(self, -1, "Create:")

        sizerh = wxBoxSizer(wxHORIZONTAL)
        sizerh.Add(self.create,0,wxALIGN_CENTER)
        sizerh.Add(self.addroom,1,wxEXPAND)
        sizerv = wxBoxSizer(wxVERTICAL)
        sizerv.Add(self.roomlist,1,wxEXPAND)
        sizerv.Add(sizerh,0,wxEXPAND)

        self.SetSizer(sizerv)
        self.SetAutoLayout(True)
        EVT_TEXT_ENTER(self,self.addroom.GetId(),self.OnEnter)
	

        self.parent = parent
        self.queue = queue
        self.privatechat = privatechat
        self.peerconns = peerconns
        self.frame = frame
        self.roomsnotebook = roomsnotebook

        self.menu = wxMenu()
        self.joinID = wxNewId()
        self.menu.Append(self.joinID, 'Join Room')
        EVT_MENU(self,self.joinID, self.OnJoinRoom)
        self.leaveID = wxNewId()
        self.menu.Append(self.leaveID, 'Leave Room')
        EVT_MENU(self,self.leaveID, self.OnLeaveRoom)
        self.menu.AppendSeparator()
        refreshID=wxNewId()
        self.menu.Append(refreshID, 'Refresh Room List')
        EVT_MENU(self,refreshID, self.OnRefresh)

        EVT_RIGHT_UP(self.roomlist, self.OnRightUp)

    def OnEnter(self, event):
	""" Add a room or join an existing one """
        text = self.frame.np.encode(self.addroom.GetLineText(0))
	if len(text) > 0:
            self.queue.put(slskmessages.JoinRoom(text))
        self.addroom.Clear()

    def OnRightUp(self, event):
        """ Show the pop-up menu"""
        pt = event.GetPosition()
        self.item, flags = self.roomlist.HitTest(pt)
        if self.item != -1:
            self.selectedroom = self.rooms[self.item][0]
            self.roomlist.SetItemState(self.item,wxLIST_STATE_FOCUSED,wxLIST_STATE_FOCUSED)
            if self.joinedrooms.has_key(self.rooms[self.item][0]):
                self.menu.Enable(self.joinID,0)
                self.menu.Enable(self.leaveID,1)
            else:
                self.menu.Enable(self.joinID,1)
                self.menu.Enable(self.leaveID,0)
            self.roomlist.PopupMenu(self.menu, pt)

    def OnJoinRoom(self, event):
        self.queue.put(slskmessages.JoinRoom(self.selectedroom))

    def OnLeaveRoom(self, event):
        self.queue.put(slskmessages.LeaveRoom(self.selectedroom))

    def OnRefresh(self,event):
        self.queue.put(slskmessages.RoomList())

    def SetGreeting(self, text):
# Don't know where to put that at the moment
        self.greeting = text
	self.frame.logMessage("Server greeting:\n" + text)

    def SetRoomList(self, msg):
        self.rooms = msg.rooms
        self.rooms.sort(self.SortRoomList)
        self.roomlist.SetItemCount(len(self.rooms))
	for i in self.frame.np.config.sections["server"]["autojoin"]:
		self.queue.put(slskmessages.JoinRoom(i))

    def SortRoomList(self, item1, item2):
        if item1[1] > item2[1]:
            return -1
        elif item1[1] < item2[1]:
            return 1
        else:
            return 0

    def UserJoinedRoom(self, msg):
        self.CreateRoomWindow(msg.room)
        self.joinedrooms[msg.room].UserJoinedRoom(msg)

    def JoinRoom(self,msg):
        self.CreateRoomWindow(msg.room)
        self.joinedrooms[msg.room].JoinRoom(msg)

    def SayChatRoom(self,msg,text):
        self.CreateRoomWindow(msg.room)
        self.joinedrooms[msg.room].SayChatRoom(msg,text)
	if text.find(self.frame.np.config.sections["server"]["login"])>=0:
	    self.frame.OnPageUpdated(self.parent, True)
	    self.frame.SetTitle("(*) PySoulSeek %s" % version)
	else:
	    self.frame.OnPageUpdated(self.parent)

    def UserLeftRoom(self,msg):
        self.CreateRoomWindow(msg.room)
        self.joinedrooms[msg.room].UserLeftRoom(msg)

    def QueuedDownloads(self, msg):
        for i in self.joinedrooms.keys():
            if self.joinedrooms[i].users.has_key(msg_user):
                self.joinedrooms[i].QueuedDownloads(msg)

    def GetUserStatus(self, msg):
        for i in self.joinedrooms.keys():
            if self.joinedrooms[i].users.has_key(msg.user):
                self.joinedrooms[i].GetUserStatus(msg)

    def GetUserStats(self, msg):
        for i in self.joinedrooms.keys():
            if self.joinedrooms[i].users.has_key(msg.user):
                self.joinedrooms[i].GetUserStats(msg)

    def LeaveRoom(self,msg):
        self.roomsnotebook.DeletePage(self.joinedroomslist.index(msg.room))
        self.joinedroomslist.remove(msg.room)
        del self.joinedrooms[msg.room]

    def CreateRoomWindow(self, room):
        if not self.joinedrooms.has_key(room):
            self.joinedrooms[room] = ChatWindow(self.roomsnotebook, -1, self.queue, self.privatechat, self.peerconns, self.frame)

            self.roomsnotebook.AddPage(self.joinedrooms[room],room)
            self.joinedroomslist.append(room)
            


class RoomListCtrl(sortableListCtrl):
    """ Actual room list control """
    def __init__(self, parent, id, style = wxLC_REPORT|wxLC_VIRTUAL):
        sortableListCtrl.__init__(self,parent,id,style = style)
        self.InsertColumn(0,"Room", width=100)
        self.InsertColumn(1,"Users",width=50,format=wxLIST_FORMAT_RIGHT)
        self.SetItemCount(len(parent.rooms))

        self.parent = parent

    def OnGetItemText(self, item, col):
        return self.parent.rooms[item][col]

    def OnGetItemImage(self,item):
	return -1

    def SortList(self, col, order):
        if order == 0:
            self.parent.rooms.sort(lambda x,y: self.cmp(x[col],y[col]))
        else:
            self.parent.rooms.sort(lambda y,x: self.cmp(x[col],y[col]))


class GlobalUsersList(wxPanel):
    """ This window contains a global list of users. """
    def __init__(self, parent, id, queue, privatechat, peerconns, frame):
        wxPanel.__init__(self, parent, id)

	self.queue = queue
	self.privatechat = privatechat
	self.peerconns = peerconns
	self.frame = frame

	self.userslistctrl = UsersList(self, -1,style = wxLC_REPORT|wxLC_VIRTUAL|wxSUNKEN_BORDER)
	self.userslist = []
	self.users = {}

        self.note = wxStaticText(self, -1, "This list does not auto-update")
	self.update = wxButton(self, -1, "Update")
	
        sizerh = wxBoxSizer(wxHORIZONTAL)
        sizerh.Add(self.update,0,wxEXPAND)
        sizerh.Add(self.note,1,wxALIGN_CENTER)
        sizerv = wxBoxSizer(wxVERTICAL)
        sizerv.Add(sizerh,0,wxEXPAND)
        sizerv.Add(self.userslistctrl,1,wxEXPAND)
        self.SetSizer(sizerv)
        self.SetAutoLayout(True)

        EVT_BUTTON(self,self.update.GetId(), self.OnUpdate)

    def OnUpdate(self, event):
        self.queue.put(slskmessages.GlobalUserList())

    def setGlobalUsersList(self, msg):
        self.users = msg.users
        self.userslist = self.users.keys()
        self.userslist.sort()
        self.userslistctrl.SetItemCount(len(self.users))
	privileged = self.frame.np.transfers.privilegedusers
	numprivonline = len([i for i in privileged if i in self.userslist])
	self.frame.logMessage("Currently %i users online (%i or %.1f" % (len(self.users),numprivonline, float(numprivonline)/len(self.users)*100) + " percent of them are privileged)") 
        self.frame.OnPageUpdated(self)


class UsersList(sortableListCtrl):
    """
    This is a list control for the users list in chat window and in global 
    users list. Gets users
    data from parent window (which should have a userslist attribute).
    """
    def __init__(self, parent, id, style = wxLC_REPORT|wxLC_VIRTUAL):
        sortableListCtrl.__init__(self,parent,id,style = style)
        self.InsertColumn(0,"User", width=100)
        self.InsertColumn(1,"Speed",width=50,format=wxLIST_FORMAT_RIGHT)
        self.InsertColumn(2,"Files",width=50,format=wxLIST_FORMAT_RIGHT)
        self.SetItemCount(0)
        self.normal = wxListItemAttr()
        self.grey = wxListItemAttr()
        self.grey.SetTextColour("grey")

        self.online = self.imglist.Add(images.getOnlineBitmap())
        self.offline = self.imglist.Add(images.getOfflineBitmap())
        self.away = self.imglist.Add(images.getAwayBitmap())
#        self.AssignImageList(self.imglist,wxIMAGE_LIST_SMALL)

        self.parent = parent.GetParent()

        self.menu = wxMenu()
        sendmessageID=wxNewId()
        self.menu.Append(sendmessageID, 'Send Message')
        EVT_MENU(self,sendmessageID, self.OnSendMessage)
	self.menu.AppendSeparator()
        showipID=wxNewId()
        self.menu.Append(showipID, 'Show IP address')
        EVT_MENU(self,showipID, self.OnShowIp)
        getinfoID=wxNewId()
        self.menu.Append(getinfoID, 'Get User Info')
        EVT_MENU(self,getinfoID, self.OnGetInfo)
        browseID=wxNewId()
        self.menu.Append(browseID, 'Browse Files')
        EVT_MENU(self,browseID, self.OnBrowse)
        addtolistID=wxNewId()
        self.menu.Append(addtolistID, 'Add to User List')
        EVT_MENU(self,addtolistID, self.OnAddToList)
        banuserID=wxNewId()
	self.menu.Append(banuserID, "Ban this user")
	EVT_MENU(self,banuserID, self.OnBanUser)
	ignoreuserID=wxNewId()
	self.menu.Append(ignoreuserID, "Ignore this user")
	EVT_MENU(self,ignoreuserID, self.OnIgnoreUser)

        EVT_RIGHT_UP(self,self.OnRightUp)

    def OnRightUp(self,event):
        """ Pops up a menu on a right-click in users list."""
        pt = event.GetPosition()
        item, flags = self.HitTest(pt)
        if item >= 0:
	    self.focuseduser=self.parent.userslist[item]
            self.SetItemState(item,wxLIST_STATE_FOCUSED,wxLIST_STATE_FOCUSED)
            self.PopupMenu(self.menu, pt)

    """ Handlers for the menu items"""
    def OnSendMessage(self, event):
        self.parent.privatechat.SendMessage(self.focuseduser)

    def OnShowIp(self, event):
        self.parent.queue.put(slskmessages.GetPeerAddress(self.focuseduser))

    def OnGetInfo(self, event):
        self.parent.frame.np.ProcessRequestToPeer(self.focuseduser, slskmessages.UserInfoRequest(None), self.parent.frame.np.userinfo)

    def OnBrowse(self, event):
        self.parent.frame.np.ProcessRequestToPeer(self.focuseduser, slskmessages.GetSharedFileList(None), self.parent.frame.np.userbrowse)

    def OnAddToList(self, event):
	self.parent.frame.np.userlist.AddToList(self.focuseduser)

    def OnBanUser(self, event):
    	self.parent.frame.BanUser(self.focuseduser)

    def OnIgnoreUser(self, event):
	self.parent.frame.IgnoreUser(self.focuseduser)

    def OnGetItemText(self, item, col):
        username =  self.parent.userslist[item]
	return self.GetColumnValue(username,col)

    def GetColumnValue(self,username,col,sort=0):
        if col == 0:
            return username
        elif col == 1:
            if not sort:
                return locale.format("%s",self.parent.users[username].avgspeed,1)
            else:
                return self.parent.users[username].avgspeed
        elif col == 2:
            if not sort:
                return locale.format("%s",self.parent.users[username].files,1)
            else:
                return self.parent.users[username].files
        else:
            return None

    def OnGetItemAttr(self,item):
        username =  self.parent.userslist[item]
        if self.parent.users[username].slotsfull == 1:
            return self.grey
        else:
            return self.normal

    def OnGetItemImage(self,item):
        username = self.parent.userslist[item]
        if self.parent.users[username].status == 1:
            return self.away
        elif self.parent.users[username].status == 2:
            return self.online
        else:
            return -1

    def SortList(self, col, order):
        if order == 0:
	    self.parent.userslist.sort(lambda x,y: self.cmp(self.GetColumnValue(x,col,1),self.GetColumnValue(y,col,1)))
	else:
	    self.parent.userslist.sort(lambda y,x: self.cmp(self.GetColumnValue(x,col,1),self.GetColumnValue(y,col,1)))


class ChatWindow(wxSplitterWindow):
    """
    The chat window that holds a users list, info window and dialog window.
    Also contains users dictionary that holds info about every user in a room.
    """
    def __init__(self, parent, id, queue, privatechat, peerconns, frame, style = wxNO_3D|wxSP_3D):
        wxSplitterWindow.__init__(self,parent,id,wxDefaultPosition,wxDefaultSize,style,"splitterWindow")
	self.SetMinimumPaneSize(1)
        splitter = wxSplitterWindow(self,-1,style=wxNO_3D|wxSP_3DSASH)
	splitter.SetMinimumPaneSize(1)
	userlistpanel = wxPanel(self,-1)
        self.userslistctrl = UsersList(userlistpanel,-1,style=wxLC_REPORT|wxLC_VIRTUAL)
	self.leave = wxButton(userlistpanel, -1, "Leave")
        self.logctrl = wxCheckBox(userlistpanel, -1, "Log");
        self.logctrl.SetValue(frame.np.config.sections["logging"]["chatrooms"])
	self.autojoinctrl = wxCheckBox(userlistpanel, -1, "Auto-Join")
        EVT_CHECKBOX(self, self.logctrl.GetId(), self.OnLogCheckClick)
	EVT_CHECKBOX(self, self.autojoinctrl.GetId(), self.OnAutoJoinClick)

        sizerh = wxBoxSizer(wxHORIZONTAL)
	sizerh.Add(self.logctrl,0,wxEXPAND)
	sizerh.Add(self.autojoinctrl,0,wxEXPAND)
        sizerh.Add(self.leave,0,wxALIGN_RIGHT)

        sizerv = wxBoxSizer(wxVERTICAL)
        sizerv.Add(self.userslistctrl,1,wxEXPAND)
        sizerv.Add(sizerh,0,wxEXPAND)
        
        userlistpanel.SetSizer(sizerv)
        userlistpanel.SetAutoLayout(True)
        self.SplitVertically(splitter,userlistpanel,-220)
        self.info = OutputWindow(splitter,-1,style = wxTE_MULTILINE|wxTE_READONLY|wxTE_RICH2)

        chatpanel = wxPanel(splitter,-1)
        self.chat = OutputWindow(chatpanel,-1,style = wxTE_MULTILINE|wxTE_READONLY|wxTE_RICH2)
        self.mychatphrase = wxTextCtrl(chatpanel,-1, style = wxTE_PROCESS_ENTER|wxTE_PROCESS_TAB)
	EVT_CHAR(self.mychatphrase, self.OnPhraseChar)

        chatsizer = wxBoxSizer(wxVERTICAL)
        chatsizer.Add(self.chat,1,wxEXPAND)
        chatsizer.Add(self.mychatphrase,0,wxEXPAND)
        chatpanel.SetSizer(chatsizer)
        chatpanel.SetAutoLayout(True)

        splitter.SplitHorizontally(self.info,chatpanel,100)

        self.queue = queue
        self.privatechat = privatechat
        self.users = {} #without IP/fw cache
        self.peerconns = peerconns
        self.frame = frame
	self.room = None
	self.parent = parent
        self.logfile = None

        EVT_TEXT_ENTER(self,self.mychatphrase.GetId(),self.OnEnter)
	EVT_BUTTON(self,self.leave.GetId(),self.OnLeave)

        EVT_SIZE(self, self.OnSize) 
        self.x,self.y = self.GetSize()

    def OnSize(self, event):
        x,y = self.GetSize()
	self.SetSashPosition(self.GetSashPosition()+(x-self.x))
        self.x = x
        self.y = y
        event.Skip()

    def OnEnter(self, event):
        """ Processes chat phrase that we entered. """
        text = self.frame.np.encode(self.mychatphrase.GetLineText(0))
	if len(text) == 0:
	  return
	s = text.split(" ", 1)
	cmd = s[0]
	if len(s) > 1:
	    rest = s[1]
	else:
	    rest = ""
	if cmd in ("/clear", "/cl"):
	    self.chat.Clear()
	elif cmd in ("/join", "/j"):
	    if rest:
	        self.queue.put(slskmessages.JoinRoom(rest))
	elif cmd in ("/leave", "/part", "/l", "/p"):
	    if rest:
		self.queue.put(slskmessages.LeaveRoom(rest))
	    else:
		self.OnLeave(event)
	elif cmd == "/pm":
            if rest:
                self.privatechat.SendMessage(text[4:])
	elif cmd in ("/msg", "/m"):
            if rest:
		l = rest.split(" ",1)
		if len(l) == 2:
	            self.privatechat.SendMessage(l[0],l[1])
	elif cmd in ("/away", "/a"):
	    self.frame.OnAway(event)
	elif cmd in ("/quit", "/q"):
	    self.frame.Close()
	    return
	elif cmd in ("/add", "/ad"):
	    if rest:
	        self.frame.np.userlist.AddToList(rest)
	elif cmd in ("/whois", "/w"):
            if rest:
                self.frame.np.ProcessRequestToPeer(rest, slskmessages.UserInfoRequest(None), self.frame.np.userinfo)
	elif cmd in ("/browse", "/b"):
	    if rest:
                self.frame.np.ProcessRequestToPeer(rest, slskmessages.GetSharedFileList(None), self.frame.np.userbrowse)
        elif cmd == "/ban":
            if rest:
                self.frame.BanUser(rest)
        elif cmd == "/unban":
            if rest:
                self.frame.UnbanUser(rest)
	elif cmd == "/ignore":
	    if rest:
		self.frame.IgnoreUser(rest)
	elif cmd == "/unignore":
	    if rest:
		self.frame.UnignoreUser(rest)
        elif cmd == "/ip":
            if rest:
                self.queue.put(slskmessages.GetPeerAddress(rest))
        elif cmd in ("/search", "/s"):
            if rest:
                self.frame.np.search.DoGlobalSearch(rest)
        elif cmd in ("/bsearch", "/bs"):
            if rest:
        	self.frame.np.search.DoBuddySearch(rest)
        elif cmd in ("/rsearch", "/rs"):
            if rest:
                self.frame.np.search.DoRoomsSearch(rest)
        elif cmd in ("/usearch", "/us"):
            if rest:
                l = rest.split(" ", 1)
                if len(l) == 2:
                    self.frame.np.search.DoPeerSearch(l[1], [l[0]], l[0])
        elif cmd == "/slap":
	    import random
            if rest:
                msg = "/me slaps %s with %s" % (rest, random.choice(("a large trout", "a dictionary", "a rubber duck", "a copy of Windows XP", "a glove", "an empty bottle", "a lawsuit", "a ddos", "google", "a herring")))
                self.queue.put(slskmessages.SayChatroom(self.room, msg))
        elif len(cmd) > 0 and cmd[0] == "/" and cmd != "/me":
            wxLogMessage("Command %s is not recognized" %(text))
	else:
            self.queue.put(slskmessages.SayChatroom(self.room, text))
	    self.frame.SetTitle("PySoulSeek %s" % version)
        self.mychatphrase.Clear()

    def OnPhraseChar(self, event):
	if event.GetKeyCode() == WXK_TAB and not event.ControlDown() and not event.ShiftDown() and not event.AltDown():
	    ip = self.mychatphrase.GetInsertionPoint()
            part = self.mychatphrase.GetLineText(0)[:ip].split(" ")[-1]
            allusers = self.users.keys()
            allusers.extend([i[0] for i in self.frame.np.userlist.userlist])
	    self.mychatphrase.WriteText(GetCompletion(part, allusers))
	else:
	    event.Skip()

    def OnLeave(self, event):
	if self.room is not None:
	    self.queue.put(slskmessages.LeaveRoom(self.room))
	    self.leave.Enable(0)

    """ These functions process various messages from the server. """
    def UserJoinedRoom(self, msg):
        self.room = msg.room
	if not self.users.has_key(msg.username):
            self.info.AppendText("%s %s joined the room\n" %(time.strftime("%X"),msg.username))	
            self.users[msg.username] = msg.userdata
            self.userslist = self.users.keys()
	    if self.userslistctrl.sortcol == -1:
                self.userslistctrl.SortList(0,0)
	    else:
	        self.userslistctrl.SortList(self.userslistctrl.sortcol,self.userslistctrl.sortorder)
            self.userslistctrl.SetItemCount(len(self.users))
	    if wxUSE_UNICODE:
	        self.chat.UserJoined(msg.username)

    def JoinRoom(self, msg):
        self.room = msg.room
        self.users = msg.users
        self.userslist = self.users.keys()
	self.userslistctrl.SortList(0,0)
        self.userslistctrl.SetItemCount(len(self.users))
        if self.logctrl.GetValue() == 1:
            self.OnLogCheckClick(None)
	if self.room in self.frame.np.config.sections["server"]["autojoin"]:
	    self.autojoinctrl.SetValue(1)

#	privileged = self.frame.np.transfers.privilegedusers
#        numprivonline = len([i for i in privileged if i in self.userslist])
#        self.frame.logMessage("Currently %i users online (%i or %.1f" % (len(self.users),numprivonline, float(numprivonline)/len(self.users)*100) + " percent of them are privileged)")
#	for i in self.userslist:
#	    self.queue.put(slskmessages.GetPeerAddress(i))

    def UserLeftRoom(self, msg):
        self.room = msg.room
        if self.users.has_key(msg.username):
            del self.users[msg.username]
            self.info.AppendText("%s %s left the room\n" %(time.strftime("%X"),msg.username))
            self.userslist = self.users.keys()
            if self.userslistctrl.sortcol == -1:
                self.userslistctrl.SortList(0,0)
            else:
                self.userslistctrl.SortList(self.userslistctrl.sortcol,self.userslistctrl.sortorder)
            self.userslistctrl.SetItemCount(len(self.users))
	    if wxUSE_UNICODE:
	        self.chat.UserLeft(msg.username)


    def SayChatRoom(self, msg, text):
	if msg.user in self.frame.np.config.sections["server"]["ignorelist"]:
	    return
        self.room = msg.room
	highlight = False

	if text[:4] == "/me ":
	    str = "%s * %s %s\n" %(time.strftime("%X"),msg.user,text[4:])
	    color = "FOREST GREEN"
	else:
	    str = "%s [%s] %s\n" %(time.strftime("%X"),msg.user,text)
	    if msg.user == self.frame.np.config.sections["server"]["login"]:
		color = wxBLUE
	    elif text.upper().find(self.frame.np.config.sections["server"]["login"].upper()) >= 0:
	        color = wxRED
		highlight = True	
	    else:
		color = None

	if color is not None:
            self.chat.SetDefaultStyle(wxTextAttr(color))
        self.chat.AppendUserText(self.frame.np.decode(str,wxUSE_UNICODE),msg.user,color)
	self.chat.SetDefaultStyle(wxTextAttr())
	self.parent.OnPageUpdated(self, highlight)
        if self.logctrl.GetValue():
            self.logfile.write(self.frame.np.decode(str))

#    def QueuedDownloads(self, msg):
#        self.users[msg.user].slotsfull = msg.slotsfull
#        self.userslistctrl.SetItemCount(len(self.users))

    def GetUserStatus(self, msg):
        if msg.status != self.users[msg.user].status:
            if msg.status == 1:
                text = "%s %s has gone away\n"
            else:
                text = "%s %s has returned\n"
            self.info.AppendText(text %(time.strftime("%X"),msg.user))
            self.users[msg.user].status = msg.status
            self.userslistctrl.SetItemCount(len(self.users))

    def GetUserStats(self, msg):
        self.users[msg.user].avgspeed = msg.avgspeed
        self.users[msg.user].downloadnum = msg.downloadnum
        self.users[msg.user].something = msg.something
        self.users[msg.user].files = msg.files
        self.users[msg.user].dirs = msg.dirs
        self.userslistctrl.Refresh(True)

    def OnLogCheckClick(self, event):
        """ This is called when the 'Log' checkbox is clicked """
        if self.logctrl.GetValue() == 1:
            oldumask = os.umask(0077)
	    logsdir = self.frame.np.config.sections["logging"]["logsdir"]
	    if not os.path.exists(logsdir):
		os.makedirs(logsdir)
            self.logfile = open(os.path.join(logsdir, string.replace(self.room, os.sep, "-") + ".log"), 'a', 0)
            os.umask(oldumask)
        else:
            self.logfile.close()

    def OnAutoJoinClick(self, event):
       if self.autojoinctrl.GetValue() == 1:
           self.frame.np.config.sections["server"]["autojoin"].append(self.room)
           self.frame.np.config.writeConfig()
       else:
           self.frame.np.config.sections["server"]["autojoin"].remove(self.room)
           self.frame.np.config.writeConfig()
	   if self.room == 'pyslsk':
		wxLogMessage("To get back to the pyslsk chatroom, enter its name in the room create textbox")

class PrivateChatNotebook(notebook.IconNotebook):
    """
    This class is a notebook of private chat windows. Actual window 
    pointers are stored in user dictionary.
    """
    def __init__(self, parent, id, queue, np, style=wxCLIP_CHILDREN|wxNB_RIGHT):
        notebook.IconNotebook.__init__(self,parent,id,style = style, frame = np.frame)
        self.users={}
        self.queue = queue
	self.np = np

    def ShowMessage(self, msg, text):
        """ Processes MessageUser message from the server. """
	import time
	if msg.user in self.np.config.sections["server"]["ignorelist"]:
	    return
        if not self.users.has_key(msg.user):
            self.users[msg.user] = PrivateChatWindow(self, -1, msg.user)
            self.AddPage(self.users[msg.user], msg.user)
       	    self.np.queue.put(slskmessages.GetUserStatus(msg.user))
	timestamp = self.np.encode(time.strftime("%c",time.localtime()))
	if text[:4] == "/me ":
	    str = "%s * %s %s\n" %(timestamp,msg.user,text[4:])
	    color = "FOREST GREEN"
	else:
	    str = "%s [%s] %s\n" %(timestamp,msg.user,text)
	    color = None
	self.users[msg.user].AddText(self.np.decode(str,wxUSE_UNICODE),color)
	self.np.frame.OnPageUpdated(self)
	self.OnPageUpdated(self.users[msg.user])
	self.np.frame.SetTitle("(*) PySoulSeek %s" % version)
        if self.users[msg.user].logctrl.GetValue():
            self.users[msg.user].logfile.write(self.np.decode(str))

    def SendMessage(self, user, message = None):
        """ Adds a notebook tab with a user's name on it, and private chat 
        window inside the tab
        """
        if not self.users.has_key(user):
            self.users[user] = PrivateChatWindow(self, -1, user)
            self.AddPage(self.users[user],user)
	    self.np.queue.put(slskmessages.GetUserStatus(user))
	if message:
	    self.users[user].SendMessage(message)

    def GetUserStatus(self, msg):
	if self.users.has_key(msg.user):
	    for i in range(self.GetPageCount()):
	        if self.GetPage(i) == self.users[msg.user] and self.GetPage(i).status != msg.status:
		    self.users[msg.user].status = msg.status
		    str = "%s * %s's status is unknown"
		    color = "RED3"
		    if msg.status == 0:
			self.SetPageText(i, msg.user + " (offline)")
			str = "%s * %s is offline\n"
		    elif msg.status == 1:
			self.SetPageText(i, msg.user + " (away)")
			str = "%s * %s is away\n"
                    elif msg.status == 2:
                        self.SetPageText(i, msg.user + " (online)")
			str = "%s * %s is online\n"
		    str = str %(time.strftime("%c",time.localtime()),msg.user)
		    self.users[msg.user].AddText(str,color)
                    if self.users[msg.user].logctrl.GetValue():
                        self.users[msg.user].logfile.write(str)

class PrivateChatWindow(wxPanel):
    """ This is a window for chatting with someone in private """
    def __init__(self, parent, id, user):
        wxPanel.__init__(self, parent, id)
        self.chat = wxTextCtrl(self,-1,style = wxTE_MULTILINE|wxTE_READONLY|wxTE_RICH2)
        self.mychatphrase = wxTextCtrl(self,-1, style = wxTE_PROCESS_ENTER|wxTE_PROCESS_TAB)
	EVT_CHAR(self.mychatphrase, self.OnPhraseChar)
        self.close = wxButton(self, -1, "Close")
        self.logctrl = wxCheckBox(self, -1, "Log");
        self.logctrl.SetValue(parent.np.config.sections["logging"]["privatechat"])
        EVT_CHECKBOX(self, self.logctrl.GetId(), self.OnLogCheckClick)
        
        sizerh = wxBoxSizer(wxHORIZONTAL)
        sizerh.Add(self.mychatphrase,1,wxEXPAND)
        sizerh.Add(self.logctrl,0,wxEXPAND)
        sizerh.Add(self.close,0,wxEXPAND)
        sizerv = wxBoxSizer(wxVERTICAL)
        sizerv.Add(self.chat,1,wxEXPAND)
        sizerv.Add(sizerh,0,wxEXPAND)

        self.SetSizer(sizerv)
        self.SetAutoLayout(True)
        EVT_BUTTON(self,self.close.GetId(), self.OnClose)
        EVT_TEXT_ENTER(self,self.mychatphrase.GetId(),self.OnEnter)

        self.menu = wxMenu()
        showipID=wxNewId()
        self.menu.Append(showipID, 'Show IP address')
        EVT_MENU(self,showipID, self.OnShowIp)
        getinfoID=wxNewId()
        self.menu.Append(getinfoID, 'Get User Info')
        EVT_MENU(self,getinfoID, self.OnGetInfo)
        browseID=wxNewId()
        self.menu.Append(browseID, 'Browse Files')
        EVT_MENU(self,browseID, self.OnBrowse)
        addtolistID=wxNewId()
        self.menu.Append(addtolistID, 'Add to User List')
        EVT_MENU(self,addtolistID, self.OnAddToList)
        banuserID=wxNewId()
        self.menu.Append(banuserID, "Ban this user")
        EVT_MENU(self,banuserID, self.OnBanUser)
        ignoreuserID=wxNewId()
        self.menu.Append(ignoreuserID, "Ignore this user")
        EVT_MENU(self,ignoreuserID, self.OnIgnoreUser)

        EVT_RIGHT_UP(self.chat,self.OnRightUp)

        self.user = user
        self.parent = parent
	self.status = -1
        self.logfile = None

        if self.logctrl.GetValue() == 1:
            self.OnLogCheckClick(None)

    def OnRightUp(self,event):
        pt = event.GetPosition()
        self.PopupMenu(self.menu, pt)

    def OnShowIp(self, event):
        self.parent.queue.put(slskmessages.GetPeerAddress(self.user))

    def OnGetInfo(self, event):
        self.parent.np.ProcessRequestToPeer(self.user, slskmessages.UserInfoRequest(None), self.parent.np.userinfo)

    def OnBrowse(self, event):
        self.parent.np.ProcessRequestToPeer(self.user, slskmessages.GetSharedFileList(None), self.parent.np.userbrowse)

    def OnAddToList(self, event):
        self.parent.np.userlist.AddToList(self.user)

    def OnBanUser(self, event):
        self.parent.np.frame.BanUser(self.user)

    def OnIgnoreUser(self, event):
        self.parent.np.frame.IgnoreUser(self.user)

    def AddText(self,text, color = None):
        """ Rather obvious really """
	style = self.chat.GetDefaultStyle()
	if color is not None:
	    self.chat.SetDefaultStyle(wxTextAttr(color))
        self.chat.AppendText(text)
	self.chat.SetDefaultStyle(wxTextAttr())

    def OnClose(self, event):
        """ Close the window and update notebook's window list."""
	parent = self.parent
        del parent.users[self.user]
	parent.DeletePage(parent.GetSelection())
	if parent.GetPageCount() > 0:
	    parent.SetSelection(0)

    def SendMessage(self, text):
	username = self.parent.np.config.sections["server"]["login"]
        timestamp = self.parent.np.encode(time.strftime("%c",time.localtime()))
        if text[:4] == "/me ":
	    str = "%s * %s %s\n" %(timestamp,username,text[4:])
            color = "FOREST GREEN"
        else:
            str = "%s %s\n" %(timestamp,text)
            color = wxBLUE

	if len(text) > 0:
	    self.AddText(self.parent.np.decode(str, wxUSE_UNICODE), color)
            self.parent.queue.put(slskmessages.MessageUser(self.user, text))
	    self.parent.np.frame.SetTitle("PySoulSeek %s" % version)
            if self.logctrl.GetValue():
                self.logfile.write(self.parent.np.decode(str))

    def OnEnter(self, event):
        """ Sends our chat phrase and updates the window."""
        text = self.parent.np.encode(self.mychatphrase.GetLineText(0))
	s = text.split(" ", 1)
	cmd = s[0]
	if len(s) > 1:
	    rest = s[1]
	else:
	    rest = ""
	if not rest:
	    rest = self.user
	    truerest = ""
	else:
	    truerest = rest
	if cmd in ("/away", "/a"):
	    self.parent.np.frame.OnAway(event)
	elif cmd in ("/clear", "/cl"):
	    self.chat.Clear()
	elif cmd in ("/quit", "/q"):
	    self.parent.np.frame.Close()
	    return
	elif cmd in ("/close", "/c"):
	    self.OnClose(event)
	    return
	elif cmd in ("/add", "/ad"):
	    self.parent.np.userlist.AddToList(rest)
	elif cmd in ("/whois", "/w"):
            self.parent.np.ProcessRequestToPeer(rest, slskmessages.UserInfoRequest(None), self.parent.np.userinfo)
	elif cmd in ("/browse", "/b"):
            self.parent.np.ProcessRequestToPeer(rest, slskmessages.GetSharedFileList(None), self.parent.np.userbrowse)
        elif cmd == "/ban":
            self.parent.np.frame.BanUser(rest)
        elif cmd == "/unban":
            self.parent.np.frame.UnbanUser(rest)
	elif cmd == "/ignore":
	    self.parent.np.frame.IgnoreUser(rest)
	elif cmd == "/unignore":
	    self.parent.np.frame.UnignoreUser(rest)
	elif cmd == "/ip":
            self.parent.queue.put(slskmessages.GetPeerAddress(rest))
        elif cmd in ("/search", "/s"):
            if truerest:
                self.parent.np.search.DoGlobalSearch(truerest)
        elif cmd in ("/bsearch", "/bs"):
            if truerest:
                self.parent.np.search.DoBuddySearch(rest)
        elif cmd in ("/rsearch", "/rs"):
            if rest:
                self.parent.np.search.DoRoomsSearch(rest)
        elif cmd in ("/usearch", "/us"):
            if truerest:
                self.parent.np.search.DoPeerSearch(truerest, [self.user], self.user)

	elif len(cmd) > 0 and cmd[0] == "/" and cmd != "/me":
	    wxLogMessage("Command %s is not recognized" %(text))
	else:
            self.SendMessage(text)
        self.mychatphrase.Clear()

    def OnPhraseChar(self, event):
	if event.GetKeyCode() == WXK_TAB and not event.ControlDown() and not event.ShiftDown() and not event.AltDown():
	    ip = self.mychatphrase.GetInsertionPoint()
            part = self.mychatphrase.GetLineText(0)[:ip].split(" ")[-1]
            allusers = [i[0] for i in self.parent.np.userlist.userlist]
            allusers.append(self.user)
            self.mychatphrase.WriteText(GetCompletion(part, allusers))
	else:
	    event.Skip()

    def OnLogCheckClick(self, event):
        """ This is called when the 'Log' checkbox is clicked """
        if self.logctrl.GetValue() == 1:
            oldumask = os.umask(0077)
	    logsdir = self.parent.np.config.sections["logging"]["logsdir"]
	    if not os.path.exists(logsdir):
		os.makedirs(logsdir)
            self.logfile = open(os.path.join(logsdir, string.replace(self.user, os.sep, "-") + ".log"), 'a', 0)
            os.umask(oldumask)
        else:
            self.logfile.close()
