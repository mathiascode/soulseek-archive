# Copyright (c) 2001-2003 Alexander Kanavin. All rights reserved.

"""
This module contains configuration classes for pyslsk.
"""

import ConfigParser
import string
import os.path
import os,stat
from pysoulseek import mp3
from pysoulseek import utils

from wxPython.wx import *

def encode(str):
    import locale,types
    try:
        localenc = locale.nl_langinfo(locale.CODESET)
        if type(str) is types.UnicodeType:
            return str.encode(localenc,'replace')
	else:
	    return str	
    except:
        return str



class ServerList(wxListCtrl):
    """ This is a list control that contains list of official servers """
    def __init__(self,parent,id, size, style = wxLC_REPORT|wxLC_VIRTUAL|wxSUNKEN_BORDER):
	wxListCtrl.__init__(self,parent,id, style = style, size = size)
	self.InsertColumn(0,"Description", width=250)
	self.InsertColumn(1,"Hostname",width=150)
	self.SetItemCount(0)

    def setList(self,list):
	self.SetItemCount(len(list))
	self.list = list

    def OnGetItemText(self, item,col):
	return self.list[item][col]

    def OnGetItemImage(self,item):
	return -1

class ServerChoose(wxDialog):
    """ This class defines a servers list window that is used to let user
	select one of the official servers from the list """
    def __init__(self,parent,id, title):
	wxDialog.__init__(self,parent,id,title)

	self.serverlistctrl = ServerList(self, -1, size=wxSize(420,200))
        self.ok = wxButton(self, wxID_OK, "OK")
        self.ok.SetDefault()
        self.cancel = wxButton(self, wxID_CANCEL, "Cancel")

        buttonssizer = wxBoxSizer(wxHORIZONTAL)
        buttonssizer.Add(self.ok)
        buttonssizer.Add((60,20))
        buttonssizer.Add(self.cancel)

        mainsizer = wxBoxSizer(wxVERTICAL)
        mainsizer.Add(self.serverlistctrl,flag=wxALL, border = 10)
        mainsizer.Add(buttonssizer,flag=wxALL|wxALIGN_CENTER, border = 10)
        self.SetSizer(mainsizer)
        self.SetAutoLayout(True)
        mainsizer.Fit(self)
	self.CenterOnParent()

	serverlist=utils.getServerList("http://www.slsk.org/slskinfo2")
	self.serverlistctrl.setList(serverlist)

    def getServer(self):
	item = self.serverlistctrl.GetNextItem(-1,wxLIST_NEXT_ALL,wxLIST_STATE_SELECTED)
	if item == -1:
	    return None
	else:
	    return self.serverlistctrl.list[item][1]

class UserList(wxPanel):
    def __init__(self, parent, id, size, label):
	wxPanel.__init__(self, parent, id, size=size)
	self.label = wxStaticText(self, -1, label)
	self.listbox = wxListBox(self, -1, style=wxLB_EXTENDED)
	self.removeButton = wxButton(self, -1, "Remove")
	self.addButton = wxButton(self, -1, "Add...")
	self.clearButton = wxButton(self, -1, "Clear")

	EVT_BUTTON(self, self.clearButton.GetId(), self.OnClear)
	EVT_BUTTON(self, self.removeButton.GetId(), self.OnRemove)
	EVT_BUTTON(self, self.addButton.GetId(), self.OnAdd)

	sizer = wxBoxSizer(wxVERTICAL)
	sizer.Add(self.label)
	sizer.Add(self.listbox, 1, flag=wxEXPAND)
	sizer.Add(self.removeButton, flag=wxEXPAND)
	sizer.Add(self.clearButton, flag=wxEXPAND)
	sizer.Add(self.addButton, flag=wxEXPAND|wxTOP, border=10)
	self.SetSizer(sizer)
	self.SetAutoLayout(True)
	sizer.Fit(self)
	
    def OnClear(self,event):
        self._list = []
        self.listbox.Set(self._list)

    def OnRemove(self,event):
        sel = self.listbox.GetSelections()
        list = self._list[:]
        for item in sel:
            self._list.remove(list[item])
        self.listbox.Set(self._list)

    def OnAdd(self,event):
	dlg = wxTextEntryDialog(self, "Username:", caption = "Add user to list")
	if (dlg.ShowModal() == wxID_OK):
	    user = encode(dlg.GetValue())
	    if user and not user in self._list:
		self._list.append(user)
		self.setList(self._list)
	dlg.Destroy()

    def getList(self):
        return self._list

    def setList(self, list):
        self._list = list[:]
        self._list.sort()
        self.listbox.Set(self._list)

class ServerPanel(wxPanel):
    def __init__(self,parent, encodings):
	wxPanel.__init__(self, parent, -1)

        self.serverctrl = wxTextCtrl(self,-1,size=wxSize(250, 25))
        self.loginctrl = wxTextCtrl(self,-1,size=wxSize(100, 25))
        self.passwctrl = wxTextCtrl(self,-1,size=wxSize(100, 25), style = wxTE_PASSWORD)
#        self.serverchoose = wxButton(self, -1, "Choose...")
#        EVT_BUTTON(self,self.serverchoose.GetId(),self.OnServerChoose)
        self.enc = wxComboBox(self, -1, style = wxCB_DROPDOWN|wxCB_READONLY|wxCB_SORT,choices = encodings)
        self.enc.SetSelection(0)
        self.firstport = wxTextCtrl(self, -1, size=wxSize(50,25))
        self.lastport = wxTextCtrl(self, -1, size=wxSize(50,25))

        hostsizer = wxBoxSizer(wxHORIZONTAL)
        hostsizer.Add(self.serverctrl)
#        hostsizer.Add(self.serverchoose,flag=wxALIGN_CENTER)

        portsizer = wxBoxSizer(wxHORIZONTAL)
        portsizer.Add(self.firstport, flag=wxRIGHT, border=5)
        portsizer.Add(wxStaticText(self, -1, "-"),flag=wxALIGN_CENTER|wxRIGHT, border=5)
        portsizer.Add(self.lastport)

        serversizer = wxStaticBoxSizer(wxStaticBox(self,-1,"Server settings:"),wxVERTICAL)
        serversizer.Add(wxStaticText(self, -1, "Server (if server.slsknet.org:2240 doesn't work, \ncheck http://www.sensi.org/~ak/pyslsk/ \nfor a newer client version):"),flag=wxTOP|wxLEFT, border = 10)
        serversizer.Add(hostsizer,flag=wxLEFT|wxRIGHT, border = 10)
        serversizer.Add(wxStaticText(self, -1, "Login:"),flag=wxTOP|wxLEFT, border = 10)
        serversizer.Add(self.loginctrl,flag=wxLEFT, border = 10)
        serversizer.Add(wxStaticText(self, -1, "Password:"),flag=wxTOP|wxLEFT, border = 10)
        serversizer.Add(self.passwctrl,flag=wxLEFT, border = 10)
        serversizer.Add(wxStaticText(self, -1, "Network character encoding (if not sure, choose utf-8):"),flag=wxTOP|wxLEFT, border = 10)
        serversizer.Add(self.enc,flag=wxLEFT, border = 10)
        serversizer.Add(wxStaticText(self, -1, "Listen on the first available port from this range:"),flag=wxTOP|wxLEFT, border = 10)
        serversizer.Add(portsizer,flag=wxLEFT, border = 10)
        awaysizer = wxBoxSizer(wxHORIZONTAL)
        awaysizer.Add(wxStaticText(self, -1, "Toggle status to 'away' after "),flag=wxALIGN_CENTER)
        self.autoaway = wxTextCtrl(self,-1,size=wxSize(30, 25))
        awaysizer.Add(self.autoaway)
        awaysizer.Add(wxStaticText(self, -1, " minutes of inactivity"),flag=wxALIGN_CENTER)
        serversizer.Add(awaysizer,flag=wxTOP|wxLEFT, border = 10)

	self.SetSizer(serversizer)
	self.SetAutoLayout(True)

    def OnServerChoose(self,event):
        serverchoose = ServerChoose(self,-1,"Choose server")
        val = serverchoose.ShowModal()
        if val == wxID_OK:
            server = serverchoose.getServer()
            if server is not None:
                self.serverctrl.SetValue(server)

class TransfersPanel(wxPanel):
    def __init__(self,parent, configwindow):
        wxPanel.__init__(self, parent, -1)
	self.configwindow = configwindow

	self.downloaddirctrl = wxTextCtrl(self,-1,size=wxSize(250, 25))
	self.uploaddirsctrl = wxListBox(self, -1, size=wxSize(250,100))
	self.uploadbandwidth = wxTextCtrl(self,-1,size=wxSize(30, 25))
	self.downloaddirchoose = wxButton(self, -1, "Choose...")
	self.sharedownloadctrl = wxCheckBox(self, -1, "Share download directory")
	self.uploaddiradd = wxButton(self, -1, "Add...")
	self.uploaddirrem = wxButton(self, -1, "Remove")
        self.uploaddirrescan = wxButton(self, -1, "Rescan")
	self.rescanonstartup = wxCheckBox(self, -1, "Rescan shares on startup")
        self.useuploadlimit = wxCheckBox(self, -1, "Limit upload speed to ")
        self.uploadlimit = wxTextCtrl(self, -1, size=wxSize(30,25))
        self.limittransfer = wxRadioButton(self, -1, "per transfer", style=wxRB_GROUP)
        self.limittotal = wxRadioButton(self, -1, "total for all transfers")
	self.queuelimit = wxTextCtrl(self, -1, size=wxSize(30,25))
	
	EVT_BUTTON(self,self.downloaddirchoose.GetId(),self.OnDownloadChoose)
	EVT_BUTTON(self,self.uploaddiradd.GetId(),self.OnUploadAdd)
	EVT_BUTTON(self,self.uploaddirrem.GetId(),self.OnUploadRem)
        EVT_BUTTON(self,self.uploaddirrescan.GetId(),self.OnUploadRescan)
	EVT_CHECKBOX(self,self.sharedownloadctrl.GetId(),self.OnShareDownload)
        EVT_CHECKBOX(self,self.useuploadlimit.GetId(),self.OnUseUploadLimit)

	downloadsizer = wxBoxSizer(wxHORIZONTAL)
        downloadsizer.Add(self.downloaddirctrl)
        downloadsizer.Add(self.downloaddirchoose,flag=wxALIGN_CENTER)
	
	uploadbuttonssizer = wxBoxSizer(wxVERTICAL)
        uploadbuttonssizer.Add(self.uploaddiradd)
        uploadbuttonssizer.Add(self.uploaddirrem)
        uploadbuttonssizer.Add(self.uploaddirrescan)

	uploadsizer = wxBoxSizer(wxHORIZONTAL)
	uploadsizer.Add(self.uploaddirsctrl)
	uploadsizer.Add(uploadbuttonssizer)

	bandwidthsizer = wxBoxSizer(wxHORIZONTAL)
	bandwidthsizer.Add(self.uploadbandwidth, flag=wxLEFT, border=10)
	bandwidthsizer.Add(wxStaticText(self, -1, " KBytes/sec"),flag=wxALIGN_CENTER)

        limitsizer = wxFlexGridSizer(cols=4, rows=2)
	limitsizer.Add(self.useuploadlimit, border = 10)
        limitsizer.Add(self.uploadlimit, border = 10)
        limitsizer.Add(wxStaticText(self, -1, " KBytes/sec "), flag = wxALIGN_CENTER_VERTICAL)
	limitsizer.Add((0,0))
	limitsizer.Add((0,0))
	limitsizer.Add((0,0))
        limitsizer.Add(self.limittransfer)
        limitsizer.Add((0,0))
	limitsizer.Add((0,0))
        limitsizer.Add((0,0))
        limitsizer.Add(self.limittotal)

	queuesizer = wxBoxSizer(wxHORIZONTAL)
	queuesizer.Add(wxStaticText(self, -1, "A user may queue a maximum of "),flag=wxALIGN_CENTER)
	queuesizer.Add(self.queuelimit)
	queuesizer.Add(wxStaticText(self, -1, " megabytes"),flag=wxALIGN_CENTER)

	transferssizer = wxStaticBoxSizer(wxStaticBox(self,-1,"Transfers settings:"),wxVERTICAL)
	transferssizer.Add(wxStaticText(self, -1, "Download directory:"),flag=wxTOP|wxLEFT, border = 10)
	transferssizer.Add(downloadsizer,flag=wxLEFT|wxRIGHT, border = 10)
	transferssizer.Add(self.sharedownloadctrl,flag=wxLEFT|wxTOP, border = 10)
	transferssizer.Add(wxStaticText(self, -1, "Shared directories:"),flag=wxTOP|wxLEFT, border = 10)
	transferssizer.Add(uploadsizer, flag=wxLEFT|wxRIGHT, border = 10)
	transferssizer.Add(self.rescanonstartup, flag=wxLEFT|wxTOP, border = 10)
	transferssizer.Add(wxStaticText(self, -1, "Locally queue uploads if total upload speed exceeds:"),flag=wxTOP|wxLEFT, border = 10)
	transferssizer.Add(bandwidthsizer,flag=wxLEFT|wxBOTTOM, border = 10)
	transferssizer.Add(limitsizer, flag=wxLEFT|wxBOTTOM, border = 10)
	transferssizer.Add(queuesizer, flag=wxLEFT, border = 10)

	self.needrescan = 0

	self.SetSizer(transferssizer)
	self.SetAutoLayout(True)


    def OnDownloadChoose(self,event):
	downloadchoose = wxDirDialog(self)
	val = downloadchoose.ShowModal()
	if val == wxID_OK:
	    dir = downloadchoose.GetPath()
	    if dir is not None:
		self.downloaddirctrl.SetValue(dir)
	    if self.sharedownloadctrl.GetValue():
		self.needrescan = 1

    def OnShareDownload(self,event):
	self.needrescan = 1

    def OnUploadAdd(self,event):
        uploadadd = wxDirDialog(self)
        val = uploadadd.ShowModal()
        if val == wxID_OK:
            dir = uploadadd.GetPath()
            if dir is not None:
                self.uploaddirsctrl.Append(dir)
	self.needrescan = 1

    def OnUploadRem(self,event):
	num = self.uploaddirsctrl.GetSelection()
	if num>=0:
	    self.uploaddirsctrl.Delete(num)
	    self.needrescan = 1

    def OnUploadRescan(self,event):
	self.configwindow.Enable(0)
	self.rescandirs()
	self.needrescan = 0
	self.configwindow.Enable(1)


    def OnUseUploadLimit(self,event):
        enabled = self.useuploadlimit.GetValue()
        self.uploadlimit.Enable(enabled)
        self.limittransfer.Enable(enabled)
        self.limittotal.Enable(enabled)

    def rescandirs(self):
	shared = []
        for i in range(self.uploaddirsctrl.Number()):
            shared.append(encode(self.uploaddirsctrl.GetString(i)))
	if self.sharedownloadctrl.GetValue():
	    shared.append(encode(self.downloaddirctrl.GetValue()))
	self.sharedfiles,self.sharedfilesstreams,self.wordindex, self.fileindex,self.sharedmtimes = utils.rescandirs(shared, self.sharedmtimes, self.sharedfiles, self.sharedfilesstreams, wxYield)

class UserinfoPanel(wxPanel):
    def __init__(self,parent):
        wxPanel.__init__(self, parent, -1)

	self.descr = wxTextCtrl(self,-1,size=wxSize(250,100),style = wxTE_MULTILINE|wxTE_RICH)
	self.pic = wxTextCtrl(self,-1,size=wxSize(250, 25))
	self.picchoose = wxButton(self, -1, "Choose...")
	EVT_BUTTON(self,self.picchoose.GetId(),self.OnPicChoose)

	picsizer = wxBoxSizer(wxHORIZONTAL)
	picsizer.Add(self.pic)
	picsizer.Add(self.picchoose,flag=wxALIGN_CENTER)

	userinfosizer = wxStaticBoxSizer(wxStaticBox(self,-1,"Personal settings:"),wxVERTICAL)
	userinfosizer.Add(wxStaticText(self, -1, "Self-description:"),flag=wxTOP|wxLEFT, border = 10)
	userinfosizer.Add(self.descr,1,flag=wxLEFT|wxRIGHT, border = 10)
	userinfosizer.Add(wxStaticText(self, -1, "Picture:"),flag=wxTOP|wxLEFT, border = 10)
	userinfosizer.Add(picsizer,flag=wxLEFT|wxBOTTOM, border = 10)

	self.SetSizer(userinfosizer)
	self.SetAutoLayout(True)

    def OnPicChoose(self,event):
	picchoose = wxFileDialog(self)
	val = picchoose.ShowModal()
	if val == wxID_OK:
            pic = picchoose.GetPath()
            if pic is not None:
                self.pic.SetValue(pic)


class MiscPanel(wxPanel):
    def __init__(self,parent):
        wxPanel.__init__(self, parent, -1)

	self.logsdirctrl = wxTextCtrl(self,-1,size=wxSize(250, 25))
	self.logsdirchoose = wxButton(self, -1, "Choose...")
	EVT_BUTTON(self,self.logsdirchoose.GetId(),self.OnLogsChoose)
	logssizer = wxBoxSizer(wxHORIZONTAL)
        logssizer.Add(self.logsdirctrl)
        logssizer.Add(self.logsdirchoose,flag=wxALIGN_CENTER)
	
        miscsizer=wxStaticBoxSizer(wxStaticBox(self,-1,"Misc settings:"),wxVERTICAL)
	self.loggingprivatectrl = wxCheckBox(self, -1, "Log private chat by default")
        miscsizer.Add(self.loggingprivatectrl, flag = wxLEFT|wxTOP, border = 10)
        self.loggingchatctrl = wxCheckBox(self, -1, "Log chatrooms by default")
        miscsizer.Add(self.loggingchatctrl, flag = wxLEFT, border = 10)
	miscsizer.Add(wxStaticText(self, -1, "Logs directory:"),flag=wxLEFT, border = 10)
	miscsizer.Add(logssizer,flag=wxLEFT, border = 10)
	
	resultssizer = wxBoxSizer(wxHORIZONTAL)
        resultssizer.Add(wxStaticText(self, -1, "Return the max of "),flag=wxALIGN_CENTER)
	self.maxresults = wxTextCtrl(self,-1,size=wxSize(30, 25))
        resultssizer.Add(self.maxresults)
        resultssizer.Add(wxStaticText(self, -1, " results per search request"),flag=wxALIGN_CENTER)
	miscsizer.Add(resultssizer,flag=wxTOP|wxLEFT, border = 10)

	self.banlist = UserList(self, -1, wxSize(150,0), "Banned users:")
	self.ignorelist = UserList(self, -1, wxSize(150,0), "Ignored users:")
	badpeoplesizer = wxBoxSizer(wxHORIZONTAL)
	badpeoplesizer.Add(self.banlist, 1, flag=wxALIGN_CENTER|wxTOP|wxEXPAND, border=15)
	badpeoplesizer.Add(self.ignorelist, 1, flag=wxALIGN_CENTER|wxTOP|wxEXPAND, border=15)
	miscsizer.Add(badpeoplesizer, 1, flag=wxALIGN_CENTER|wxTOP|wxEXPAND, border=5 )

	custombansizer = wxBoxSizer(wxHORIZONTAL)
	self.usecustomban = wxCheckBox(self, -1, "Use custom ban message:")
	custombansizer.Add(self.usecustomban)
	self.customban = wxTextCtrl(self, -1)
	custombansizer.Add(self.customban, 1, flag=wxEXPAND|wxLEFT, border=5)
	miscsizer.Add(custombansizer, flag=wxLEFT|wxTOP|wxEXPAND|wxRIGHT, border=10)

	self.SetSizer(miscsizer)
        self.SetAutoLayout(True)

    def OnLogsChoose(self,event):
        logschoose = wxDirDialog(self)
        val = logschoose.ShowModal()
        if val == wxID_OK:
            dir = logschoose.GetPath()
            if dir is not None:
                self.logsdirctrl.SetValue(dir)


class ConfigWindow(wxDialog):
    """
    This class defines a settings window that the main application should 
    display on request. 

    Methods:
    SetSettings(config) - fills widgets in the window 
    with provided values
    GetSettings - returns a tuple of settings from window widgets (possibly 
    modified by user
    """
    def __init__(self, parent, id, title):
	wxDialog.__init__(self,parent,id,title)

	self.parent = parent
	nb = wxNotebook(self, -1)
	nbs = wxNotebookSizer(nb)
	self.serverpanel = ServerPanel(nb, parent.np.getencodings())
	self.transferspanel = TransfersPanel(nb, self)
	self.userinfopanel = UserinfoPanel(nb)
	self.miscpanel = MiscPanel(nb)
	nb.AddPage(self.serverpanel,"Server")
	nb.AddPage(self.transferspanel,"Transfers")
	nb.AddPage(self.userinfopanel,"Personal info")
	nb.AddPage(self.miscpanel,"Miscellaneous")



	self.ok = wxButton(self, wxID_OK, "OK")
	self.ok.SetDefault()
	self.cancel = wxButton(self, wxID_CANCEL, "Cancel")

	buttonssizer = wxBoxSizer(wxHORIZONTAL)
	buttonssizer.Add(self.ok)
	buttonssizer.Add((60,20))
	buttonssizer.Add(self.cancel)

	mainsizer = wxBoxSizer(wxVERTICAL)
	mainsizer.Add(nbs,flag=wxALL,border=5)
	mainsizer.Add(buttonssizer,flag=wxALL|wxALIGN_CENTER, border = 10)
	self.SetSizer(mainsizer)
	self.SetAutoLayout(True)
	mainsizer.Fit(self)

	EVT_BUTTON(self, self.ok.GetId(),self.OnOk) 

    def OnOk(self, event):
	self.Enable(0)
	self.parent.SettingsClosed()
	self.Enable(1)
	event.Skip()

    def SetSettings(self, config):
	server = config.sections["server"]
	transfers = config.sections["transfers"]
	userinfo = config.sections["userinfo"]
        logging = config.sections["logging"]
	searches = config.sections["searches"]
	if server["server"] is not None:
    	    self.serverpanel.serverctrl.SetValue(string.join([str(i) for i in server["server"]],":"))
	if server["login"] is not None:
	    self.serverpanel.loginctrl.SetValue(server["login"])
	if server["passw"] is not None:
	    self.serverpanel.passwctrl.SetValue(server["passw"])
	if server["enc"] is not None:
	    self.serverpanel.enc.SetValue(server["enc"])
	if server["banlist"] is not None:
	    self.miscpanel.banlist.setList(server["banlist"])
	if server["ignorelist"] is not None:
	    self.miscpanel.ignorelist.setList(server["ignorelist"])
	if server["portrange"] is not None:
	    self.serverpanel.firstport.SetValue(str(server["portrange"][0]))
	    self.serverpanel.lastport.SetValue(str(server["portrange"][1]))
	if server["autoaway"] is not None:
	    self.serverpanel.autoaway.SetValue(str(server["autoaway"]))
	if transfers["downloaddir"] is not None:
	    self.transferspanel.downloaddirctrl.SetValue(transfers["downloaddir"])
	if transfers["shared"] is not None:
	    self.transferspanel.uploaddirsctrl.Clear()
	    for i in transfers["shared"]:
		self.transferspanel.uploaddirsctrl.Append(i)
	if transfers["sharedfiles"] is not None:
	    self.transferspanel.sharedfiles = transfers["sharedfiles"]
	if transfers["sharedfilesstreams"] is not None:
	    self.transferspanel.sharedfilesstreams = transfers["sharedfilesstreams"]
	if transfers["wordindex"] is not None:
	    self.transferspanel.wordindex = transfers["wordindex"]
        if transfers["fileindex"] is not None:
            self.transferspanel.fileindex = transfers["fileindex"]
        if transfers["sharedmtimes"] is not None:
            self.transferspanel.sharedmtimes = transfers["sharedmtimes"]
	if transfers["rescanonstartup"] is not None:
	    self.transferspanel.rescanonstartup.SetValue(transfers["rescanonstartup"])
	if transfers["uploadbandwidth"] is not None:
	    self.transferspanel.uploadbandwidth.SetValue(str(transfers["uploadbandwidth"]))
	if transfers["uselimit"] is not None:
	    self.transferspanel.useuploadlimit.SetValue(transfers["uselimit"])
	if transfers["uploadlimit"] is not None:
	    self.transferspanel.uploadlimit.SetValue(str(transfers["uploadlimit"]))
	if transfers["limitby"] is not None:
	    self.transferspanel.limittotal.SetValue(transfers["limitby"])
	self.transferspanel.OnUseUploadLimit(None)
	if transfers["sharedownloaddir"] is not None:
	    self.transferspanel.sharedownloadctrl.SetValue(transfers["sharedownloaddir"])
	if transfers["queuelimit"] is not None:
	    self.transferspanel.queuelimit.SetValue(str(transfers["queuelimit"]))
	if transfers["usecustomban"] is not None:
	    self.miscpanel.usecustomban.SetValue(transfers["usecustomban"])
	if transfers["customban"] is not None:
	    self.miscpanel.customban.SetValue(transfers["customban"])
	if userinfo["descr"] is not None:
	    self.userinfopanel.descr.SetValue(eval(userinfo["descr"]))
	if userinfo["pic"] is not None:
	    self.userinfopanel.pic.SetValue(userinfo["pic"])
	if logging["logsdir"] is not None:
	    self.miscpanel.logsdirctrl.SetValue(logging["logsdir"])
        if logging["privatechat"] is not None:
            self.miscpanel.loggingprivatectrl.SetValue(logging["privatechat"])
        if logging["chatrooms"] is not None:
            self.miscpanel.loggingchatctrl.SetValue(logging["chatrooms"])
	if searches["maxresults"] is not None:
	    self.miscpanel.maxresults.SetValue(str(searches["maxresults"]))


    def GetSettings(self):
        try:
            server = string.split(encode(self.serverpanel.serverctrl.GetValue()),":")
            server[1] = int(server[1])
	    server = tuple(server)
        except:
            server = None
	try:
	    autoaway = int(encode(self.serverpanel.autoaway.GetValue()))
	except:
	    autoaway = None
	shared = []
	for i in range(self.transferspanel.uploaddirsctrl.Number()):
	    shared.append(encode(self.transferspanel.uploaddirsctrl.GetString(i)))
	if self.transferspanel.needrescan:
	    self.transferspanel.rescandirs()
	    self.transferspanel.needrescan = 0 
	try:
	    uploadbandwidth = int(encode(self.transferspanel.uploadbandwidth.GetValue()))
	except:
	    uploadbandwidth = None
	try:
	    uploadlimit = int(encode(self.transferspanel.uploadlimit.GetValue()))
	except:
	    uploadlimit = None
        try:
	    queuelimit = int(encode(self.transferspanel.queuelimit.GetValue()))
	except:
	    queuelimit = None
	try:
	    maxresults = int(encode(self.miscpanel.maxresults.GetValue()))
	except:
	    maxresults = None
	try:
	    firstport = int(encode(self.serverpanel.firstport.GetValue()))
	    lastport = int(encode(self.serverpanel.lastport.GetValue()))
	    if firstport < 1:
	        firstport = 2234
	    if lastport < firstport:
	        lastport = firstport
	    portrange = (firstport, lastport)
	except:
	    portrange = (2234, 2239)
	banlist = []
	for i in self.miscpanel.banlist.getList():
	    banlist.append(encode(i))
	ignorelist = []
	for i in self.miscpanel.ignorelist.getList():
	    ignorelist.append(encode(i))
	return {"server":{"server":server, \
		"login":encode(self.serverpanel.loginctrl.GetValue()), \
		"passw":encode(self.serverpanel.passwctrl.GetValue()), \
		"banlist":banlist, \
		"ignorelist":ignorelist, \
		"portrange":portrange, \
		"autoaway":autoaway, \
		"enc":encode(self.serverpanel.enc.GetValue())},"transfers":{\
		"downloaddir":encode(self.transferspanel.downloaddirctrl.GetValue()), \
		"shared":shared, "sharedfiles":self.transferspanel.sharedfiles, \
		"sharedfilesstreams":self.transferspanel.sharedfilesstreams, \
		"fileindex":self.transferspanel.fileindex, \
                "wordindex":self.transferspanel.wordindex, \
	        "sharedmtimes":self.transferspanel.sharedmtimes, \
		"rescanonstartup":encode(self.transferspanel.rescanonstartup.GetValue()),\
		"uploadbandwidth":uploadbandwidth, \
		"uselimit":encode(self.transferspanel.useuploadlimit.GetValue()), \
		"usecustomban":encode(self.miscpanel.usecustomban.GetValue()), \
		"customban":encode(self.miscpanel.customban.GetValue()), \
		"uploadlimit":uploadlimit, "queuelimit":queuelimit, \
		"limitby":encode(self.transferspanel.limittotal.GetValue()), \
		"sharedownloaddir":encode(self.transferspanel.sharedownloadctrl.GetValue())},"userinfo": \
		{"descr":encode(self.userinfopanel.descr.GetValue()).__repr__(), \
		"pic":encode(self.userinfopanel.pic.GetValue())},"logging":{ \
		"logsdir":encode(self.miscpanel.logsdirctrl.GetValue()), \
		"privatechat":encode(self.miscpanel.loggingprivatectrl.GetValue()), \
		"chatrooms":encode(self.miscpanel.loggingchatctrl.GetValue())},
		"searches":{"maxresults":maxresults}}
