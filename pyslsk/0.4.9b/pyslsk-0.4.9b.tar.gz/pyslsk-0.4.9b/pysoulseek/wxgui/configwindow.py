# Copyright (c) 2001-2002 Alexander Kanavin. All rights reserved.

"""
This module contains configuration classes for pyslsk.
"""

import ConfigParser
import string
import os.path
import os,stat
from pysoulseek import mp3
from pysoulseek import utils

from wxPython.wx import *

class ServerList(wxListCtrl):
    """ This is a list control that contains list of official servers """
    def __init__(self,parent,id, size, style = wxLC_REPORT|wxLC_VIRTUAL|wxSUNKEN_BORDER):
	wxListCtrl.__init__(self,parent,id, style = style, size = size)
	self.InsertColumn(0,"Description", width=250)
	self.InsertColumn(1,"Hostname",width=150)
	self.SetItemCount(0)

    def setList(self,list):
	self.SetItemCount(len(list))
	self.list = list

    def OnGetItemText(self, item,col):
	return self.list[item][col]

    def OnGetItemImage(self,item):
	return -1

class ServerChoose(wxDialog):
    """ This class defines a servers list window that is used to let user
	select one of the official servers from the list """
    def __init__(self,parent,id, title):
	wxDialog.__init__(self,parent,id,title)

	self.serverlistctrl = ServerList(self, -1, size=wxSize(420,200))
        self.ok = wxButton(self, wxID_OK, "OK")
        self.ok.SetDefault()
        self.cancel = wxButton(self, wxID_CANCEL, "Cancel")

        buttonssizer = wxBoxSizer(wxHORIZONTAL)
        buttonssizer.Add(self.ok)
        buttonssizer.Add(60,20)
        buttonssizer.Add(self.cancel)

        mainsizer = wxBoxSizer(wxVERTICAL)
        mainsizer.Add(self.serverlistctrl,flag=wxALL, border = 10)
        mainsizer.Add(buttonssizer,flag=wxALL|wxALIGN_CENTER, border = 10)
        self.SetSizer(mainsizer)
        self.SetAutoLayout(true)
        mainsizer.Fit(self)
	self.CenterOnParent()

	serverlist=utils.getServerList("http://www.slsk.org/slskinfo2")
	self.serverlistctrl.setList(serverlist)


    def getServer(self):
	item = self.serverlistctrl.GetNextItem(-1,wxLIST_NEXT_ALL,wxLIST_STATE_SELECTED)
	if item == -1:
	    return None
	else:
	    return self.serverlistctrl.list[item][1]

class ConfigWindow(wxDialog):
    """
    This class defines a settings window that the main application should 
    display on request. 

    Methods:
    SetSettings(config) - fills widgets in the window 
    with provided values
    GetSettings - returns a tuple of settings from window widgets (possibly 
    modified by user
    """
    def __init__(self, parent, id, title):
	wxDialog.__init__(self,parent,id,title)

	nb = wxNotebook(self, -1)
	nbs = wxNotebookSizer(nb)
	serverpanel = wxPanel(nb, -1)
	transferspanel = wxPanel(nb, -1)
	userinfopanel = wxPanel(nb, -1)
	nb.AddPage(serverpanel,"Server")
	nb.AddPage(transferspanel,"Transfers")
	nb.AddPage(userinfopanel,"Personal info")

	self.serverctrl = wxTextCtrl(serverpanel,-1,size=wxSize(250, 25))
	self.loginctrl = wxTextCtrl(serverpanel,-1,size=wxSize(100, 25))
	self.passwctrl = wxTextCtrl(serverpanel,-1,size=wxSize(100, 25))
	self.serverchoose = wxButton(serverpanel, -1, "Choose...")
	EVT_BUTTON(self,self.serverchoose.GetId(),self.OnServerChoose)
	self.enc = wxComboBox(serverpanel, -1, style = wxCB_DROPDOWN|wxCB_READONLY|wxCB_SORT,choices = parent.np.getencodings())
	self.enc.SetSelection(0)

	hostsizer = wxBoxSizer(wxHORIZONTAL)
	hostsizer.Add(self.serverctrl)
	hostsizer.Add(self.serverchoose,flag=wxALIGN_CENTER)

	serversizer = wxStaticBoxSizer(wxStaticBox(serverpanel,-1,"Server settings:"),wxVERTICAL)
	serversizer.Add(wxStaticText(serverpanel, -1, "Server (hostname:port):"),flag=wxTOP|wxLEFT, border = 10)
	serversizer.Add(hostsizer,flag=wxLEFT|wxRIGHT, border = 10)
	serversizer.Add(wxStaticText(serverpanel, -1, "Login:"),flag=wxTOP|wxLEFT, border = 10)
	serversizer.Add(self.loginctrl,flag=wxLEFT, border = 10)
	serversizer.Add(wxStaticText(serverpanel, -1, "Password:"),flag=wxTOP|wxLEFT, border = 10)
	serversizer.Add(self.passwctrl,flag=wxLEFT, border = 10)
	serversizer.Add(wxStaticText(serverpanel, -1, "Network character encoding (if not sure, choose ascii):"),flag=wxTOP|wxLEFT, border = 10)
	serversizer.Add(self.enc,flag=wxLEFT|wxBOTTOM, border = 10)

	self.downloaddirctrl = wxTextCtrl(transferspanel,-1,size=wxSize(250, 25))
	self.uploaddirsctrl = wxListBox(transferspanel, -1, size=wxSize(250,100))
	self.uploadbandwidth = wxTextCtrl(transferspanel,-1,size=wxSize(30, 25))
	self.downloaddirchoose = wxButton(transferspanel, -1, "Choose...")
	self.sharedownloadctrl = wxCheckBox(transferspanel, -2, "Share download directory")
	self.uploaddiradd = wxButton(transferspanel, -1, "Add...")
	self.uploaddirrem = wxButton(transferspanel, -1, "Remove")
	self.uploaddirrescan = wxButton(transferspanel, -1, "Rescan")
	EVT_BUTTON(self,self.downloaddirchoose.GetId(),self.OnDownloadChoose)
	EVT_BUTTON(self,self.uploaddiradd.GetId(),self.OnUploadAdd)
	EVT_BUTTON(self,self.uploaddirrem.GetId(),self.OnUploadRem)
        EVT_BUTTON(self,self.uploaddirrescan.GetId(),self.OnUploadRescan)
	EVT_CHECKBOX(self,self.sharedownloadctrl.GetId(),self.OnShareDownload)

	downloadsizer = wxBoxSizer(wxHORIZONTAL)
        downloadsizer.Add(self.downloaddirctrl)
        downloadsizer.Add(self.downloaddirchoose,flag=wxALIGN_CENTER)
	
	uploadbuttonssizer = wxBoxSizer(wxVERTICAL)
        uploadbuttonssizer.Add(self.uploaddiradd)
        uploadbuttonssizer.Add(self.uploaddirrem)
        uploadbuttonssizer.Add(self.uploaddirrescan)

	uploadsizer = wxBoxSizer(wxHORIZONTAL)
	uploadsizer.Add(self.uploaddirsctrl)
	uploadsizer.Add(uploadbuttonssizer)

	bandwidthsizer = wxBoxSizer(wxHORIZONTAL)
	bandwidthsizer.Add(wxStaticText(transferspanel, -1, "upload speed exceeds "),flag=wxALIGN_CENTER)
	bandwidthsizer.Add(self.uploadbandwidth)
	bandwidthsizer.Add(wxStaticText(transferspanel, -1, " KBytes/sec"),flag=wxALIGN_CENTER)
	
	transferssizer = wxStaticBoxSizer(wxStaticBox(transferspanel,-1,"Transfers settings:"),wxVERTICAL)
	transferssizer.Add(wxStaticText(transferspanel, -1, "Download directory:"),flag=wxTOP|wxLEFT, border = 10)
	transferssizer.Add(downloadsizer,flag=wxLEFT|wxRIGHT, border = 10)
	transferssizer.Add(self.sharedownloadctrl,flag=wxLEFT|wxTOP, border = 10)
	transferssizer.Add(wxStaticText(transferspanel, -1, "Shared directories:"),flag=wxTOP|wxLEFT, border = 10)
	transferssizer.Add(uploadsizer, flag=wxLEFT|wxRIGHT, border = 10)
	transferssizer.Add(wxStaticText(transferspanel, -1, "Locally queue remote requests if current"),flag=wxTOP|wxLEFT, border = 10)
	transferssizer.Add(bandwidthsizer,flag=wxBOTTOM|wxLEFT, border = 10)

	self.descr = wxTextCtrl(userinfopanel,-1,size=wxSize(250,100),style = wxTE_MULTILINE|wxTE_RICH)
	self.pic = wxTextCtrl(userinfopanel,-1,size=wxSize(250, 25))
	self.picchoose = wxButton(userinfopanel, -1, "Choose...")
	EVT_BUTTON(self,self.picchoose.GetId(),self.OnPicChoose)

	picsizer = wxBoxSizer(wxHORIZONTAL)
	picsizer.Add(self.pic)
	picsizer.Add(self.picchoose,flag=wxALIGN_CENTER)

	userinfosizer = wxStaticBoxSizer(wxStaticBox(userinfopanel,-1,"Personal settings:"),wxVERTICAL)
	userinfosizer.Add(wxStaticText(userinfopanel, -1, "Self-description:"),flag=wxTOP|wxLEFT, border = 10)
	userinfosizer.Add(self.descr,1,flag=wxLEFT|wxRIGHT, border = 10)
	userinfosizer.Add(wxStaticText(userinfopanel, -1, "Picture:"),flag=wxTOP|wxLEFT, border = 10)
	userinfosizer.Add(picsizer,flag=wxLEFT|wxBOTTOM, border = 10)


	serverpanel.SetSizer(serversizer)
	serverpanel.SetAutoLayout(true)
	transferspanel.SetSizer(transferssizer)
	transferspanel.SetAutoLayout(true)
	userinfopanel.SetSizer(userinfosizer)
	userinfopanel.SetAutoLayout(true)

	self.ok = wxButton(self, wxID_OK, "OK")
	self.ok.SetDefault()
	self.cancel = wxButton(self, wxID_CANCEL, "Cancel")

	buttonssizer = wxBoxSizer(wxHORIZONTAL)
	buttonssizer.Add(self.ok)
	buttonssizer.Add(60,20)
	buttonssizer.Add(self.cancel)

	mainsizer = wxBoxSizer(wxVERTICAL)
	mainsizer.Add(nbs,flag=wxALL,border=5)
	mainsizer.Add(buttonssizer,flag=wxALL|wxALIGN_CENTER, border = 10)
	self.SetSizer(mainsizer)
	self.SetAutoLayout(true)
	mainsizer.Fit(self)

	self.sharedfiles = {}
	self.needrescan = 0

    def OnServerChoose(self,event):
	serverchoose = ServerChoose(self,-1,"Choose server")
	val = serverchoose.ShowModal()
	if val == wxID_OK:
	    server = serverchoose.getServer()
	    if server is not None:
		self.serverctrl.SetValue(server)

    def OnDownloadChoose(self,event):
	downloadchoose = wxDirDialog(self)
	val = downloadchoose.ShowModal()
	if val == wxID_OK:
	    dir = downloadchoose.GetPath()
	    if dir is not None:
		self.downloaddirctrl.SetValue(dir)
	    if self.sharedownloadctrl.GetValue():
		self.needrescan = 1

    def OnShareDownload(self,event):
	self.needrescan = 1

    def OnUploadAdd(self,event):
        uploadadd = wxDirDialog(self)
        val = uploadadd.ShowModal()
        if val == wxID_OK:
            dir = uploadadd.GetPath()
            if dir is not None:
                self.uploaddirsctrl.Append(dir)
	self.needrescan = 1

    def OnUploadRem(self,event):
	num = self.uploaddirsctrl.GetSelection()
	self.uploaddirsctrl.Delete(num)
	self.needrescan = 1

    def OnUploadRescan(self,event):
	self.rescandirs()
	self.needrescan = 0

    def rescandirs(self):
	shared = []
        for i in range(self.uploaddirsctrl.Number()):
            shared.append(self.uploaddirsctrl.GetString(i))
	if self.sharedownloadctrl.GetValue():
	    shared.append(self.downloaddirctrl.GetValue())
	self.sharedfiles = utils.getFilesList(shared)

    def OnPicChoose(self,event):
	picchoose = wxFileDialog(self)
	val = picchoose.ShowModal()
	if val == wxID_OK:
            pic = picchoose.GetPath()
            if pic is not None:
                self.pic.SetValue(pic)

    def SetSettings(self, config):
	server = config.sections["server"]
	transfers = config.sections["transfers"]
	userinfo = config.sections["userinfo"]
	if server["server"] is not None:
    	    self.serverctrl.SetValue(string.join([str(i) for i in server["server"]],":"))
	if server["login"] is not None:
	    self.loginctrl.SetValue(server["login"])
	if server["passw"] is not None:
	    self.passwctrl.SetValue(server["passw"])
	if server["enc"] is not None:
	    self.enc.SetValue(server["enc"])
	if transfers["downloaddir"] is not None:
	    self.downloaddirctrl.SetValue(transfers["downloaddir"])
	if transfers["shared"] is not None:
	    self.uploaddirsctrl.Clear()
	    for i in transfers["shared"]:
		self.uploaddirsctrl.Append(i)
	if transfers["sharedfiles"] is not None:
	    self.sharedfiles = transfers["sharedfiles"]
	if transfers["uploadbandwidth"] is not None:
	    self.uploadbandwidth.SetValue(str(transfers["uploadbandwidth"]))
	if transfers["sharedownloaddir"] is not None:
	    self.sharedownloadctrl.SetValue(transfers["sharedownloaddir"])
	if userinfo["descr"] is not None:
	    self.descr.SetValue(eval(userinfo["descr"]))
	if userinfo["pic"] is not None:
	    self.pic.SetValue(userinfo["pic"])

    def GetSettings(self):
        try:
            server = string.split(self.serverctrl.GetValue(),":")
            server[1] = string.atoi(server[1])
	    server = tuple(server)
        except:
            server = None
	shared = []
	for i in range(self.uploaddirsctrl.Number()):
	    shared.append(self.uploaddirsctrl.GetString(i))
	if self.needrescan:
	    self.rescandirs()
	    self.needrescan = 0 
	return {"server":{"server":server, "login":self.loginctrl.GetValue(), "passw":self.passwctrl.GetValue(),"enc":self.enc.GetValue()},"transfers":{"downloaddir":self.downloaddirctrl.GetValue(), "shared":shared, "sharedfiles":self.sharedfiles,"uploadbandwidth":self.uploadbandwidth.GetValue(),"sharedownloaddir":self.sharedownloadctrl.GetValue()},"userinfo":{"descr":self.descr.GetValue().__repr__(),"pic":self.pic.GetValue()}}

