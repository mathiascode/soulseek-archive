# Copyright (c) 2001-2002 Alexander Kanavin. All rights reserved.
pass
