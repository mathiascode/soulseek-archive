# Copyright (c) 2001-2003 Alexander Kanavin. All rights reserved.

"""
This is the client code for the notebook with bird icons.
"""

from wxPython.wx import *
import images
from pysoulseek.utils import version

class IconNotebook(wxNotebook):
    def __init__(self, parent, id, style = None, frame = None): 
        wxNotebook.__init__(self,parent,id, style = style)
        
	EVT_NOTEBOOK_PAGE_CHANGED(self,self.GetId(),self.OnPageChanged)

        self.imglist = wxImageList(18,18)
        self.online = self.imglist.Add(images.getOnlineBitmap())
	self.hilite = self.imglist.Add(images.getActiveBitmap())
        self.AssignImageList(self.imglist)
	self.pages = []
	self.page = 0
	self.frame = frame

    def OnPageChanged(self, event):
	self.page = event.GetSelection()
	self.SetPageImage(self.page,-1)
	if self.frame is not None:
	    self.frame.SetTitle("PySoulSeek %s" % version)
	event.Skip()

    def AddPage(self, page, title):
	wxNotebook.AddPage(self, page, title)
	self.pages.append(page)

    def DeleteAllPages(self):
	wxNotebook.DeleteAllPages(self)
	self.pages = []
	self.page = 0

    def DeletePage(self, index):
	wxNotebook.DeletePage(self, index)
	del self.pages[index]
	self.page = self.GetSelection()
	if index <= self.GetSelection():
	    self.page = self.page - 1
	
    def OnPageUpdated(self, pageobj, hilite = False):
	if self.pages[self.page] != pageobj:
	    if hilite:
		self.SetPageImage(self.pages.index(pageobj),1)
	    elif self.GetPageImage(self.pages.index(pageobj)) != 1:
	        self.SetPageImage(self.pages.index(pageobj),0)
	    return 1
	return 0

