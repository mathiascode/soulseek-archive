# Copyright (c) 2001-2003 Alexander Kanavin. All rights reserved.

""" This module contains GUI class that deals with file transfers
"""

from wxPython.wx import *
from pysoulseek import slskmessages
import os
import pysoulseek
import string
import time
from sortablelist import sortableListCtrl
import locale
from types import StringType

class TransfersList(sortableListCtrl):
    """ This is a list control for transfers. Gets transfer data from transfer
    manager.
    """
    def __init__(self, parent, id, list, style = wxLC_REPORT|wxSUNKEN_BORDER):
        sortableListCtrl.__init__(self,parent,id, style = style)
	self.list = list
	self.InsertColumn(0,"Filename", width = 300)
	self.InsertColumn(1,"User", width = 100)
	self.InsertColumn(2,"Status", width  = 150)
	self.InsertColumn(3,"Size", width = 100,format=wxLIST_FORMAT_RIGHT)
	self.InsertColumn(4,"Speed",width = 50,format=wxLIST_FORMAT_RIGHT)
	self.InsertColumn(5,"Time elapsed", width = 70,format=wxLIST_FORMAT_RIGHT)
	self.InsertColumn(6,"Time left", width = 70,format=wxLIST_FORMAT_RIGHT)
	self.InsertColumn(7,"Path", width = 300)
	self.update(None)


    def Humanize(self, size):
    	if size is None:
    	    return None
	priv = ""
        if type(size) is StringType and size[-13:] == " (privileged)":
		size, priv = size[:-13], size[-13:]
        try:
	    s = int(size)
	    if s > 1024*1024*1024:
	        r = "%.2f GB" % ((float(s) / (1024.0*1024.0*1024.0)))
	    elif s > 1024*1024:
	        r = "%.2f MB" % ((float(s) / (1024.0*1024.0)))
	    elif s > 1024:
	        r = "%.2f KB" % ((float(s) / 1024.0))
	    else:
                r = str(size)
	    return r + priv
	except:
	    return size + priv

    def update(self, item):
	if item is not None:
	    if item in self.list:
		if self.list.index(item) >= self.GetItemCount():
		    self.InsertStringItem(self.list.index(item), str(self.GetColumnText(item,0)))
		    
	        for j in range(8):
	            self.SetStringItem(self.list.index(item), j, str(self.GetColumnText(item,j)))
	else:
	    for i in range(len(self.list)):
		if i >= self.GetItemCount():
		    self.InsertStringItem(i, str(self.GetColumnText(self.list[i],0)))
		for j in range(8):
		    self.SetStringItem(i, j, str(self.GetColumnText(self.list[i],j)))
	    for i in range(len(self.list), self.GetItemCount()):
		self.DeleteItem(len(self.list))

    def GetColumnText(self,item,col,sort=False):
	if col == 0:
	    return string.split(item.filename,'\\')[-1]
	if col == 1:
	    return item.user
	if col == 2:
	    if not sort:
	        return self.Humanize(item.status)
	    else:
	        return item.status
	if col == 3:
	    if not sort:
	        return self.Humanize(item.size)
	    else:
	        return item.size
	if col == 4:
            if item.speed is not None:
	        return "%.1f" %(item.speed)
	    else:
		return None
	if col == 5:
	    return item.timeelapsed
	if col == 6:
	    return item.timeleft
	if col == 7:
	    return item.path

    def UnselectAll(self):
        for i in range(len(self.list)):
            self.SetItemState(i,0,wxLIST_STATE_SELECTED)

    def SortList(self, col, order):
        if order == 0:
            self.list.sort(lambda x,y: self.cmp(self.GetColumnText(x,col,True),self.GetColumnText(y,col,True)))
        else:
            self.list.sort(lambda y,x: self.cmp(self.GetColumnText(x,col,True),self.GetColumnText(y,col,True)))
	self.update(None)


class TransfersPanel(wxPanel):
    """ This is the transfer panel that contains transfers list control.
    The right-click pop--up menu is implemented here."""
    def __init__(self, parent, id, list, eventprocessor, transfermanager):
	wxPanel.__init__(self,parent,id)
	self.list = list
	self.eventprocessor = eventprocessor
	self.transfermanager = transfermanager

	self.processrequest = self.eventprocessor.ProcessRequestToPeer
	self.users = self.transfermanager.users
	self.listctrl = TransfersList(self,-1,list)
	sizer = wxBoxSizer(wxVERTICAL)
	sizer.Add(self.listctrl,1,wxEXPAND, border = 10)
	self.SetSizer(sizer)
	self.SetAutoLayout(True)

	self.menu = wxMenu()
	getplaceID = wxNewId()
	self.menu.Append(getplaceID, 'Get Place In Queue')
	EVT_MENU(self,getplaceID,self.OnGetPlace)
	self.menu.AppendSeparator()
        sendmessageID=wxNewId()
        self.menu.Append(sendmessageID, 'Send Message')
        EVT_MENU(self,sendmessageID, self.OnSendMessage)
	getaddrID=wxNewId()
	self.menu.Append(getaddrID, 'Show IP address')
	EVT_MENU(self,getaddrID, self.OnGetAddr)
        getinfoID=wxNewId()
        self.menu.Append(getinfoID, 'Get User Info')
        EVT_MENU(self,getinfoID, self.OnGetInfo)
        browseID=wxNewId()
        self.menu.Append(browseID, 'Browse Files')
        EVT_MENU(self,browseID, self.OnBrowse)
        addtolistID=wxNewId()
        self.menu.Append(addtolistID, 'Add to User List')
        EVT_MENU(self,addtolistID, self.OnAddToList)
	banuserID=wxNewId()
	self.menu.Append(banuserID, "Ban this user")
	EVT_MENU(self,banuserID, self.OnBanUser)

	self.menu.AppendSeparator()

        self.abortID=wxNewId()
        self.menu.Append(self.abortID, 'Abort')
        EVT_MENU(self,self.abortID, self.OnAbort)
	if self.list is self.transfermanager.downloads:
            abortremID=wxNewId()
            self.menu.Append(abortremID, 'Abort and remove file')
            EVT_MENU(self,abortremID, self.OnAbort)
        retryID=wxNewId()
        self.menu.Append(retryID, 'Retry')
        EVT_MENU(self,retryID, self.OnRetry)
        clearID=wxNewId()
        self.menu.Append(clearID, 'Clear')
        EVT_MENU(self,clearID, self.OnClear)
        self.menu.AppendSeparator()

        clearfaID=wxNewId()
        self.menu.Append(clearfaID, 'Clear finished/aborted')
        EVT_MENU(self,clearfaID, self.OnClearFinAb)
        clearfID=wxNewId()
        self.menu.Append(clearfID, 'Clear finished')
        EVT_MENU(self,clearfID, self.OnClearFin)
        clearaID=wxNewId()
        self.menu.Append(clearaID, 'Clear aborted')
        EVT_MENU(self,clearaID, self.OnClearAb)
        clearqID=wxNewId()
        self.menu.Append(clearqID, 'Clear queued')
        EVT_MENU(self,clearqID, self.OnClearQueued)


	EVT_RIGHT_UP(self.listctrl, self.OnRightUp)

    def update(self, entry = None):
	""" Call this to make the transfer panel update the data."""
	self.listctrl.update(entry)
	self.eventprocessor.frame.updateBandwidth()

    def OnRightUp(self, event):
	""" Show the pop-up menu"""
        pt = event.GetPosition()
        item, flags = self.listctrl.HitTest(pt)
	self.item = item
	if item >= 0:
            self.listctrl.SetItemState(item,wxLIST_STATE_FOCUSED,wxLIST_STATE_FOCUSED)
            self.listctrl.PopupMenu(self.menu, pt)

    """ Handlers for the menu items """

    def OnSendMessage(self, event):
	""" Sends user a private message """
        self.eventprocessor.privatechat.SendMessage(self.list[self.item].user)

    def OnGetAddr(self, event):
	user = self.list[self.item].user
	self.eventprocessor.queue.put(slskmessages.GetPeerAddress(user))

    def OnGetPlace(self,event):
	""" Gets place in line for the queued file """
        user = self.list[self.item].user
        self.processrequest(user, slskmessages.PlaceInQueueRequest(None,self.list[self.item].filename))

    def OnGetInfo(self, event):
	""" Gets info about a user """
	user = self.list[self.item].user
        self.processrequest(user, slskmessages.UserInfoRequest(None), self.eventprocessor.userinfo)

    def OnBrowse(self, event):
	""" Browse user's files """
	user = self.list[self.item].user
        self.processrequest(user, slskmessages.GetSharedFileList(None), self.eventprocessor.userbrowse)

    def OnAddToList(self,event):
	user = self.list[self.item].user
	self.eventprocessor.userlist.AddToList(user)	

    def OnBanUser(self,event):
    	user = self.list[self.item].user
    	self.eventprocessor.frame.BanUser(user)

    def OnAbort(self, event):
	""" Abort all selected transfers """
	item = -1
	while 1:
	    item = self.listctrl.GetNextItem(item,wxLIST_NEXT_ALL,wxLIST_STATE_SELECTED|wxLIST_STATE_FOCUSED)
	    if item == -1:
		break

	    transfer = self.list[item]
            if transfer.status != "Finished" and transfer.status != "Old":
		if event.GetId() != self.abortID:
		    self.transfermanager.AbortTransfer(transfer, True)
		else:
		    self.transfermanager.AbortTransfer(transfer)
                transfer.status = "Aborted"
		transfer.req = None
	if self.list is self.transfermanager.uploads:
	    self.transfermanager.calcUploadQueueSizes()
	    self.transfermanager.checkUploadQueue()
	else:
	    self.transfermanager.SaveDownloads()
	self.update()

    def OnRetry(self,event):
	""" Retry all selected transfers, if they're not active 
	and not finished and a user is online """
        item = -1
        while 1:
            item = self.listctrl.GetNextItem(item,wxLIST_NEXT_ALL,wxLIST_STATE_SELECTED|wxLIST_STATE_FOCUSED)
            if item == -1:
                break
            transfer = self.list[item]
            if transfer.status != "Finished" and transfer.status != "Old":
                self.transfermanager.AbortTransfer(transfer)
                transfer.req = None
	        if self.list is self.transfermanager.downloads:
		    self.transfermanager.getFile(transfer.user, transfer.filename, transfer.path, transfer)
		else:
		    self.status = "Queued"
	self.transfermanager.calcUploadQueueSizes()

    def OnClear(self,event):
	""" Remove all selected transfers. Abort those that are in progress."""
        item = -1
        while 1:
            item = self.listctrl.GetNextItem(item,wxLIST_NEXT_ALL,wxLIST_STATE_SELECTED|wxLIST_STATE_FOCUSED)
            if item == -1:
                break
            transfer = self.list[item]
            self.transfermanager.AbortTransfer(transfer)
	    self.list[item] = None
	while self.list.count(None) > 0:
	    self.list.remove(None)
	self.listctrl.UnselectAll()
        if self.list is self.transfermanager.uploads:
            self.transfermanager.checkUploadQueue()
	    self.transfermanager.calcUploadQueueSizes()
	else:
	    self.transfermanager.SaveDownloads()
 	self.update()

    def OnClearFinAb(self,event):
	""" Remove all finished or aborted transfers"""
	statuslist = ["Finished","Aborted","Connection closed by peer","Cancelled"]
	if self.list is self.transfermanager.uploads:
	    statuslist += ["Cannot connect"]
        self.listctrl.UnselectAll()
	for i in self.list[:]:
	    if i.status in statuslist:
		if i.transfertimer is not None:
		    i.transfertimer.cancel()
		self.list.remove(i)
	self.update()

    def OnClearFin(self,event):
	""" Remove just the finished transfers."""
        self.listctrl.UnselectAll()
        for i in self.list[:]:
            if i.status == "Finished":
                if i.transfertimer is not None:
                    i.transfertimer.cancel()
                self.list.remove(i)
        self.update()

    def OnClearAb(self,event):
	""" Remove just the aborted transfers. """
        statuslist = ["Aborted","Connection closed by peer","Cancelled"]
        if self.list is self.transfermanager.uploads:
            statuslist += ["Cannot connect"]
        self.listctrl.UnselectAll()
        for i in self.list[:]:
            if i.status in statuslist:
                if i.transfertimer is not None:
                    i.transfertimer.cancel()
                self.list.remove(i)
        self.update()

    def OnClearQueued(self,event):
	""" Remove all (locally or remotely) queued transfers. """
        self.listctrl.UnselectAll()
        for i in self.list[:]:
            if i.status == "Queued":
                if i.transfertimer is not None:
                    i.transfertimer.cancel()
                self.list.remove(i)
	self.transfermanager.SaveDownloads()
        self.transfermanager.calcUploadQueueSizes()
        self.update()

    def ClearByUser(self, user):
        self.listctrl.UnselectAll()
        for i in self.list[:]:
            if i.user == user:
                if i.transfertimer is not None:
                    i.transfertimer.cancel()
                self.list.remove(i)
	self.transfermanager.calcUploadQueueSizes()
        self.update()

