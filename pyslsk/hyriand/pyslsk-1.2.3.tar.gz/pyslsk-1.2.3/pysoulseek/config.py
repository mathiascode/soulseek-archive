# Copyright (c) 2001-2003 Alexander Kanavin. All rights reserved.

"""
This module contains configuration classes for pyslsk.
"""

import ConfigParser
import string
import os.path
import cPickle
import shelve

class Config:
    """ 
    This class holds configuration information and provides the 
    following methods:

    needConfig() - returns true if configuration information is incomplete
    readConfig() - reads configuration information from ~/.pyslsk
    setConfig(config_info_dict) - sets configuration information
    writeConfig - writes configuration information to ~/.pyslsk

    The actual configuration information is stored as a two-level dictionary.
    First-level keys are config sections, second-level keys are config 
    parameters.
    """
    def __init__(self, filename):
        self.filename = filename
	self.parser = ConfigParser.ConfigParser()
	self.parser.read([self.filename])
        self.sections = {"server":{"server":('mail.slsk.org', 2240), \
	"login":None,"passw":None, \
	"autosearch":[], \
	"portrange": (2234,2239), "enc":"utf-8","userlist":[], \
	"banlist":[], "ignorelist":[],"autojoin":["pyslsk"],"autoaway":15}, \
	"transfers":{"downloaddir":None,"sharedownloaddir":1,"shared":None, \
	"uploadbandwidth":10,"uselimit":0,"uploadlimit":100,"limitby":1,\
	"usecustomban":0,"customban":"don't bother to retry", "queuelimit":100,\
	"downloads":[],"sharedfiles":{},"sharedfilesstreams":{}, \
	"wordindex":{},"fileindex":{},"sharedmtimes":{},"rescanonstartup":0}, \
	"userinfo":{"descr":"''","pic":""},"logging": {"logcollapsed":0, \
	"logsdir":os.path.expanduser("~"),"privatechat":0,"chatrooms":0}, \
	"searches":{"maxresults":50,"history":[]}}
	    
    def needConfig(self):
	for i in self.sections.keys():
	    for j in self.sections[i].keys():
		if self.sections[i][j] is None or self.sections[i][j] == '' and i != "userinfo":
		    return 1
	return 0

    def readConfig(self):
	for i in self.parser.sections():
	    for j in self.parser.options(i):
		val = self.parser.get(i,j, raw = 1)
		if i not in self.sections.keys():
		    print "Bogus config section:",i
		elif j not in self.sections[i].keys():
		    print "Bogus config option",j,"section",i
		elif j in ['login','passw','enc','downloaddir','customban','descr','pic','logsdir']:
		    self.sections[i][j] = val
		else:
		    try:
		        self.sections[i][j] = eval(val)
		    except:
			self.sections[i][j] = None
			raise
	sharedfiles = shelve.open(self.filename+".files.db")
	sharedfilesstreams =shelve.open(self.filename+".streams.db")
	wordindex = shelve.open(self.filename+".wordindex.db")
	fileindex = shelve.open(self.filename+".fileindex.db")
	sharedmtimes = shelve.open(self.filename+".mtimes.db")
	self.sections["transfers"]["sharedfiles"] = sharedfiles
	self.sections["transfers"]["sharedfilesstreams"] = sharedfilesstreams
	self.sections["transfers"]["wordindex"] = wordindex
	self.sections["transfers"]["fileindex"] = fileindex
	self.sections["transfers"]["sharedmtimes"] = sharedmtimes
	if self.sections["server"]["server"] == ('mail.slsk.org',2242):
	    self.sections["server"]["server"] = ('mail.slsk.org', 2240)
 
    def writeConfig(self):
        for i in self.sections.keys():
            if not self.parser.has_section(i):
                self.parser.add_section(i)
            for j in self.sections[i].keys():
                if j not in ["sharedfiles","sharedfilesstreams","wordindex","fileindex","sharedmtimes"]:
                    self.parser.set(i,j,self.sections[i][j])
                else:
                    self.parser.remove_option(i,j)

        oldumask = os.umask(0077)
	try:
	    f = open(self.filename,"w")
	except IOError, (errno, strerror):
            print "Can't save config file, I/O error(%s): %s" % (errno, strerror)
	else:
	    self.parser.write(f)
	    f.close()
        os.umask(oldumask)
        # A paranoid precaution since .pyslsk contains the password
        try:
            os.chmod(self.filename, 0600)
        except:
            pass

    def setShares(self,files,streams,wordindex,fileindex,mtimes):
	if self.sections["transfers"]["sharedfiles"] == files:
	    return
	self.sections["transfers"]["sharedfiles"].close()
	self.sections["transfers"]["sharedfilesstreams"].close()
	self.sections["transfers"]["sharedmtimes"].close()
	self.sections["transfers"]["wordindex"].close()
	self.sections["transfers"]["fileindex"].close()
	self.sections["transfers"]["sharedfiles"] = shelve.open(self.filename+".files.db",'n')
	self.sections["transfers"]["sharedfilesstreams"] = shelve.open(self.filename+".streams.db",'n')
	self.sections["transfers"]["sharedmtimes"] = shelve.open(self.filename+".mtimes.db",'n')
	self.sections["transfers"]["wordindex"] = shelve.open(self.filename+".wordindex.db",'n')
	self.sections["transfers"]["fileindex"] = shelve.open(self.filename+".fileindex.db",'n')
	for (i,j) in files.items():
	    self.sections["transfers"]["sharedfiles"][i] = j
	for (i,j) in streams.items():
           self.sections["transfers"]["sharedfilesstreams"][i] = j
	for (i,j) in mtimes.items():
            self.sections["transfers"]["sharedmtimes"][i] = j
	for (i,j) in wordindex.items():
	    self.sections["transfers"]["wordindex"][i] = j
        for (i,j) in fileindex.items():
            self.sections["transfers"]["fileindex"][i] = j

	

    def writeShares(self):
	self.sections["transfers"]["sharedfiles"].sync()
	self.sections["transfers"]["sharedfilesstreams"].sync()
	self.sections["transfers"]["wordindex"].sync()
	self.sections["transfers"]["fileindex"].sync()
	self.sections["transfers"]["sharedmtimes"].sync()

